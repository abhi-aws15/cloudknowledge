import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, ReactiveFormsModule, Validators, ValidationErrors } from '@angular/forms';

import { AppsettingsService } from 'src/app/config/appsettings.service';
import { ConfigService } from 'src/app/config/config.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonservicesService } from 'src/app/services/commonservices.service';

// Get file according to environment name
import { environment } from '../../../environments/environment';
import { ValidationService } from 'src/app/services/validation.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit, OnDestroy  {
  token: string;
  private sub: any;
  public redirect :any;
 

  public userForm = new FormGroup({
      BeneficiaryFirstName: new FormControl(null, Validators.required),
      LabhpatriName: new FormControl(null, Validators.required),
      BeneficiaryMiddleName: new FormControl(null, Validators.required),
      MobileNo: new FormControl(null, Validators.required)
  });


  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute, 
    private _appSettings: AppsettingsService, 
    private _ConfigService: ConfigService,
    private _notification: NotificationService,
    private _commonService: CommonservicesService) {
    
     }

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      this.token = params['token']; // (+) converts string 'token' to a number      
    });
  
    if(window.localStorage.getItem("TokenID")=='' || window.localStorage.getItem("TokenID")== null || window.localStorage.getItem("TokenID")== undefined ){
      this.ValidateToken(1);
    }
    else{
      if (window.localStorage.getItem("TokenID") == this.token) {
        this.ValidateToken(0);
      }
      else{        
        window.localStorage.clear();
        this.ValidateToken(1);
      }
    }
  }

  ValidateToken(redirect){
     // window.localStorage.getItem("token")
      if(this.token != null || this.token !=""){
        var url = this._appSettings.eSewaURL;
        var ValidateToken = this._appSettings.ValidateToken;
        url = url + ValidateToken + this.token;
        
        this._ConfigService.getWithoutHeader(url)
        .subscribe(response => {
          this._notification.responseHandler(response);
          if(response["response"] == 1){
            if(redirect === 1){
              window.localStorage.setItem("TokenID", this.token);
              window.localStorage.setItem("token", response["data"][0]["Token"]);
              window.localStorage.setItem("session", response["data"][0]["Session"]);
              window.location.reload();
             // this._commonService.BindMenu();
            }
            else{
              this._commonService.BindMenu();
            }
          }
          else {
             window.localStorage.clear();
             this._commonService.BindMenu();
            // window.sessionStorage.clear();
            // window.location.href = environment.eSewaURL;
          }
        },
        err=>{
          console.log("status code--->"+err.status)
        });
        // In a real app: dispatch action to load the details here.
        }
        else{
          // window.localStorage.clear();
          // window.sessionStorage.clear();
          // window.location.href = environment.eSewaURL;
        }
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  submit() {
    console.log(this.userForm.value);
  }
}
