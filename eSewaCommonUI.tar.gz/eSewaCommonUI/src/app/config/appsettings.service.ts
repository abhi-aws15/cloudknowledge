import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppsettingsService {

  constructor() { }

  // eSewa URL's
  eSewaURL: string = environment.eSewaURL;
  // PostGre Master API URL's
  PostGreMasterAPI: string = environment.postGreMasterAPI;
  //Compulsory Marriage API
  CompulsoryMarriageAPI: string = "http://localhost:5069/";
  // Common Esewa URL
  CommonEsewaAPI: string = "http://localhost:5000/";

  // Marriage API URL's
  MarriageServicesAPI: string = environment.marriageServicesAPI;

  // eSewaDevURL: string = "https://esewadev.punjab.gov.in/";
  // eSewaTestURL: string = "https://esewatst.punjab.gov.in/";
  // eSewaStgURL: string = "https://esewastg.punjab.gov.in/";
  // eSewaProURL: string = "https://esewa.punjab.gov.in/";

  ValidateToken: string = "common/api/common/ValidateToken/";
  FetchMenu: string = "common/api/Menu/FetchUserNavigationMenu";
  DecryptCitizenID: string = "common/api/CommonExternalApis/DecryptCitizenID/";

  // Fetch master data
  fetchDistrict: string = "api/Masters/HM_MC_DistrictMaster/";
  fetchTehsil: string = "api/Masters/HM_MC_TehsilMaster/";
  fetchVillages: string = "api/Masters/HM_MC_VillageMaster/";
  fetchProcessingOfficeMaster: string = "api/Masters/HM_MC_ProcessingOfficeMaster/";

  // Fetch common master data
  fetchDepartment: string = "common/api/common/fetchdeptcatser";
  fetchSubDepartment: string = "common/api/common/GetSubDepartmentByDepartment/";
  fetchServicesByDepartmentID : string = "common/api/common/GetServicesByDepartment/";  
  fetchAdvanceSearchResult : string = "common/api/AllApplicationSearch/getApplications";

  fetchMaritalStatus: string = "api/Masters/HM_MC_MaritalStatusMatser";
  fetchRelationMaster: string = "api/Masters/HM_MC_RelationMaster";

  fetchMasterData: string = "offlineapi/api/Admin/serfnFetchMdata";
  GetApplicationIdAtCreation: string = "common/api/CommonExternalApis/GetApplicationIdAtCreation/";
  GetMappingStageAndUser: string = "common/api/CommonExternalApis/GetFirstUserMappingbyService";
  GetCitizenProfilePic: string = "common/api/CommonExternalApis/getUserProfilePicsById_for_profile/";

  ApplicationSubmit: string = "api/ApplicationSubmit/Submit";
  GetApplicationDetail: string = "api/ApplicationSubmit/"
  ApplicationReSubmit: string = "api/ApplicationSubmit/Resubmit"
  UploadBeneficiaryPic: string = "dms/api/DMS/UploadBeneficiaryPic"
}
