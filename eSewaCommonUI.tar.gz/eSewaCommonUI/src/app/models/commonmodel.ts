export class Commonmodel {
    selectfrom: string = null;
    selectby: string = null;
    selectionparam: string = null;
    selectionparam1: string = null;
}

export class ApplicationSubmitModel {
    applicationid: string = null;
    serviceID: string = null;
    applicant_address: string = null;
    applicant_name: string = null;
    dob: string = null;
    fatherfullname: string = null;
    motherfullname: string = null;
    marital_status: string = null;
    gender: string = null;
    pincode: string = null;
    region: string = null;
    state_code: string = null;
    district_code: string = null;
    division_code: string = null;
    tehsil_code: string = null;
    block_code: string = null;
    village_code: string = null;
    citizenID: string = null;
    assignmentLevel: string = null;
    assignmentID: string = null;
    application_type: string = null;
    doc_user_case: string = null;
    doc_user_case_value: string = null;
    CurrentStage: string = null;
    currentStageRefID: string = null;
    UserID: string = null;
    service_data: string = null;
}

