import { Commonmodel } from './commonmodel';

describe('Commonmodel', () => {
  it('should create an instance', () => {
    expect(new Commonmodel()).toBeTruthy();
  });
});
