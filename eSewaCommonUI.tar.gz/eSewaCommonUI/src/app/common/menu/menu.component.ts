import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';

import { AppsettingsService } from 'src/app/config/appsettings.service';
import { ConfigService } from 'src/app/config/config.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonservicesService } from 'src/app/services/commonservices.service';

// Get file according to environment name
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  public menulist : any = [];
  public child_array : any = [];
  public firstName : string;
  public designationName : string;

  constructor(
    private _appSettings: AppsettingsService, 
    private _ConfigService: ConfigService,
    private _notification: NotificationService,
    private _CommonservicesService: CommonservicesService) { }
    @ViewChild('mainSidebar') mainSidebar;
    @Output() mainSidebarHeight: EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
    //this._CommonservicesService.BindMenu();
    var token = window.localStorage.getItem("token");
    var url = environment.eSewaURL;
    var FetchMenu = this._appSettings.FetchMenu;
    url = url + FetchMenu;
    if(token != null || token !=''){
      this._ConfigService.get(url)
      .subscribe(response => {
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.menulist = response["data"];
          let temp:any = [];
       
        let surface_id = 0;
        let is_first = true;
        let last_id = 0;

        if (this.menulist != null) {
            for (var i = 0; i < (this.menulist).length; i++) {
                if (this.menulist[i].parent_item_id == 0) {
                    is_first = true;
                    temp[surface_id] = this.menulist[i];
                    if (surface_id > 0) { last_id = last_id+1; } else { last_id = 0; }
                    surface_id++;
                }   
                else {
                    if (is_first) {
                        is_first = false;
                        this.menulist[i].item_redirect_url = environment.eSewaURL.slice(0, -1) + this.menulist[i].item_redirect_url;
                        this.child_array.push(this.menulist[i]);
                    }
                    else {
                      this.menulist[i].item_redirect_url = environment.eSewaURL.slice(0, -1) + this.menulist[i].item_redirect_url;
                        this.child_array.push(this.menulist[i]);
                    }
                }
            }
        }
     
        this.menulist = temp;
        }
        else {
          this._notification.info("Please enter all required fields")
        }
      });
    }
  }
  ngAfterViewInit() {
    // this.mainSidebarHeight.emit(this.mainSidebar.nativeElement.offsetHeight);
  }
  logout() {
    window.localStorage.clear();
    window.sessionStorage.clear();
    window.location.href = environment.eSewaURL;
  }
  ngAfterContentInit() {  
    this.firstName= window.localStorage.getItem("f_name");
    this.designationName= window.localStorage.getItem("desig_name");
  }  
}
