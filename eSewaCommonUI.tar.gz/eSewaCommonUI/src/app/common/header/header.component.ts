import { Component, OnInit } from '@angular/core';// Get file according to environment name
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  logout() {
    window.localStorage.clear();
    window.sessionStorage.clear();
    window.location.href = environment.eSewaURL;
  }
}
