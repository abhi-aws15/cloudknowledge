import { AbstractControl, ValidationErrors, FormGroup, FormControl } from "@angular/forms";

export function UrlValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.startsWith("https") || !control.value.includes(".me")) {
      return { invalid: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function MobileValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[0-9]+(\.?[0-9]+)?$/)) {
      return { invalid: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function EmailValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (
      !control.value
        .toString()
        .match(/^\w+[\w-\.]*\@\w+((-\w+)|(\w*))\.[a-z]{2,8}$/)
    ) {
      return { invalid: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function email(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
      return { email: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function mobile(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[6-9]{1}[0-9]{9}$/)) {
      return { mobile: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function AlphaValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z ]*$/)) {
      return { AlphaValidator: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function NumericValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[0-9]+$/)) {
      return { NumericValidator: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function DecimalValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value != null) {
    if (!control.value.toString().match(/^\d*\.?\d*$/)) {
      return { DecimalValidator: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function AlphaNumericValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (
      !control.value.toString().match(/^[-a-zA-Z0-9]+(( ?)+[-a-zA-Z0-9]+)*$/)
    ) {
      return { AlphaNumericValidator: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function AllowedCharacterValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (
      !control.value
        .toString()
        .match(
          /^[-a-zA-Z0-9$-/:-{-~!"^_`\[\]]+(( ?)+[-a-zA-Z0-9$-/:-{-~!"^_`\[\]]+)*$/
        )
    ) {
      return { AllowedCharacterValidator: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function PasswordValidator(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    let password = control.value.toString();
    const regex = /[$-/:-?{-~!"^_@`\[\]]/g;
    const lowerLetters = /[a-z]+/.test(password);
    const upperLetters = /[A-Z]+/.test(password);
    const numbers = /[0-9]+/.test(password);
    const symbols = regex.test(password);

    if (password.length < 6) {
      return { PasswordValidator: true, minLength: true };
    }
    else if (password.length > 32) {
      return { PasswordValidator: true, maxLength: true };
    }
    else if (!lowerLetters) {
      return { PasswordValidator: true, lowerCase: true };
    }
    else if (!upperLetters) {
      return { PasswordValidator: true, upperCase: true };
    }
    else if (!numbers) {
      return { PasswordValidator: true, numbers: true };
    }
    else if (!symbols) {
      return { PasswordValidator: true, symbols: true };
    }
    else {
      return null;
    }
  } else {
    return null;
  }
}
export function PasswordValidation(password: string) {
  const regex = /[$-/:-?{-~!"^_@`\[\]]/g;
  const lowerLetters = /[a-z]+/.test(password);
  const upperLetters = /[A-Z]+/.test(password);
  const numbers = /[0-9]+/.test(password);
  const symbols = regex.test(password);

  if (
    password.length >= 6 &&
    password.length < 32 &&
    lowerLetters &&
    upperLetters &&
    numbers &&
    symbols
  ) {
    return true;
  } else {
    return false;
  }
}

export function OnlyPunjabi(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[\u0A00-\u0A7F ]+$/)) {      
      return { OnlyPunjabi: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function PanCard(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$/)) {      
      return { PanCard: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function NumWithoutDecimal(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^\+?[0-9]*$/)) {      
      return { NumWithoutDecimal: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function PunjabiMixed(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[\u0A00-\u0A7F \s\b\!\@\#\$\/ \%\&\* \(\)\,\.\? \"\:\-\{\}\|0-9]+$/)) {      
      return { PunjabiMixed: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function EnglishPunjabiOnly(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z\s\b \u0A00-\u0A7F]+$/)) {      
      return { EnglishPunjabiOnly: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function EnglishPunjabiWithSpecialCharaterForAddress(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z0-9\*/\-#,. \s\b \u0A00-\u0A7F]+$/)) {      
      return { EnglishPunjabiWithSpecialCharaterForAddress: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function EnglishWithSpecialCharaterForAddress(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z0-9\*/\-#,. ]*$/)) {      
      return { EnglishWithSpecialCharaterForAddress: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function EnglishMixed(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z0-9\s\b\!\@\#\$\%\&\*\(\)\,\.\?\"\:\{\}\|\-\/]+$/)) {      
      return { EnglishMixed: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function EnglishAddress(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z0-9\s\b/-]+$/)) {      
      return { EnglishAddress: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}

export function PunjabiAddress(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[\u0A00-\u0A7F \s\b 0-9 \-\/]+$/)) {      
      return { PunjabiAddress: true };
    }
    // if (!control.value.toString().match(/^[\u0A00-\u0A7F \s\b\$\/ \& \(\)\,\.\? \-\{\}\|0-9]+$/)) {      
    //   return { PunjabiAddress: true };
    // }
    
    else {
      return null;
    }
  } else {
    return null;
  }
} 
export function PassportNo(
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[A-PR-WYa-pr-wy][1-9]\d\s?\d{4}[1-9]$/)) {      
      return { PassportNo: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
} 

export function VoterID (
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[a-zA-Z]{3}[0-9]{7}?$/)) {      
      return { VoterID: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
} 
export function AadhaarEnrolmentNumber (
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^\d{4}\/\d{5}\/\d{5}$/)) {      
      return { EnrolmentNumber: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function NumOnly (
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[0-9]*$/)) {      
      return { NumOnly: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
 
export function Aadhaar (
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match(/^[1-9]\d{11}$/)) {      
      return { Aadhaar: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function SocialSecurityNumber (
  control: AbstractControl
): ValidationErrors | null {
  if (control.value) {
    if (!control.value.toString().match( /^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$/) ) {      
      return { SocialSecurityNumber: true };
    } else {
      return null;
    }
  } else {
    return null;
  }
}


export function FormErrorMessage(formGroup: FormGroup, control: string) {
  let controlValue = formGroup.get(control).errors;
  if (controlValue) {
    if (controlValue.required) {
      return 'This field is required'
    }
    else if (controlValue.minlength) {
      return 'Please enter at least ' + controlValue.minlength.requiredLength + ' characters';
    }
    else if (controlValue.maxlength) {
      return 'Please enter not more than  ' + controlValue.maxlength.requiredLength + ' characters';
    } 
    else if (controlValue.UrlValidator) {
      return 'Please enter valid url'
    }
    // else if (controlValue.MobileValidator) {
    //   return 'Please enter valid mobile number'
    // }
    else if (controlValue.mobile) {
      return 'Please enter valid mobile number'
    }
    
    else if (controlValue.PassportNo) {
      return 'Please enter valid passport number'
    }
    
    else if (controlValue.AlphaValidator) {
      return 'Please enter only english alphabets'
    }
    else if (controlValue.NumericValidator) {
      return 'Please enter only number'
    }
    else if (controlValue.DecimalValidator) {
      return 'Please enter only number or decimal'
    }
    else if (controlValue.AlphaNumericValidator) {
      return 'Please enter only alphabets and numbers'
    }
    else if (controlValue.AllowedCharacterValidator) {
      return "Please use only '$-/:-{-~!\"^_`\[\]' special characters";
    }
    else if (controlValue.PasswordValidator) {
      return 'Password must be between 6 - 32 character, Contains 1 Uppercase 1 Lowercase 1 Number & 1 Special character';
    }
    else if (controlValue.OnlyPunjabi) {
      return 'Only punjabi is allowed';
    }
    else if (controlValue.PanCard) {
      return 'Please enter a valid PAN number';
    }
    else if (controlValue.NumWithoutDecimal) {
      return 'Please enter whole number without decimal';
    }
    else if (controlValue.PunjabiMixed) {
      return 'Only punjabi, numbers and special characters [ ! @ # $ % & * ( ) , . ? " : { } | - /] are allowed';
    }
    else if (controlValue.EnglishPunjabiOnly) {
      return 'Only english and punjabi is allowed';
    }
    else if (controlValue.EnglishMixed) {
      return 'Only english, numbers and special characters [ ! @ # $ % & * ( ) , . ? " : { } | - /] are allowed';
    }
    // else if (controlValue.EmailValidator) {
    //   return 'Please enter a valid email address';
    // }
    else if (controlValue.email) {
      return 'Please enter a valid email address';
    }
    else if (controlValue.EnglishAddress) {
      return 'Only english, numbers and special characters [- /] are allowed.';
    }
    else if (controlValue.PunjabiAddress) {
      return 'Only punjabi, numbers and special characters [- /] are allowed.';
     // return 'Only Punjabi is allowed with special charcters other than (@,!,^,#) in Address';
    }
    else if (controlValue.VoterID) {
      return 'Invalid voter id.';
    }
    else if (controlValue.EnrolmentNumber) {
      return 'Only "/",alphabets and numbers are allowed.';
    }
    else if (controlValue.NumOnly) {
      return 'Only numerics are allowed.';
    }
    else if (controlValue.Aadhaar) {
      return 'Invalid aadhaar number.';
    }
    else if (controlValue.SocialSecurityNumber) {
      return 'Please enter a Social Security Number.';
    }
    else {
      return controlValue;
    }
  }
}
