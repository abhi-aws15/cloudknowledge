import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AppsettingsService } from 'src/app/config/appsettings.service';
import { ConfigService } from 'src/app/config/config.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonservicesService } from 'src/app/services/commonservices.service';
import { AlphaNumericValidator, EmailValidator, FormErrorMessage } from 'src/app/services/custom.validators';


@Component({
  selector: 'app-compulsorymarriage',
  templateUrl: './compulsorymarriage.component.html',
  styleUrls: ['./compulsorymarriage.component.css']
})
export class CompulsorymarriageComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private _appSettings: AppsettingsService,
      private _ConfigService: ConfigService,
      private _notification: NotificationService,
      private _commonService: CommonservicesService) {
  }

  token: string;
  private sub: any;
  // public step1: any;
  // public BeneficiaryFirstName = "";
  public isProcessing: boolean;
  public isSubmitted: boolean;
  public step1: FormGroup;


public userForm = new FormGroup({});

  // public userForm = new FormGroup({
  //   PersonalInformation: new FormGroup({
  //     BeneficiaryFirstName: new FormControl(null, Validators.required),
  //     LabhpatriName: new FormControl(null, Validators.required),
  //     BeneficiaryMiddleName: new FormControl(null, Validators.required)
  //   }),
  //   // ContactDetails: new FormGroup({
  //   //   MobileNo: new FormControl(null, Validators.required)
  //   // }),
  // });
  Onstep1(){
    this.isProcessing = true;
    this.step1 = new FormGroup({
    Salutation: new FormControl(null, Validators.required),
     BeneficiaryFirstName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(100)]),
    BeneficiaryFirstNamePunjabi: new FormControl(null, Validators.required),
    BeneficiaryMiddleName: new FormControl(null, Validators.required),
    BeneficiaryMiddleNamePunjabi: new FormControl(null, Validators.required),
    BeneficiaryLastName: new FormControl(null, Validators.required),
    BeneficiaryLastNamePunjabi: new FormControl(null, Validators.required),
    FatherFirstName: new FormControl(null, Validators.required),
    FatherFirstNamePunjabi: new FormControl(null, Validators.required),
    FatherMiddleName: new FormControl(null, Validators.required),
    FatherMiddleNamePunjabi: new FormControl(null, Validators.required),
    FatherLastName: new FormControl(null, Validators.required),
    FatherLastNamePunjabi: new FormControl(null, Validators.required),
    MotherFirstName: new FormControl(null, Validators.required),
    MotherFirstNamePunjabi: new FormControl(null, Validators.required),
    MotherMiddleName: new FormControl(null, Validators.required),
    MotherMiddleNamePunjabi: new FormControl(null, Validators.required),
    MotherLastName: new FormControl(null, Validators.required),
    MotherLastNamePunjabi: new FormControl(null, Validators.required),
    Gender: new FormControl(null, Validators.required),
    DateOfBirth: new FormControl(null, [Validators.required]),
    AgeofBeneficiary: new FormControl(null, [Validators.required]),
    PlaceofBirth: new FormControl(null, [Validators.required]),
    MaritalStatus: new FormControl(null, [Validators.required]),
    VoterIdCardNumber: new FormControl(null, [Validators.required]),
    AadhaarNumber: new FormControl(null, [Validators.required]),
    AadhaarEnrollmentNumber: new FormControl(null, [Validators.required]),
    BPLCardNumber: new FormControl(null, [Validators.required]),
  });
}

// tslint:disable-next-line: typedef
getErrorMessageStep1(control: string) {
  if (this.isProcessing){
    this.isProcessing = false;
    console.log(this.step1.value);
    return FormErrorMessage(this.step1, control); }
}

  ngOnInit(): void {
    this.sub = this.route.params.subscribe(params => {
      const token = params.token; // (+) converts string 'token' to a number
      // tslint:disable-next-line: triple-equals
      if (token != null || token != ''){
        let url = this._appSettings.eSewaURL;
        const ValidateToken = this._appSettings.ValidateToken;
        url = url + ValidateToken + token;

        this._ConfigService.getWithoutHeader(url)
        .subscribe(response => {
          this._notification.responseHandler(response);
          if (response['response'] == 1){
            window.localStorage.setItem('token', response['data'][0]['Token']);
            window.localStorage.setItem('session', response['data'][0]['Session']);
            this._commonService.BindMenu();
          }
          else {
            // window.localStorage.clear();
            // window.sessionStorage.clear();
            // window.location.href = environment.eSewaURL;
          }
        },
        err => {
          console.log('status code--->'+ err.status);
        });
        // In a real app: dispatch action to load the details here.
        }
        else{
          // window.localStorage.clear();
          // window.sessionStorage.clear();
          // window.location.href = environment.eSewaURL;
        }
   });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  // submit() {
  //   //console.log(this.userForm.value);
  // }
// submit
submitApplication() {
  this.isSubmitted = true;
  if (this.userForm.valid) {
    try {

      const formData = {
        categoryId: this.step1.get('BeneficiaryFirstName').value
        // info: {
        //   quantity: this.addUpdateProductForm.get('productQuantity').value,
        //   color: this.addUpdateProductForm.get('productColor').value,
        //   description: this.addUpdateProductForm.get('productDescription').value,
        // }
      };
      console.log(this.userForm.value);

    } catch (err) {
      this.isProcessing = false;
    }
  }
}
// end of submit
}



