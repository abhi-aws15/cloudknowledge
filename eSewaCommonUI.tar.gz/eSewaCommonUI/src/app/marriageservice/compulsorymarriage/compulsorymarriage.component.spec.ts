import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompulsorymarriageComponent } from './compulsorymarriage.component';

describe('CompulsorymarriageComponent', () => {
  let component: CompulsorymarriageComponent;
  let fixture: ComponentFixture<CompulsorymarriageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompulsorymarriageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompulsorymarriageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
