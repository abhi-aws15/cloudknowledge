import { Component, OnInit,ElementRef,  Renderer2, ViewChild, Inject,LOCALE_ID } from '@angular/core';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DatePipe, formatDate } from '@angular/common';


// Import common services
import { AppsettingsService } from 'src/app/config/appsettings.service';
import { ConfigService } from 'src/app/config/config.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonservicesService } from 'src/app/services/commonservices.service';
import { AlphaNumericValidator, SocialSecurityNumber, EnglishPunjabiWithSpecialCharaterForAddress, EnglishWithSpecialCharaterForAddress, AadhaarEnrolmentNumber, mobile, email, AlphaValidator, FormErrorMessage, OnlyPunjabi, VoterID, Aadhaar, EnglishAddress, PunjabiAddress, NumericValidator } from 'src/app/services/custom.validators';
import { environment } from 'src/environments/environment';
import { LoaderService } from 'src/app/loader.service';
import { EncryptiondecryptionserviceService } from 'src/app/services/encryptiondecryptionservice.service';
import { NgxSpinnerService } from "ngx-spinner";

// Import Models
// import { Commonmodel, ApplicationSubmitModel } from 'src/app/models/commonmodel';

import * as _moment from 'moment';
import { Moment } from 'moment';
import * as _ from 'lodash';
const moment = _moment;

@Component({
  selector: 'app-marriageabilitycertificate',
  templateUrl: './marriageabilitycertificate.component.html',
  styleUrls: ['./marriageabilitycertificate.component.css']
})
export class MarriageabilitycertificateComponent implements OnInit {

  //Get route parameters
  token: string;
  action: string;
  citizenRefCode: string;
  applicationID: string;
  minDate: Date;
  maxDate: Date;
  todayDate: Date;

  private sub: any;
  public redirect :any;
  public userID :any;
  public responseData :any;
  public districtList :[];
  public currentdistrictList :[];
  public processingdistrictList :[];
  public tehsilList: [];
  public currenttehsilList: [];
  public processingtehsilList: [];
  public processingOfficesList:[];
  public villageList: [];
  public currentvillageList: [];
  public maritalstatuslist: [];
  public relationlist: [];
  public eSewaURL: any;
  public PostGreMasterAPI: any;
  public MarriageServicesAPI: any;
  public PermanentRegion: boolean;
  public ProcessingRegion: boolean;
  public CurrentRegion: boolean;
  public citizenID: string;
  public citizenData: [];
  public citizenAddress : [];
  public processingOfficeTehsil : [];
  public processingDistricts: [];
  public service_data : any;
  public response_data : any;
  public isShownSocialSecurityNumber : boolean = false;
  public CurrentIsOutOfState : boolean = true;
  public PermanenIsOutOfState : boolean = true;
  public Maritalstatus : boolean = false;
  public CitizenResidingOutsideOfIndia : boolean = false;
  public IsCitizenIsNRI : boolean = false;
  public button_text: string = 'Submit';  
  public captures: Array<any>;
  pipe = new DatePipe('en-US');
  public img : string;
  public dobstatus : boolean = true;

  district_id: string;

  isLinear = false;
  isStep1Next=false;
  isStep2Next=false;
  isStep3Next=false;
  isStep4Next=false;

  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  fourthFormGroup: FormGroup;

  public isProcessing: boolean;
  @ViewChild('video', { static: true }) videoElement: ElementRef;
  @ViewChild('canvas', { static: true }) canvas: ElementRef;
  @ViewChild('canvas1', { static: true }) canvas1: ElementRef;

    videoWidth = 0;
    videoHeight = 0;
    constraints = {
        video: {
            facingMode: "environment",
            width: { ideal: 4096 },
            height: { ideal: 2160 }
        }
    };
  constructor(private _formBuilder: FormBuilder,
    private renderer: Renderer2,
    private route: ActivatedRoute, 
    private _appSettings: AppsettingsService, 
    private _ConfigService: ConfigService,
    private _notification: NotificationService,
    private _commonService: CommonservicesService,
    //private loaderService: LoaderService,
    private _encdecrService: EncryptiondecryptionserviceService,
    private loaderService: NgxSpinnerService,
    @Inject(LOCALE_ID) private locale: string) {
      this.captures = [];
  }

  ngOnInit() {
    this.loaderService.show();
    this.sub = this.route.params.subscribe(params => {
      this.token = params['token']; // (+) converts string 'token' to a number      
      this.action = params['action'];
      if(this.action === 'resubmit'){
        this.applicationID = params['applicationID'];
        this.button_text = 'Update';
      }
      else{
        this.citizenRefCode = params['userID']; 
      }
    });
  
    if(window.localStorage.getItem("TokenID")=='' || window.localStorage.getItem("TokenID")== null || window.localStorage.getItem("TokenID")== undefined ){
      this.ValidateToken(1);
    }
    else{
      if (window.localStorage.getItem("TokenID") == this.token) {
        this.ValidateToken(0);
      }
      else{        
        window.localStorage.clear();
        this.ValidateToken(1);
      }
    }

    this.firstFormGroup = this._formBuilder.group({     
      citizenRefCode: new FormControl(null),
      canvas:  new FormControl(null, Validators.required),
      salutation: new FormControl(null, Validators.required),
      first_name: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      first_name_punjabi: new FormControl(null, [Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      middle_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      middle_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      last_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      last_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),

      father_first_name: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      father_first_name_punjabi: new FormControl(null,[Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      father_middle_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      father_middle_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      father_last_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      father_last_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),

      mother_first_name: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      mother_first_name_punjabi: new FormControl(null,[Validators.required,OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      mother_middle_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      mother_middle_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      mother_last_name: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      mother_last_name_punjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),

      gender: new FormControl(null, Validators.required),
      date_of_birth: new FormControl(null, Validators.required),
      age: new FormControl({ value : null, disabled: true }, [Validators.required]),
      months: new FormControl({ value : null, disabled: true }, [Validators.required]),
      place_of_birth: new FormControl(null, [AlphaValidator, Validators.required, Validators.minLength(2), Validators.maxLength(50)]),
      marital_status: new FormControl(null,[Validators.required]),
      SpouseName: new FormControl(null, [AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      SpouseNameinPunjabi: new FormControl(null, [OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),
      VoterIdCardNumber: new FormControl(null, [VoterID]),
      AadhaarNumber: new FormControl(null, [Aadhaar]),
      AadhaarEnrollmentNumber: new FormControl(null, [AadhaarEnrolmentNumber, Validators.minLength(16), Validators.maxLength(16)]),
      BPLCardNumber: new FormControl(null)
    });
      
    this.secondFormGroup = this._formBuilder.group({
      // secondCtrl: ['', Validators.required]
      EmailID: new FormControl(null, [Validators.minLength(5), Validators.maxLength(100), Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]),
      PhoneNo: new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.minLength(8), Validators.maxLength(15)]),
      MobileNo: new FormControl(null, [Validators.required, mobile, Validators.minLength(10), Validators.maxLength(10)]),
      
      address_type: new FormControl(null),

      // Permanent Address
      //AddressIsOutOfState: new FormControl({ value : null, disabled: true }),
      address_line_1: new FormControl(null, [Validators.required, EnglishWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]),
      //address_line_2: new FormControl(null, [EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      //address_line_3: new FormControl(null, [EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      outofstate_address: new FormControl(null, [Validators.minLength(2), EnglishWithSpecialCharaterForAddress, Validators.maxLength(250)]),
      outofstate_address_pb: new FormControl(null, [PunjabiAddress, Validators.minLength(2), Validators.maxLength(250)]),
      region: new FormControl('Urban', Validators.required),
      stateID: new FormControl(null, Validators.required,),
      districtID: new FormControl(null, Validators.required),
      tehsilID: new FormControl(null, Validators.required),
      PermanentVillage: new FormControl(null),
      pincode: new FormControl(null, [NumericValidator, Validators.minLength(6)]),
      
      Currentaddress_is_same_as_permanentaddress : new FormControl(false),
      // Current Address
      CurrentAddressIsOutOfState: new FormControl(false),
      CurrentAddressLine1: new FormControl(null, [Validators.required, EnglishWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]),
      //CurrentAddressLine2: new FormControl(null, [EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      //CurrentAddressLine3: new FormControl(null, [EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      Currentoutofstate_address: new FormControl(null, [EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      Currentoutofstate_address_pb: new FormControl(null, [PunjabiAddress, Validators.minLength(2), Validators.maxLength(250)]),
      CurrentRegion: new FormControl('Urban',Validators.required),
      CurrentstateID: new FormControl(null,Validators.required),
      CurrentdistrictID: new FormControl(null,Validators.required),
      CurrenttehsilID: new FormControl(null,Validators.required),
      CurrentVillage: new FormControl(null),
      Currentpincode: new FormControl(null, [NumericValidator, Validators.minLength(6)]),
    });

    this.thirdFormGroup = this._formBuilder.group({
      ApplicentRelationIDWithBeneficary: new FormControl(null,Validators.required),
      ApplicantName: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      ApplicantNameInPunjabi: new FormControl(null,[Validators.required, OnlyPunjabi]),
      ApplicantAddress: new FormControl(null, [Validators.required, EnglishPunjabiWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]),
      ApplicantFatherName: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      ApplicantFatherNameInPunjabi: new FormControl(null, [Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]),

      DoesSocialSecurityNumberExists: new FormControl('No',Validators.required),
      SocialSecurityNumber: new FormControl(null, [Validators.minLength(9), Validators.maxLength(15)]),
      CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry:  new FormControl(null, [Validators.required, EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]),
      CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi:  new FormControl(null,[Validators.required, PunjabiAddress, Validators.minLength(2), Validators.maxLength(250)]),

      DateTillUnmarried: new FormControl(null,Validators.required),
      ServiceDetailPlaceOfBirth: new FormControl(null, [Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]),
      ServiceDetailDateOfBirth: new FormControl(null,Validators.required),
      IsCitizenResidingOutsideOfIndia: new FormControl(true),
      FromDate: new FormControl(null),
      ToDate: new FormControl(null),
      CitizenIsNRI : new FormControl(true),
      CurrentAddressInIndia: new FormControl(null, [EnglishWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]),
      CurrentAddressInIndiaInPunjabi : new FormControl(null, [PunjabiAddress, Validators.minLength(2), Validators.maxLength(250)])
    });
    
    this.fourthFormGroup = this._formBuilder.group({
      // Processing Details
      ProcessingRegion: new FormControl('Urban', Validators.required),
      ProcessingdistrictID: new FormControl(null, Validators.required),
      ProcessingtehsilID: new FormControl(null, Validators.required),
      ProcessingofficeID: new FormControl(null),      
      acceptinformation : new FormControl(false),
    });
    
    if(this.action === 'review'){      
      this.firstFormGroup.disable();      
      this.secondFormGroup.disable();
      this.thirdFormGroup.disable();
    }
    else if(this.action === 'resubmit'){
      this.ChangeCitizenResidingOutsideOfIndia(true);
      this.ChangeCitizenIsNRI(true);
    }
    else{
      this.ChangeCitizenResidingOutsideOfIndia(true);
      this.ChangeCitizenIsNRI(true);
    }
  }
  ValidateToken(redirect){
    // window.localStorage.getItem("token")
     if(this.token != null || this.token !=""){
       var url = this._appSettings.eSewaURL;
       var ValidateToken = this._appSettings.ValidateToken;
       url = url + ValidateToken + this.token;
       
       this._ConfigService.getWithoutHeader(url)
       .subscribe(response => {
         this._notification.responseHandler(response);
         if(response["response"] == 1){
           if(redirect === 1){
              window.localStorage.clear();
              window.localStorage.setItem("TokenID", this.token);
              window.localStorage.setItem("token", this._encdecrService.Encrypt(response["data"][0]["Token"]));
              window.localStorage.setItem("session", this._encdecrService.Encrypt(response["data"][0]["Session"]));
              window.localStorage.setItem("user_type", response["data"][0]["user_type"]);
              window.localStorage.setItem("f_name", response["data"][0]["f_name"]);
              window.localStorage.setItem("desig_name", response["data"][0]["desig_name"]);
              window.location.reload();
           }
           else{
              this.PostGreMasterAPI = this._appSettings.PostGreMasterAPI;
              this.eSewaURL = this._appSettings.eSewaURL;
              this.MarriageServicesAPI = this._appSettings.MarriageServicesAPI;
              this.responseData = response["data"][0];
              this._commonService.BindMenu();
              this.userID = this.responseData.userID;
              this.fetchAllMasters();
              this.startCamera();
              this.isProcessing=true;
           }
         }
         else {
            window.localStorage.clear();
            this._commonService.BindMenu();
           // window.sessionStorage.clear();
           // window.location.href = environment.eSewaURL;
         }
       },
       err=>{
         console.log("status code--->"+err.status)
       });
       // In a real app: dispatch action to load the details here.
       }
       else{
         // window.localStorage.clear();
         // window.sessionStorage.clear();
         // window.location.href = environment.eSewaURL;
       }
  }
  fetchAllMasters(){
    this.fetchDistrict();
    this.fetchProcessingDistricts();
    this.fetchmaritalstatus();
    if(this.action === 'submit' || this.action === 'review'){
        this.DecryptCitizenID();
    }
    else{
      this.fetchApplicationDetail();
    }
    this.fetchRelation();
  }
  bindDynamicCalendar(){
    const currentYear = new Date().getFullYear();
    const currentDate = new Date().getDate();
    const currentMonth = new Date().getMonth();
    this.todayDate = new Date();

    this.minDate = new Date(currentYear - 100, 0, 1);
    if(this.firstFormGroup.get("gender").value === 'Female'){
      this.maxDate = new Date(currentYear - 18, currentMonth, currentDate);
    }
    else{
      this.maxDate = new Date(currentYear - 21, currentMonth, currentDate);
    }
  }
  calculateAge(event){
    const m: Moment = event.value;
    if(m){
      var startDate = moment(event.value).format('yyyy-MM');
      var endDate = moment(new Date()).format('yyyy-MM');

      let b_day = event.value.getDate();
      let b_month = event.value.getMonth() + 1;
      let b_year = event.value.getFullYear();

      let c_day = new Date().getDate();
      let c_month = new Date().getMonth() + 1;
      let c_year = new Date().getFullYear();
      let ageDetails=this.findAge(c_day, c_month, c_year, b_day, b_month, b_year);
      
   
      if(ageDetails.years < 18 && this.firstFormGroup.get("gender").value === 'Female'){
        this._notification.info("Applicant not eligible for marriageablility certificate!","info");
        this.firstFormGroup.get("age").setValue(null);
        this.firstFormGroup.get('age').setValidators([Validators.required]);

        this.firstFormGroup.get("months").setValue(null);
        this.firstFormGroup.get('months').setValidators([Validators.required]);
        window.location.href = environment.eSewaURL + "/home";
      }
      else if(ageDetails.years < 21 && this.firstFormGroup.get("gender").value === 'Male'){
        this._notification.info("Applicant not eligible for marriageablility certificate!","info");
        this.firstFormGroup.get("age").setValue(null);     
        this.firstFormGroup.get('age').setValidators([Validators.required]);

        this.firstFormGroup.get("months").setValue(null);     
        this.firstFormGroup.get('months').setValidators([Validators.required]); 
        window.location.href = environment.eSewaURL + "/home";
      }
      this.firstFormGroup.get("age").setValue(ageDetails.years);
      this.firstFormGroup.get("months").setValue(ageDetails.months);

      this.firstFormGroup.get('age').updateValueAndValidity();
      this.firstFormGroup.get('months').updateValueAndValidity();
    }
  }
  findAge(current_date, current_month, current_year, birth_date, birth_month, birth_year) {

    if (birth_date > current_date) {
      current_date = current_date + this.daysInMonth(current_month - 1, current_year);
      current_month = current_month - 1;
    }
  
    if (birth_month > current_month) {
      current_year = current_year - 1;
      current_month = current_month + 12;
    }
    
    var calculated_date = current_date - birth_date;
    var calculated_month = current_month - birth_month;
    var calculated_year = current_year - birth_year;
  
    let calAge={
      years:calculated_year,
      months:calculated_month,
      days:calculated_date
    }
   return (calAge)
  }
  daysInMonth(month, year) {
    if (month < 0)
      return 31;
    return new Date(year, month, 0).getDate();
  }
  selectPermanenRegion(event){
    this.loaderService.show();
    if(event == 'Rural'){      
      this.PermanentRegion = true;
    }
    else{
      this.PermanentRegion = false;
    }
    this.loaderService.hide();
  }
  selectCurrentRegion(event){
    if(event == 'Rural'){      
      this.CurrentRegion = true;
    }
    else{
      this.CurrentRegion = false;
    }
  }
  // Get Application Detail By Application ID
  fetchApplicationDetail(){
    var url = this.MarriageServicesAPI;
    var GetApplicationDetail = this._appSettings.GetApplicationDetail;
    url = url + GetApplicationDetail + this.applicationID;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1) {
        this.response_data = response["data"];
        this.service_data = response["data"]["service_data"];
        this.citizenRefCode = this.service_data['citizenRefCode'];
        this.firstFormGroup.patchValue({
            salutation : this.service_data['salutation'],
            first_name : this.service_data['beneficiary_firstName'],
            first_name_punjabi : this.service_data['beneficiary_firstName_pb'],
            middle_name : this.service_data['beneficiary_middleName'],
            middle_name_punjabi : this.service_data['beneficiary_middleName_pb'],
            last_name : this.service_data['beneficiary_lastName'],
            last_name_punjabi : this.service_data['beneficiary_lastName_pb'],

            father_first_name: this.service_data['beneficiary_fathersFirstName'],
            father_first_name_punjabi: this.service_data['beneficiary_fathersFirstName_pb'],
            father_middle_name: this.service_data['beneficiary_fathersMiddleName'],
            father_middle_name_punjabi: this.service_data['beneficiary_fathersMiddleName_pb'],
            father_last_name: this.service_data['beneficiary_fathersLastName'],
            father_last_name_punjabi: this.service_data['beneficiary_fathersLastName_pb'],

            mother_first_name: this.service_data['beneficiary_mothersFirstName'],
            mother_first_name_punjabi: this.service_data['beneficiary_mothersFirstName_pb'],
            mother_middle_name: this.service_data['beneficiary_mothersMiddleName'],
            mother_middle_name_punjabi: this.service_data['beneficiary_mothersMiddleName_pb'],
            mother_last_name: this.service_data['beneficiary_mothersLastName'],
            mother_last_name_punjabi: this.service_data['beneficiary_mothersLastName_pb'],

            gender: this.service_data['beneficiary_gender'],
            date_of_birth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY((this.service_data['beneficiary_dob'])))),
            age: this. service_data['beneficiary_age'],
            months: this. service_data['beneficiary_months'],
            place_of_birth: this.service_data['beneficiary_placeOfBirth'],
            marital_status: this.service_data['beneficiary_maritalStatus']['statusid'],
            SpouseName: this.service_data['beneficiary_spouseName'],
            SpouseNameinPunjabi: this.service_data['beneficiary_spouseName_pb'],
            VoterIdCardNumber: this.service_data['beneficiary_voterId'],
            AadhaarNumber: this.service_data['beneficiary_aadhaar'],
            AadhaarEnrollmentNumber: this.service_data['beneficiary_aadhaarEnrollment'],
            BPLCardNumber: this.service_data['beneficiary_bplNumber'],
            EmailID: this.service_data['beneficiary_email']
        });
        //this.calculateAge(this.service_data['beneficiary_dob']);
        this.Changemaritalstatus(this.service_data['beneficiary_maritalStatus']['statusid']);  
        
        // Disable first Form Group fields
        this.firstFormGroup.get("gender").disable();
        this.firstFormGroup.get("date_of_birth").disable();
        this.dobstatus = false;

        this.secondFormGroup.patchValue({
          EmailID: this.service_data['beneficiary_email'],
          PhoneNo: this.service_data['beneficiary_phoneNo'],
          MobileNo: this.service_data['beneficiary_mobileNo'],
          
          address_type: this.service_data['address_type'],

          // Permanent Address
          //AddressIsOutOfState: this.service_data['permanent_address']['address_isOutofState'],
          address_line_1: this.service_data['permanent_address']['address_line_1'],
          // address_line_2: this.service_data['permanent_address']['address_line_2'],
          // address_line_3: this.service_data['permanent_address']['address_line_3'],
          outofstate_address: this.service_data['permanent_address']['outofstate_address'],
          outofstate_address_pb: this.service_data['permanent_address']['outofstate_address_pb'],
          region: this.service_data['permanent_address']['address_region'],
          stateID: "1",
          districtID: this.service_data['permanent_address']['address_district']['district_id'],
          pincode: this.service_data['permanent_address']['address_pincode'],
          
          // Current Address
          CurrentAddressIsOutOfState: this.service_data['current_address']['address_isOutofState'],
          CurrentAddressLine1: this.service_data['current_address']['address_line_1'],
          // CurrentAddressLine2: this.service_data['current_address']['address_line_2'],
          // CurrentAddressLine3: this.service_data['current_address']['address_line_3'],
          Currentoutofstate_address: this.service_data['current_address']['outofstate_address'],
          Currentoutofstate_address_pb: this.service_data['current_address']['outofstate_address_pb'],
          CurrentRegion: this.service_data['current_address']['address_region'],
          CurrentstateID: "1",
          CurrentdistrictID: this.service_data['current_address']['address_district']['district_id'],
          Currentpincode: this.service_data['current_address']['address_pincode'],
        });

        // Disable Parmanent Address
        this.secondFormGroup.get("address_line_1").disable();
        this.secondFormGroup.get("region").disable();
        this.secondFormGroup.get("stateID").disable();
        this.secondFormGroup.get("districtID").disable();
        this.secondFormGroup.get("tehsilID").disable();
        this.secondFormGroup.get("PermanentVillage").disable();
        this.secondFormGroup.get("pincode").disable();

        this.CurrentsetOutOfState(Boolean(JSON.parse(this.service_data['current_address']['address_isOutofState'].toLowerCase())));

        // if(this.service_data['permanent_address']['address_isOutofState'] === "True")
        // {
        //   this.PermanenIsOutOfState = false;
        //   this.secondFormGroup.get('CurrentAddressIsOutOfState').setValue(false);
        //   this.secondFormGroup.get('CurrentAddressIsOutOfState').disable();
        //   this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').disable();
        // }
        // else
        // {
        //   this.PermanenIsOutOfState = true;
        //   this.secondFormGroup.get('CurrentAddressIsOutOfState').setValue(true);
        //   this.secondFormGroup.get('CurrentAddressIsOutOfState').enable();
        //   this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').enable();
        // }

        if(Boolean(JSON.parse(this.service_data['current_address']['address_isOutofState'].toLowerCase())))
        {
          this.CurrentIsOutOfState = false;
          this.secondFormGroup.get('CurrentAddressIsOutOfState').setValue(true);
        }
        else
        {
          this.CurrentIsOutOfState = true;
          this.secondFormGroup.get('CurrentAddressIsOutOfState').setValue(false);
        }

        this.subDistricts(this.secondFormGroup.get("districtID").value);
        this.secondFormGroup.patchValue({
          tehsilID: this.service_data['permanent_address']['address_tehsil']['tehsil_id'],
        });
        this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
        this.secondFormGroup.patchValue({
          CurrenttehsilID: this.service_data['current_address']['address_tehsil']['tehsil_id'],
        });
        this.thirdFormGroup.patchValue({
          ApplicentRelationIDWithBeneficary: this.service_data['applyingforself'],
          ApplicantName: this.service_data['applicant_name'],
          ApplicantNameInPunjabi: this.service_data['applicant_name_pb'],
          ApplicantAddress: this.service_data['applicant_address'],
          ApplicantFatherName: this.service_data['applicant_fathername'],
          ApplicantFatherNameInPunjabi: this.service_data['applicant_fathername_pb'],
    
          DoesSocialSecurityNumberExists: this.service_data['doesSocialSecurityNumberExists'],
          SocialSecurityNumber: this.service_data['socialSecurityNumber'],
          CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry:  this.service_data['currentAddressOfProspectiveBrideOrBridegroomInForeignCountry'],
          CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi:  this.service_data['currentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi'],
          
          DateTillUnmarried: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY((this.service_data['dateTillUnmarried'])))),
          ServiceDetailPlaceOfBirth: this.service_data['serviceDetailPlaceOfBirth'],
          ServiceDetailDateOfBirth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY((this.service_data['serviceDetailDateOfBirth'])))),
          IsCitizenResidingOutsideOfIndia: (/true/i).test(this.service_data['isCitizenResidingOutsideOfIndia']),
          FromDate: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY((this.service_data['fromDate'])))),
          ToDate: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY((this.service_data['toDate'])))),
          CitizenIsNRI : (/true/i).test(this.service_data['citizenIsNRI']),
          CurrentAddressInIndia: this.service_data['currentAddressInIndia'],
          CurrentAddressInIndiaInPunjabi : this.service_data['currentAddressInIndiaInPunjabi']
        });
        debugger
        this.chooseSocialSecurityNumber();
        //this.checkApplicatentRelation(this.thirdFormGroup.get('ApplicentRelationIDWithBeneficary').value);
        this.selectPermanenRegion(this.service_data['permanent_address']['address_region']);
        this.selectCurrentRegion(this.service_data['current_address']['address_region']);
        //Fetch Villages
        if(this.service_data['permanent_address']['address_region'] === 'Rural'){
          this.fetchVillages(this.service_data['permanent_address']['address_tehsil']['tehsil_id']);
          this.secondFormGroup.patchValue({
            PermanentVillage: this.service_data['permanent_address']['address_village']['village_id'],
          });
        }
        if(this.service_data['current_address']['address_region'] === 'Rural'){
          this.fetchcurrentVillages(this.service_data['current_address']['address_tehsil']['tehsil_id']);
          this.secondFormGroup.patchValue({
            CurrentVillage: this.service_data['current_address']['address_village']['village_id'],
          });
        }
        //End Fetch Villages
        this.ChangeCitizenResidingOutsideOfIndia((/true/i).test(this.service_data['isCitizenResidingOutsideOfIndia']));
        this.ChangeCitizenIsNRI((/true/i).test(this.service_data['citizenIsNRI']));
        this.bindDynamicCalendar();
        //Fetch Processing Offices
        this.fourthFormGroup.patchValue({
          ProcessingRegion: this.service_data['processing_region'],
          ProcessingdistrictID: this.service_data['processing_district'].toString(),
          ProcessingtehsilID: this.service_data['processing_tehsil'].toString(),
          ProcessingofficeID: this.service_data['processing_office'].toString(),
        });
        this.fetchProcessingTehsilByDistrictID(this.service_data['processing_district']);        
        this.fourthFormGroup.get("ProcessingdistrictID").disable();
        this.fetchProcessingOfficeMasterByTehsilID(this.service_data['processing_tehsil']);
        //End Fetch Processing Offices

        this.isStep1Next=true;
        this.isStep2Next=true; 
        this.isStep3Next=true; 
        this.isStep4Next=true; 
      }
    });
  }
  // Address Detail : District, Sub Districts (Tehsil), Villages
  fetchDistrict(){
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchDistrict;
    url = url + fetchDistrict + 1;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.districtList = response["data"];
        this.currentdistrictList = response["data"];
        this.processingdistrictList = response["data"];
      }});
  }
  subDistricts(event){
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    this.loaderService.show();
    this._ConfigService.get(url)
    .subscribe(response => {
      this.loaderService.hide();
      if(response["response"] == 1){
        this.tehsilList = response["data"];
      }});
  }
  fetchVillages(event){
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    this.loaderService.show();
    this._ConfigService.get(url)
    .subscribe(response => {
      this.loaderService.hide();
      if(response["response"] == 1){
        this.villageList = response["data"];
      }});
  }
  currentsubDistricts(event){
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    this.loaderService.show();    
    this._ConfigService.get(url)
    .subscribe(response => {
      this.loaderService.hide();
      if(response["response"] == 1){
        this.currenttehsilList = response["data"];
      }});
  }
  fetchcurrentVillages(event){
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    this.loaderService.show();
    this._ConfigService.get(url)
    .subscribe(response => {
      this.loaderService.hide();
      if(response["response"] == 1){
        this.currentvillageList = response["data"];
      }});
  }
  // End Address Detail
  fetchmaritalstatus(){
    var url = this.MarriageServicesAPI;
    var fetchMaritalStatus = this._appSettings.fetchMaritalStatus;
    url = url + fetchMaritalStatus;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.maritalstatuslist = response["data"];
      }});
  }
  Changemaritalstatus(event){
    if(event == '1'){
      this.Maritalstatus = true;
      this.firstFormGroup.get('SpouseName').setValidators([Validators.required, AlphaValidator, Validators.minLength(2), Validators.maxLength(100)]);
      this.firstFormGroup.get('SpouseNameinPunjabi').setValidators([Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(100)]);
    }
    else{
      this.Maritalstatus = false;      
      this.firstFormGroup.get('SpouseName').setValidators(null);
      this.firstFormGroup.get('SpouseNameinPunjabi').setValidators(null);

      this.firstFormGroup.get('SpouseName').clearValidators();
      this.firstFormGroup.get('SpouseNameinPunjabi').clearValidators();
    }
    this.firstFormGroup.get('SpouseName').updateValueAndValidity();
    this.firstFormGroup.get('SpouseNameinPunjabi').updateValueAndValidity();
  }
  DecryptCitizenID(){
    var url = this.eSewaURL;
    var DecryptCitizenID = this._appSettings.DecryptCitizenID;
    url = url + DecryptCitizenID + this.citizenRefCode;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.citizenID = response["sys_message"];
        this.fetchCitizenProfile();
      }});
  }
  fetchCitizenProfile(){
    var data = {
      selectfrom : "user",
      selectby : "citizen_profile",
      selectionparam1 : this.citizenRefCode,
    }

    var url = this.eSewaURL;
    var fetchMasterData = this._appSettings.fetchMasterData;
    url = url + fetchMasterData;

    this.loaderService.show();
    this._ConfigService.post(url, data)
      .subscribe(response => {
        this.loaderService.hide();
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.citizenData = response["data"][0];
          this.patchFormValue(this.citizenData, this.firstFormGroup);
          this.Changemaritalstatus(this.firstFormGroup.get("marital_status").value);
          //alert(this.citizenData['date_of_birth']);
          this.firstFormGroup.patchValue({
            date_of_birth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.citizenData['date_of_birth']))
          });
          this.calculateAge(this.firstFormGroup.get("date_of_birth"));
          this.firstFormGroup.get("first_name").disable();
          this.firstFormGroup.get("middle_name").disable();
          this.firstFormGroup.get("last_name").disable();
          this.firstFormGroup.get("father_first_name").disable();
          this.firstFormGroup.get("father_middle_name").disable();
          this.firstFormGroup.get("father_last_name").disable();
          this.firstFormGroup.get("mother_first_name").disable();
          this.firstFormGroup.get("mother_middle_name").disable();
          this.firstFormGroup.get("mother_last_name").disable();
          this.firstFormGroup.get("gender").disable();
          this.firstFormGroup.get("marital_status").disable();
          this.firstFormGroup.get("SpouseName").disable();
          this.firstFormGroup.get("SpouseNameinPunjabi").disable();
          
          this.dobstatus = true;
          this.bindDynamicCalendar();
          if(this.firstFormGroup.get("marital_status").value == "1"){
            var SpouseName = this.citizenData["husband_first_name"] 
            + " " + this.citizenData["husband_middle_name"] + " "+ this.citizenData["husband_last_name"];
            this.firstFormGroup.get("SpouseName").setValue(SpouseName);
            
            var SpouseNamePunjabi = this.citizenData["husband_first_name_punjabi"] 
            + " " + this.citizenData["husband_middle_name_punjabi"] + " "+ this.citizenData["husband_last_name_punjabi"];
            this.firstFormGroup.get("SpouseNameinPunjabi").setValue(SpouseNamePunjabi);
          }
          
          this.fetchCitizenAddress();
        }
      });
  }
  fetchCitizenAddress(){
    var data = {
      selectfrom : "user",
      selectby : "profile_address",
      selectionparam1 : this.citizenRefCode,
    }

    var url = this.eSewaURL;
    var fetchMasterData = this._appSettings.fetchMasterData;
    url = url + fetchMasterData;

    this._ConfigService.post(url, data)
      .subscribe(response => {
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.citizenAddress = response["data"][0];
          this.patchFormValue(this.citizenAddress, this.secondFormGroup);
          this.secondFormGroup.get("MobileNo").setValue(this.citizenData["mobile_no"]);
          if(this.secondFormGroup.get("MobileNo").value != null || this.secondFormGroup.get("MobileNo").value != ""){
            this.secondFormGroup.get("MobileNo").disable();

          }
          this.secondFormGroup.get("EmailID").setValue(this.citizenData["EmailID"]);
          if(this.secondFormGroup.get("EmailID").value != null || this.secondFormGroup.get("EmailID").value != ""){
            this.secondFormGroup.get("EmailID").disable();
          }

          // Disable Parmanent Address
          this.secondFormGroup.get("address_line_1").disable();
          this.secondFormGroup.get("region").disable();
          this.secondFormGroup.get("stateID").disable();
          this.secondFormGroup.get("districtID").disable();
          this.secondFormGroup.get("tehsilID").disable();
          this.secondFormGroup.get("PermanentVillage").disable();
          this.secondFormGroup.get("pincode").disable();

          this.subDistricts(this.secondFormGroup.get("districtID").value);

          if(this.secondFormGroup.get("address_type").value === 'P'){
            this.secondFormGroup.get("CurrentAddressLine1").setValue(this.citizenAddress["address_line_1"]);
            // this.secondFormGroup.get("CurrentAddressLine2").setValue(this.citizenAddress["address_line_2"]);
            // this.secondFormGroup.get("CurrentAddressLine3").setValue(this.citizenAddress["address_line_3"]);
            this.secondFormGroup.get("CurrentRegion").setValue(this.citizenAddress["region"]);
            this.secondFormGroup.get("CurrentstateID").setValue(this.citizenAddress["stateID"]);
            this.secondFormGroup.get("CurrentdistrictID").setValue(this.citizenAddress["districtID"]);
            this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
            this.secondFormGroup.get("CurrenttehsilID").setValue(this.citizenAddress["tehsilID"]);
            this.secondFormGroup.get("Currentpincode").setValue(this.citizenAddress["pincode"]);
            if(this.citizenAddress["region"] == "Rural"){
              this.fetchVillages(this.citizenAddress["tehsilID"])
              this.secondFormGroup.get("PermanentVillage").setValue(this.citizenAddress["villageID"]);
              this.fetchcurrentVillages(this.citizenAddress["tehsilID"])
              this.secondFormGroup.get("CurrentVillage").setValue(this.citizenAddress["villageID"]);
            }
          }
          else{
            this.secondFormGroup.get("CurrentAddressLine1").setValue(null);
            // this.secondFormGroup.get("CurrentAddressLine2").setValue(null);
            // this.secondFormGroup.get("CurrentAddressLine3").setValue(null);
            this.secondFormGroup.get("CurrentRegion").setValue(null);
            this.secondFormGroup.get("CurrentstateID").setValue(null);
            this.secondFormGroup.get("CurrentdistrictID").setValue(null);
            this.secondFormGroup.get("CurrenttehsilID").setValue(null);
            this.secondFormGroup.get("Currentpincode").setValue(null);
          }
          this.selectPermanenRegion(this.secondFormGroup.get("region").value);
          this.selectCurrentRegion(this.secondFormGroup.get("CurrentRegion").value);

          //  Set processing district
          this.fourthFormGroup.get("ProcessingdistrictID").setValue(this.secondFormGroup.get("districtID").value);
          this.fourthFormGroup.get("ProcessingdistrictID").disable();
          this.fetchProcessingTehsilByDistrictID(this.secondFormGroup.get("districtID").value);
        }
      });

  }
  fetchRelation(){
    var url = this.MarriageServicesAPI;
    var fetchRelationMaster = this._appSettings.fetchRelationMaster;
    url = url + fetchRelationMaster;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.relationlist = response["data"].filter(item => item.relationid == 1 || item.relationid == 2 || item.relationid == 8 || item.relationid == 11 || item.relationid == 12 || item.relationid == 14);
      }});
  }
  chooseSocialSecurityNumber(){
    if(this.thirdFormGroup.get("DoesSocialSecurityNumberExists").value === 'Yes'){
      //Show field
      this.isShownSocialSecurityNumber = true;
      this.thirdFormGroup.get('SocialSecurityNumber').setValidators([Validators.required, SocialSecurityNumber, Validators.minLength(9), Validators.maxLength(15)])
    }
    else{
      //Hide field
      this.isShownSocialSecurityNumber = false;
      this.thirdFormGroup.get('SocialSecurityNumber').setValue(null);
      this.thirdFormGroup.get('SocialSecurityNumber').clearValidators();
    }
    
    this.thirdFormGroup.get('SocialSecurityNumber').updateValueAndValidity();
  }
  fromDateChange(event){
    const FromDate = _moment(event);
    const ToDate = _moment(this.thirdFormGroup.get("ToDate").value);
    if(ToDate != null){
      if(FromDate > ToDate)
      {
        //this.thirdFormGroup.get('FromDate').clearValidators();
      }
      else{
        this.thirdFormGroup.get("ToDate").setValue(null);
        this.thirdFormGroup.get('ToDate').setValidators(Validators.required);
      }
      this.thirdFormGroup.get("ToDate").updateValueAndValidity();
    }
  }
  toDateChange(event){
    const FromDate = _moment(this.thirdFormGroup.get("FromDate").value);
    const ToDate = _moment(event);
    if(FromDate != null){
      if(FromDate < ToDate)
      {
        this.thirdFormGroup.get('FromDate').clearValidators();
      }
      else{
        this.thirdFormGroup.get("ToDate").setValue(null);
        this.thirdFormGroup.get('ToDate').setValidators(Validators.required);
        this._notification.warning("Invalid date!","warning");
      }
      this.thirdFormGroup.get("ToDate").updateValueAndValidity();
    }
  }
  checkApplicatentRelation(event){
    this.loaderService.show();
    if(event === "11"){
      this.thirdFormGroup.get("ApplicantName").setValue(this.firstFormGroup.get("first_name").value
            + " " + this.firstFormGroup.get("middle_name").value + " " + this.firstFormGroup.get("last_name").value);

      this.thirdFormGroup.get("ApplicantNameInPunjabi").setValue(this.firstFormGroup.get("first_name_punjabi").value
            + " " + this.firstFormGroup.get("middle_name_punjabi").value + " " + this.firstFormGroup.get("last_name_punjabi").value);
      
      if(this.secondFormGroup.get("PermanentVillage").value != null &&
        this.secondFormGroup.get("PermanentVillage").value != undefined &&
        this.secondFormGroup.get("PermanentVillage").value !=""){
        this.thirdFormGroup.get("ApplicantAddress").setValue(this.secondFormGroup.get("address_line_1").value
        + ", " + _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_name
        + ", " + _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_name
        + ", " + _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_name);
      }
      else
      {
        this.thirdFormGroup.get("ApplicantAddress").setValue(this.secondFormGroup.get("address_line_1").value
        + ", " + _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_name
        + ", " + _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_name);
      }

      this.thirdFormGroup.get("ApplicantFatherName").setValue(this.firstFormGroup.get("father_first_name").value
            + " " + this.firstFormGroup.get("father_middle_name").value + " " + this.firstFormGroup.get("father_last_name").value);
      this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").setValue(this.firstFormGroup.get("father_first_name_punjabi").value
            + " " + this.firstFormGroup.get("father_middle_name_punjabi").value + " " + this.firstFormGroup.get("father_last_name_punjabi").value);

      //Disable field
      this.thirdFormGroup.get("ApplicantName").disable();
      this.thirdFormGroup.get("ApplicantNameInPunjabi").disable();
      this.thirdFormGroup.get("ApplicantAddress").disable();
      this.thirdFormGroup.get("ApplicantFatherName").disable();
      this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").disable();
    }
    else{
      this.thirdFormGroup.get("ApplicantName").setValue(null),
      this.thirdFormGroup.get("ApplicantNameInPunjabi").setValue(null),
      this.thirdFormGroup.get("ApplicantAddress").setValue(null),
      this.thirdFormGroup.get("ApplicantFatherName").setValue(null),
      this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").setValue(null),

      //Enable field
      this.thirdFormGroup.get("ApplicantName").enable();
      this.thirdFormGroup.get("ApplicantNameInPunjabi").enable();
      this.thirdFormGroup.get("ApplicantAddress").enable();
      this.thirdFormGroup.get("ApplicantFatherName").enable();
      this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").enable();
    }
    this.loaderService.hide();
  }
  patchFormValue(Data, formGroup: FormGroup) {
    let patchValues = {};
    Object.keys(formGroup.controls).forEach((key: any) => {
      patchValues[key] = Data[key];
    });
    formGroup.patchValue(patchValues);
  }
  convertToDate(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [mnth, day, date.getFullYear()].join("/");
  }
  startCamera() {
    if (!!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) {
        navigator.mediaDevices.getUserMedia(this.constraints).then(this.attachVideo.bind(this)).catch(this.handleError);
    } else {
      this._notification.warning("Sorry, camera not available.","warning");
    }
  }
  Currentaddressissame(completed: boolean){
    if(completed){
      this.secondFormGroup.get("CurrentAddressLine1").setValue(this.secondFormGroup.get("address_line_1").value);
      // this.secondFormGroup.get("CurrentAddressLine2").setValue(this.secondFormGroup.get("address_line_2").value);
      // this.secondFormGroup.get("CurrentAddressLine3").setValue(this.secondFormGroup.get("address_line_3").value);
      this.secondFormGroup.get("CurrentRegion").setValue(this.secondFormGroup.get("region").value);
      this.secondFormGroup.get("CurrentstateID").setValue(this.secondFormGroup.get("stateID").value);
      this.secondFormGroup.get("CurrentdistrictID").setValue(this.secondFormGroup.get("districtID").value);
      this.secondFormGroup.get("Currentoutofstate_address").setValue(this.secondFormGroup.get("outofstate_address").value);
      this.secondFormGroup.get("Currentoutofstate_address_pb").setValue(this.secondFormGroup.get("outofstate_address_pb").value);
      this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
      this.secondFormGroup.get("CurrenttehsilID").setValue(this.secondFormGroup.get("tehsilID").value);
      this.secondFormGroup.get("Currentpincode").setValue(this.secondFormGroup.get("pincode").value);
      if(this.secondFormGroup.get("region").value === 'Rural'){
        this.CurrentRegion= true;
        this.fetchcurrentVillages(this.secondFormGroup.get("tehsilID").value);
        this.secondFormGroup.get("CurrentVillage").setValue(this.secondFormGroup.get("PermanentVillage").value);
      }
    }
    else{
      this.secondFormGroup.get("CurrentAddressLine1").setValue(null);
      // this.secondFormGroup.get("CurrentAddressLine2").setValue(null);
      // this.secondFormGroup.get("CurrentAddressLine3").setValue(null);
      this.secondFormGroup.get("Currentoutofstate_address").setValue(null);
      this.secondFormGroup.get("Currentoutofstate_address_pb").setValue(null);
      this.secondFormGroup.get("CurrentRegion").setValue(null);
      this.secondFormGroup.get("CurrentstateID").setValue(null);
      this.secondFormGroup.get("CurrentdistrictID").setValue(null);
      this.secondFormGroup.get("CurrenttehsilID").setValue(null);
      this.secondFormGroup.get("Currentpincode").setValue(null);

      if(this.secondFormGroup.get("region").value === 'Urban'){
        this.CurrentRegion= false;
      }
    }
    this.secondFormGroup.get("CurrentAddressLine1").updateValueAndValidity();
    // this.secondFormGroup.get("CurrentAddressLine2").updateValueAndValidity();
    // this.secondFormGroup.get("CurrentAddressLine3").updateValueAndValidity();
    this.secondFormGroup.get("Currentoutofstate_address").updateValueAndValidity();
    this.secondFormGroup.get("Currentoutofstate_address_pb").updateValueAndValidity();
    this.secondFormGroup.get("CurrentRegion").updateValueAndValidity();
    this.secondFormGroup.get("CurrentstateID").updateValueAndValidity();
    this.secondFormGroup.get("CurrentdistrictID").updateValueAndValidity();
    this.secondFormGroup.get("CurrenttehsilID").updateValueAndValidity();
    this.secondFormGroup.get("Currentpincode").updateValueAndValidity();
  }
  PermanentOutOfState(completed: boolean){
    if(completed){
      this.PermanenIsOutOfState = false;
      this.secondFormGroup.get('address_line_1').setValidators(null);
      // this.secondFormGroup.get('address_line_2').setValidators(null);
      // this.secondFormGroup.get('address_line_3').setValidators(null);
      this.secondFormGroup.get('outofstate_address').setValidators([Validators.required, EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      this.secondFormGroup.get('outofstate_address_pb').setValidators([Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(250)]);
      // this.secondFormGroup.get('Currentoutofstate_address').setValidators([Validators.required]);
      // this.secondFormGroup.get('Currentoutofstate_address_pb').setValidators([Validators.required, OnlyPunjabi]);
      this.secondFormGroup.get('region').setValidators(null);
      this.secondFormGroup.get('stateID').setValidators(null);
      this.secondFormGroup.get('districtID').setValidators(null);
      this.secondFormGroup.get('tehsilID').setValidators(null);
      this.secondFormGroup.get('PermanentVillage').setValidators(null);
      this.secondFormGroup.get('pincode').setValidators(null);
      this.secondFormGroup.get('CurrentAddressIsOutOfState').disable();
      this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').disable();
    }
    else{
      this.PermanenIsOutOfState = true;
      this.secondFormGroup.get('address_line_1').setValidators([Validators.required, EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      // this.secondFormGroup.get('address_line_2').setValidators([EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      // this.secondFormGroup.get('address_line_3').setValidators([EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      this.secondFormGroup.get('outofstate_address').setValidators(null);
      this.secondFormGroup.get('outofstate_address_pb').setValidators(null);
      // this.secondFormGroup.get('Currentoutofstate_address').setValidators(null);
      // this.secondFormGroup.get('Currentoutofstate_address_pb').setValidators(null);
      this.secondFormGroup.get('region').setValidators([Validators.required]);
      this.secondFormGroup.get('stateID').setValidators([Validators.required]);
      this.secondFormGroup.get('districtID').setValidators([Validators.required]);
      this.secondFormGroup.get('tehsilID').setValidators([Validators.required]);
      //this.secondFormGroup.get('PermanentVillage').setValidators([Validators.required]);
      this.secondFormGroup.get('pincode').setValidators([NumericValidator, Validators.minLength(6)]);
      this.secondFormGroup.get('CurrentAddressIsOutOfState').enable();
      this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').enable();
    }

    this.secondFormGroup.get('address_line_1').updateValueAndValidity();
    // this.secondFormGroup.get('address_line_2').updateValueAndValidity();
    // this.secondFormGroup.get('address_line_3').updateValueAndValidity();
    this.secondFormGroup.get('outofstate_address').updateValueAndValidity();
    this.secondFormGroup.get('outofstate_address_pb').updateValueAndValidity();
    // this.secondFormGroup.get('Currentoutofstate_address').updateValueAndValidity();
    // this.secondFormGroup.get('Currentoutofstate_address_pb').updateValueAndValidity();
    this.secondFormGroup.get('region').updateValueAndValidity();
    this.secondFormGroup.get('stateID').updateValueAndValidity();
    this.secondFormGroup.get('districtID').updateValueAndValidity();
    this.secondFormGroup.get('tehsilID').updateValueAndValidity();
    //this.secondFormGroup.get('PermanentVillage').updateValueAndValidity();
    this.secondFormGroup.get('pincode').updateValueAndValidity();
  }
  CurrentsetOutOfState(completed: boolean){
    if(completed){
      this.CurrentIsOutOfState = false;
      this.secondFormGroup.get('CurrentAddressLine1').setValidators(null);
      // this.secondFormGroup.get('CurrentAddressLine2').setValidators(null);
      // this.secondFormGroup.get('CurrentAddressLine3').setValidators(null);
      this.secondFormGroup.get('Currentoutofstate_address').setValidators([Validators.required, EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      this.secondFormGroup.get('Currentoutofstate_address_pb').setValidators([Validators.required, OnlyPunjabi, Validators.minLength(2), Validators.maxLength(250)]);
      this.secondFormGroup.get('CurrentRegion').setValidators(null);
      this.secondFormGroup.get('CurrentstateID').setValidators(null);
      this.secondFormGroup.get('CurrentdistrictID').setValidators(null);
      this.secondFormGroup.get('CurrenttehsilID').setValidators(null);
      this.secondFormGroup.get('CurrentVillage').setValidators(null);
      this.secondFormGroup.get('Currentpincode').setValidators(null);
      //this.secondFormGroup.get('AddressIsOutOfState').disable();
      this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').disable();
    }
    else{
      this.CurrentIsOutOfState = true;
      this.secondFormGroup.get('CurrentAddressLine1').setValidators([Validators.required, EnglishWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]);
      // this.secondFormGroup.get('CurrentAddressLine2').setValidators([EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      // this.secondFormGroup.get('CurrentAddressLine3').setValidators([EnglishAddress, Validators.minLength(2), Validators.maxLength(250)]);
      this.secondFormGroup.get('Currentoutofstate_address').setValidators(null);
      this.secondFormGroup.get('Currentoutofstate_address_pb').setValidators(null);
      this.secondFormGroup.get('CurrentRegion').setValidators([Validators.required]);
      this.secondFormGroup.get('CurrentstateID').setValidators([Validators.required]);
      this.secondFormGroup.get('CurrentdistrictID').setValidators([Validators.required]);
      this.secondFormGroup.get('CurrenttehsilID').setValidators([Validators.required]);
      //this.secondFormGroup.get('CurrentVillage').setValidators([Validators.required]);
      this.secondFormGroup.get('Currentpincode').setValidators([NumericValidator, Validators.minLength(6)]);
      //this.secondFormGroup.get('AddressIsOutOfState').enable();
      this.secondFormGroup.get('Currentaddress_is_same_as_permanentaddress').enable();
    }

    this.secondFormGroup.get('CurrentAddressLine1').updateValueAndValidity();
    // this.secondFormGroup.get('CurrentAddressLine2').updateValueAndValidity();
    // this.secondFormGroup.get('CurrentAddressLine3').updateValueAndValidity();
    this.secondFormGroup.get('Currentoutofstate_address').updateValueAndValidity();
    this.secondFormGroup.get('Currentoutofstate_address_pb').updateValueAndValidity();
    this.secondFormGroup.get('CurrentRegion').updateValueAndValidity();
    this.secondFormGroup.get('CurrentstateID').updateValueAndValidity();
    this.secondFormGroup.get('CurrentdistrictID').updateValueAndValidity();
    this.secondFormGroup.get('CurrenttehsilID').updateValueAndValidity();
    //this.secondFormGroup.get('CurrentVillage').updateValueAndValidity();
    this.secondFormGroup.get('Currentpincode').updateValueAndValidity();
  }  
  ChangeCitizenResidingOutsideOfIndia(completed: boolean){
    if(completed){
      this.CitizenResidingOutsideOfIndia = true;
      this.thirdFormGroup.get('FromDate').setValidators(Validators.required);
      this.thirdFormGroup.get('ToDate').setValidators(Validators.required);
    }
    else{
      this.CitizenResidingOutsideOfIndia = false;      
      this.thirdFormGroup.get('FromDate').setValidators(null);
      this.thirdFormGroup.get('ToDate').setValidators(null);

      this.thirdFormGroup.get('FromDate').setValue(null);
      this.thirdFormGroup.get('ToDate').setValue(null);

      this.thirdFormGroup.get('FromDate').clearValidators();
      this.thirdFormGroup.get('ToDate').clearValidators();
    }
    this.thirdFormGroup.get('FromDate').updateValueAndValidity();
    this.thirdFormGroup.get('ToDate').updateValueAndValidity();
  }
  ChangeCitizenIsNRI(completed: boolean){
    if(completed){
      this.IsCitizenIsNRI = true;
      this.thirdFormGroup.get('CurrentAddressInIndia').setValidators([Validators.required, EnglishWithSpecialCharaterForAddress, Validators.minLength(2), Validators.maxLength(250)]);
      this.thirdFormGroup.get('CurrentAddressInIndiaInPunjabi').setValidators([Validators.required, PunjabiAddress, Validators.minLength(2), Validators.maxLength(250)]);
    }
    else{
      this.IsCitizenIsNRI = false;      
      this.thirdFormGroup.get('CurrentAddressInIndia').setValidators(null);
      this.thirdFormGroup.get('CurrentAddressInIndiaInPunjabi').setValidators(null);

      this.thirdFormGroup.get('CurrentAddressInIndia').setValue(null);
      this.thirdFormGroup.get('CurrentAddressInIndiaInPunjabi').setValue(null);

      this.thirdFormGroup.get('CurrentAddressInIndia').clearValidators();
      this.thirdFormGroup.get('CurrentAddressInIndiaInPunjabi').clearValidators();
    }
    this.thirdFormGroup.get('CurrentAddressInIndia').updateValueAndValidity();
    this.thirdFormGroup.get('CurrentAddressInIndiaInPunjabi').updateValueAndValidity();
  }
  //  Processing Details
  fetchProcessingDistricts(){
    var url = this.MarriageServicesAPI;
    var fetchMasterData = this._appSettings.fetchDistrict;
    url = url + fetchMasterData + "1";
    this._ConfigService.get(url)
      .subscribe(response => {
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.processingDistricts = response["data"];
        }
      });
  }
  fetchProcessingTehsilByDistrictID(event){
    var url = this.MarriageServicesAPI;
    var fetchMasterData = this._appSettings.fetchTehsil;
    url = url + fetchMasterData + event;
    this.loaderService.show();
    this._ConfigService.get(url)
      .subscribe(response => {
        this.loaderService.hide();
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.processingOfficeTehsil = response["data"];
        }
      });
  }
  fetchProcessingOfficeMasterByTehsilID(event){
    var url = this.MarriageServicesAPI;
    var fetchProcessingOfficeMaster = this._appSettings.fetchProcessingOfficeMaster;
    url = url + fetchProcessingOfficeMaster + event;
    this.loaderService.show();
    this._ConfigService.get(url)
      .subscribe(response => {
        this.loaderService.hide();
        this._notification.responseHandler(response);
        if(response["response"] == 1){
          this.processingOfficesList = response["data"];
        }
      });
  }
  //  End Processing Details
  attachVideo(stream) {
      this.renderer.setProperty(this.videoElement.nativeElement, 'srcObject', stream);
      this.renderer.listen(this.videoElement.nativeElement, 'play', (event) => {
          this.videoHeight = this.videoElement.nativeElement.videoHeight;
          this.videoWidth = this.videoElement.nativeElement.videoWidth;
      });
  }
  capture() {
      this.loaderService.show();
      this.renderer.setProperty(this.canvas.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas.nativeElement, 'height', this.videoHeight);
      this.canvas.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      //var context = this.canvas.nativeElement.getContext("2d").drawImage(this.videoElement.nativeElement, 0, 0);
      this.captures = [];
      this.captures.push(this.canvas.nativeElement.toDataURL("image/png"));
      this.img = null;
      this.img = this.canvas.nativeElement.toDataURL("image/png");      
      this.firstFormGroup.get("canvas").setValue(this.canvas.nativeElement.toDataURL("image/png"));
      this.loaderService.hide();
  }
  handleError(error) {
      console.log('Error: ', error);
  }
  step1Next(){
    if(this.captures.length <=0 || this.captures === null){
      this._notification.info("Please capture the image of beneficary!","info");
    }
    this.isStep1Next=true;
  }
  step2Next(){
    this.isStep2Next=true;
  }
  step3Next(){
    // if(this.captures.length <=0 || this.captures === null){
    //   this._notification.info("Please capture the image of beneficary!","info");      
    //   this.isStep3Next=false;
    // }
    // else{
      this.isStep3Next=true;
    //}
  }
  onSubmit(){
    if (this.firstFormGroup.invalid === true || this.secondFormGroup.invalid === true || this.thirdFormGroup.invalid === true || this.fourthFormGroup.invalid === true) {          
      this.isStep4Next = true;     
      return;
    }
    else if(!this.fourthFormGroup.get("acceptinformation").value){
      this._notification.info("Please accept the declare!","info");      
      this.isStep4Next = true;     
      return;
    }
    else{
      this.loaderService.show();
      this.isStep4Next = true;      
      if(this.captures.length <=0 || this.captures === null){
        this.loaderService.hide();
        this._notification.info("Please capture the image of beneficary!","info");
        return;
      }
      else{
        let DocID = String;
        var url = '';
        url =  this.eSewaURL;
        var GetMappingStageAndUser = this._appSettings.GetMappingStageAndUser;
        url = url + GetMappingStageAndUser;
        var data = {
          ServiceID : 104,
          operation_level : "district",
          operation_ref_id : this.fourthFormGroup.get("ProcessingdistrictID").value, // Processing office districtID
          SubmissionType : 'Y',
        }
        this._ConfigService.post(url, data)
        .subscribe(response => {
          if(response["response"] == 1){
              let MappingStage = response["data"];
              url =  this.eSewaURL;
              
              let UploadBeneficiaryPicData = {
                base64 : this.captures[0].replace('data:image/png;base64,', ''),
                filetype : 'image/png',
                filesize : ''
              };
              var UploadBeneficiaryPic = this._appSettings.UploadBeneficiaryPic;
              url = url + UploadBeneficiaryPic;

              this._ConfigService.post(url, UploadBeneficiaryPicData)
              .subscribe(response => {
                if(response["response"] == 1){
                  DocID = response["data"][0].docid;
                  if(this.action === 'resubmit'){
                    if(this.applicationID != null || this.applicationID != ''){
                        // Bind model for submit the data
                        let submitData = {
                            applicationid : this.applicationID,
                            serviceID : "104",
                            service_data : {
                              photo_of_Beneficiary_id: DocID,
                              citizenRefCode: this.citizenRefCode,
                              salutation: this.firstFormGroup.get("salutation").value,
                              applyingforself: this.thirdFormGroup.get("ApplicentRelationIDWithBeneficary").value,
                              applicentrelationwithbeneficary : _.find(this.relationlist, (pdstlst) => pdstlst.relationid == this.thirdFormGroup.get("ApplicentRelationIDWithBeneficary").value).relation_name_eng,
                              applicant_name : this.thirdFormGroup.get("ApplicantName").value,
                              applicant_name_pb : this.thirdFormGroup.get("ApplicantNameInPunjabi").value,
                              applicant_address : this.thirdFormGroup.get("ApplicantAddress").value,
                              applicant_address_pb : "",
                              applicant_fathername : this.thirdFormGroup.get("ApplicantFatherName").value,
                              applicant_fathername_pb : this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").value,

                              //Personal_Details
                              beneficiary_firstName: this.firstFormGroup.get("first_name").value,
                              beneficiary_firstName_pb: this.firstFormGroup.get("first_name_punjabi").value,
                              beneficiary_middleName: this.firstFormGroup.get("middle_name").value,
                              beneficiary_middleName_pb: this.firstFormGroup.get("middle_name_punjabi").value,
                              beneficiary_lastName: this.firstFormGroup.get("last_name").value,
                              beneficiary_lastName_pb: this.firstFormGroup.get("last_name_punjabi").value,

                              beneficiary_fathersFirstName: this.firstFormGroup.get("father_first_name").value,
                              beneficiary_fathersFirstName_pb: this.firstFormGroup.get("father_first_name_punjabi").value,              
                              beneficiary_fathersMiddleName: this.firstFormGroup.get("father_middle_name").value,
                              beneficiary_fathersMiddleName_pb: this.firstFormGroup.get("father_middle_name_punjabi").value,
                              beneficiary_fathersLastName: this.firstFormGroup.get("father_last_name").value,
                              beneficiary_fathersLastName_pb: this.firstFormGroup.get("father_last_name_punjabi").value,

                              beneficiary_mothersFirstName: this.firstFormGroup.get("mother_first_name").value,
                              beneficiary_mothersFirstName_pb: this.firstFormGroup.get("mother_first_name_punjabi").value,
                              beneficiary_mothersMiddleName: this.firstFormGroup.get("mother_middle_name").value,
                              beneficiary_mothersMiddleName_pb: this.firstFormGroup.get("mother_middle_name_punjabi").value,
                              beneficiary_mothersLastName: this.firstFormGroup.get("mother_last_name").value,
                              beneficiary_mothersLastName_pb: this.firstFormGroup.get("mother_last_name_punjabi").value,

                              beneficiary_dob: this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.firstFormGroup.get("date_of_birth").value),
                              beneficiary_age: this.firstFormGroup.get("age").value,
                              beneficiary_months: this.firstFormGroup.get("months").value,
                              beneficiary_placeOfBirth: this.firstFormGroup.get("place_of_birth").value,
                              beneficiary_gender: this.firstFormGroup.get("gender").value,
                              beneficiary_maritalStatus: {
                                statusid : this.firstFormGroup.get("marital_status").value,
                                status_title: _.find(this.maritalstatuslist, (pdstlst) => pdstlst.statusid == this.firstFormGroup.get("marital_status").value).status_title,
                                status_title_pb: _.find(this.maritalstatuslist, (pdstlst) => pdstlst.statusid == this.firstFormGroup.get("marital_status").value).status_title_p,
                              },
                              //beneficiary_maritalStatus: this.firstFormGroup.get("marital_status").value,
                              beneficiary_spouseName: this.firstFormGroup.get("SpouseName").value,
                              beneficiary_spouseName_pb: this.firstFormGroup.get("SpouseNameinPunjabi").value,
                              permanent_address : {
                                  //address_isOutofState   : this.secondFormGroup.get("AddressIsOutOfState").value,
                                  address_isOutofState : null,
                                  address_line_1  : this.secondFormGroup.get("address_line_1").value,
                                  // address_line_2  : this.secondFormGroup.get("address_line_2").value,
                                  // address_line_3  : this.secondFormGroup.get("address_line_3").value,   
                                  address_line_2  : null,
                                  address_line_3  : null,                   
                                  outofstate_address  : this.secondFormGroup.get("outofstate_address").value,
                                  outofstate_address_pb  : this.secondFormGroup.get("outofstate_address_pb").value,
                                  address_pb  :"",
                                  address_pincode   : this.secondFormGroup.get("pincode").value,        
                                  address_region  : this.secondFormGroup.get("region").value,
                                address_district : {
                                  district_id : this.secondFormGroup.get("districtID").value,
                                  district_name: _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_name,
                                  district_code : _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_code,
                                  name_in_punjabi: _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).name_in_punjabi,
                                },
                                address_tehsil : {
                                  tehsil_id  : this.secondFormGroup.get("tehsilID").value,
                                  tehsil_name  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_name,
                                  district_name  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).district_name,
                                  name_in_punjabi  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).name_in_punjabi,
                                  teh_user_code : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_user_code,
                                  is_sub_tehsil : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).is_sub_tehsil,
                                },
                                address_village : {
                                  village_code : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_code : null,
                                  village_name : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_name : null,
                                  village_id : this.secondFormGroup.get("PermanentVillage").value,
                                  tehsil_name :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).tehsil_name : null,
                                  district_name :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).district_name : null,
                                  name_in_punjabi :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).name_in_punjabi : null,
                                  village_user_code :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_user_code : null,
                                  village_code_agri :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_code_agri : null,
                                },
                              },
                              currentaddress_is_same_as_permanentaddress : this.secondFormGroup.get("Currentaddress_is_same_as_permanentaddress").value,
                              currentaddress_is_out_of_state : this.CurrentIsOutOfState,
                              current_address: {
                                address_isOutofState : this.secondFormGroup.get("CurrentAddressIsOutOfState").value,                      
                                address_line_1  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine1").value : null,
                                // address_line_2  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine2").value : null,
                                // address_line_3  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine3").value : null,
                                address_line_2  : null,
                                address_line_3  : null,
                                outofstate_address  : this.secondFormGroup.get("Currentoutofstate_address").value,
                                outofstate_address_pb  : this.secondFormGroup.get("Currentoutofstate_address_pb").value,
                                address_pb  : "",
                                address_pincode   : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("Currentpincode").value : null,
                                address_region  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value : null,
                                address_district : {
                                  district_id : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentdistrictID").value : null,
                                  district_name: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).district_name : null,
                                  district_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).district_code : null,
                                  name_in_punjabi: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).name_in_punjabi : null,
                                },
                                address_tehsil   :{
                                  tehsil_id  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrenttehsilID").value : null,
                                  tehsil_name  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).tehsil_name : null,
                                  district_name  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).district_name : null,
                                  name_in_punjabi  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).name_in_punjabi : null,
                                  teh_user_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).tehsil_user_code : null,
                                  is_sub_tehsil : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).is_sub_tehsil : null,
                                }  ,            
                                address_village  :{
                                  village_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_code : null : null,
                                  village_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_name : null : null,
                                  village_id : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentVillage").value : null,
                                  tehsil_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).tehsil_name : null : null,
                                  district_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).district_name : null : null,
                                  name_in_punjabi : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).name_in_punjabi : null : null,
                                  village_user_code: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_user_code : null : null,
                                  village_code_agri: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_code_agri : null : null,
                                },
                              },

                              // permanent_address : this.secondFormGroup.get("address_line_1").value,
                              // current_address : this.secondFormGroup.get("CurrentAddressLine1").value,
                              beneficiary_email: this.secondFormGroup.get("EmailID").value,
                              beneficiary_mobileNo: this.secondFormGroup.get("MobileNo").value,
                              beneficiary_phoneNo: this.secondFormGroup.get("PhoneNo").value,

                              beneficiary_voterId: this.firstFormGroup.get("VoterIdCardNumber").value,
                              beneficiary_aadhaarEnrollment: this.firstFormGroup.get("AadhaarEnrollmentNumber").value,
                              beneficiary_aadhaar: this.firstFormGroup.get("AadhaarNumber").value,
                              
                              // applicant_religion : {
                              //   religionid :"",
                              //   religionname :"",
                              // },
                              beneficiary_religion: "",
                              beneficiary_bplNumber : this.firstFormGroup.get("BPLCardNumber").value,
                              beneficiary_verificationNumber : "",
                              issued_to : "",
                              designation_of_issuingPerson : "",
                              remarks : "",
                              enc_aadhaar : "",
                              //End Personal_Details
                              beneficiary_details : null,

                              DoesSocialSecurityNumberExists : this.thirdFormGroup.get("DoesSocialSecurityNumberExists").value,
                              SocialSecurityNumber : this.thirdFormGroup.get("SocialSecurityNumber").value,
                              CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry : this.thirdFormGroup.get("CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry").value,
                              CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi : this.thirdFormGroup.get("CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi").value,
                              DateTillUnmarried : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("DateTillUnmarried").value),
                              ServiceDetailPlaceOfBirth : this.thirdFormGroup.get("ServiceDetailPlaceOfBirth").value,
                              ServiceDetailDateOfBirth : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("ServiceDetailDateOfBirth").value),
                              IsCitizenResidingOutsideOfIndia : this.thirdFormGroup.get("IsCitizenResidingOutsideOfIndia").value,
                              FromDate : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("FromDate").value),
                              ToDate : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("ToDate").value),
                              CitizenIsNRI : this.thirdFormGroup.get("CitizenIsNRI").value,
                              CurrentAddressInIndia : this.thirdFormGroup.get("CurrentAddressInIndia").value,
                              CurrentAddressInIndiaInPunjabi : this.thirdFormGroup.get("CurrentAddressInIndiaInPunjabi").value,

                              currentStage : MappingStage[0]["userID"],
                              currentStageRefID : MappingStage[0]["stageID"],
                              UserID : this.userID,

                              // Processing Details
                              processing_region : this.fourthFormGroup.get("ProcessingRegion").value,
                              processing_district : this.fourthFormGroup.get("ProcessingdistrictID").value,
                              processing_district_name : _.find(this.processingDistricts, (pdstlst) => pdstlst.district_id == this.fourthFormGroup.get("ProcessingdistrictID").value).district_name,
                              processing_district_name_pb : _.find(this.processingDistricts, (pdstlst) => pdstlst.district_id == this.fourthFormGroup.get("ProcessingdistrictID").value).name_in_punjabi,
                              
                              processing_tehsil : this.fourthFormGroup.get("ProcessingtehsilID").value,
                              processing_tehsil_name : _.find(this.processingOfficeTehsil, (pdstlst) => pdstlst.tehsil_id == this.fourthFormGroup.get("ProcessingtehsilID").value).tehsil_name,
                              processing_tehsil_name_pb : _.find(this.processingOfficeTehsil, (pdstlst) => pdstlst.tehsil_id == this.fourthFormGroup.get("ProcessingtehsilID").value).name_in_punjabi,
                              //processing_office : this.fourthFormGroup.get("ProcessingofficeID").value,
                              processing_office : 0,
                              //processing_office_name : _.find(this.processingOfficesList, (pdstlst) => pdstlst.office_id == this.fourthFormGroup.get("ProcessingofficeID").value).office_name,
                              processing_office_name : null,
                              
                              //  Application Approve Actor Detail
                              applicationapprovedactordetail : null,
                              sspvideno : null,
                              sspvidedate : null
                            },
                            applicant_address : this.secondFormGroup.get("address_line_1").value,
                            applicant_name : 
                            this.firstFormGroup.get("first_name").value + " " +
                            this.firstFormGroup.get("middle_name").value + " " +
                            this.firstFormGroup.get("last_name").value,
                            dob : this.firstFormGroup.get("date_of_birth").value,
                            fatherfullname : 
                              this.firstFormGroup.get("father_first_name").value + " " +
                              this.firstFormGroup.get("father_middle_name").value + " " +
                              this.firstFormGroup.get("father_last_name").value,
                            motherfullname :
                            this.firstFormGroup.get("mother_first_name").value + " " +
                            this.firstFormGroup.get("mother_middle_name").value + " " +
                            this.firstFormGroup.get("mother_last_name").value,
                            marital_status : this.firstFormGroup.get("marital_status").value,
                            gender : this.firstFormGroup.get("gender").value,
                            pincode : this.secondFormGroup.get("pincode").value,
                            region : this.secondFormGroup.get("region").value,
                            state_code : this.secondFormGroup.get("stateID").value,
                            state_name : "Punjab",
                            district_code : this.fourthFormGroup.get("ProcessingdistrictID").value,
                            district_name : "",
                            division_code : 0,
                            division_name : "",
                            tehsil_code : this.fourthFormGroup.get("ProcessingtehsilID").value,
                            tehsil_name : "",
                            block_code : 0,
                            block_name : "",
                            village_code : 0,
                            village_name : "",
                            citizenID : this.citizenRefCode,
                            assignmentLevel : "District",
                            assignmentID : this.secondFormGroup.get("districtID").value,
                            application_type : "Issuance",
                            doc_user_case : "",
                            doc_user_case_value : "",
                            currentStage : MappingStage[0]["userID"],
                            currentStageRefID : MappingStage[0]["stageID"],
                            UserID : this.response_data["skm_operator_id"],
                            
                            // Processing Details
                            processing_region : this.fourthFormGroup.get("ProcessingRegion").value,
                            processing_district : this.fourthFormGroup.get("ProcessingdistrictID").value,
                            processing_tehsil : this.fourthFormGroup.get("ProcessingtehsilID").value,
                            //processing_office : this.fourthFormGroup.get("ProcessingofficeID").value
                            processing_office : 0
                        }
                        url = '';
                        url =  this.MarriageServicesAPI;
                        var ApplicationReSubmit = this._appSettings.ApplicationReSubmit;
                        url = url + ApplicationReSubmit;

                        this._ConfigService.post(url, submitData)
                        .subscribe(response => {
                          if(response["response"] == 1){
                            this.firstFormGroup.reset();
                            this.secondFormGroup.reset();
                            this.thirdFormGroup.reset();
                            this.fourthFormGroup.reset();
                            //alert('Application has been resubmitted successfully!');
                            let submitData = {
                              base64 : this.captures[0].replace('data:image/png;base64,', ''),
                              appId : this.applicationID,
                              filetype : 'image/png',
                              filesize : ''
                            };
                            url = '';
                            url =  this.eSewaURL;
                            var UploadBeneficiaryPic = this._appSettings.UploadBeneficiaryPic;
                            url = url + UploadBeneficiaryPic;

                            this._ConfigService.post(url, submitData)
                            .subscribe(response => {
                              this.loaderService.hide();
                              if(response["response"] == 1){
                                window.location.href = environment.uploadDocumentURL + "uploaddocuments/" +
                                  this.token + '/' + this.applicationID + '/resubmit/'+ environment.serviceID_marriageability;
                              }
                              else{
                                this._notification.info("Application not resubmitted successfully due to some reason!","info");
                              }
                            });
                          }
                          else{
                            this.loaderService.hide();
                            this._notification.info("Application not resubmitted successfully due to some reason!","info");
                          }
                        });
                    }
                    else{
                      this.loaderService.hide();
                      this._notification.info("eSewa not generated application id due to some reason!","info");
                    }
                  }
                  else{
                    var url = this._appSettings.eSewaURL;
                    var GetApplicationIdAtCreation = this._appSettings.GetApplicationIdAtCreation;
                    url = url + GetApplicationIdAtCreation + "6";

                    this._ConfigService.get(url)
                    .subscribe(response => {
                    if(response["response"] == 1){
                      this.applicationID = response["data"][0].applicationID;
                      if(this.applicationID != null || this.applicationID != '' || this.applicationID.length > 0){
                            // Bind model for submit the data
                            let submitData = {
                                applicationid : this.applicationID,
                                serviceID : "104",
                                service_data : {
                                  photo_of_Beneficiary_id: DocID,
                                  citizenRefCode: this.citizenRefCode,
                                  salutation: this.firstFormGroup.get("salutation").value,
                                  applyingforself: this.thirdFormGroup.get("ApplicentRelationIDWithBeneficary").value,
                                  applicentrelationwithbeneficary : _.find(this.relationlist, (pdstlst) => pdstlst.relationid == this.thirdFormGroup.get("ApplicentRelationIDWithBeneficary").value).relation_name_eng,
                                  applicant_name : this.thirdFormGroup.get("ApplicantName").value,
                                  applicant_name_pb : this.thirdFormGroup.get("ApplicantNameInPunjabi").value,
                                  applicant_address : this.thirdFormGroup.get("ApplicantAddress").value,
                                  applicant_address_pb : "",
                                  applicant_fathername : this.thirdFormGroup.get("ApplicantFatherName").value,
                                  applicant_fathername_pb : this.thirdFormGroup.get("ApplicantFatherNameInPunjabi").value,

                                  //Personal_Details
                                  beneficiary_firstName: this.firstFormGroup.get("first_name").value,
                                  beneficiary_firstName_pb: this.firstFormGroup.get("first_name_punjabi").value,
                                  beneficiary_middleName: this.firstFormGroup.get("middle_name").value,
                                  beneficiary_middleName_pb: this.firstFormGroup.get("middle_name_punjabi").value,
                                  beneficiary_lastName: this.firstFormGroup.get("last_name").value,
                                  beneficiary_lastName_pb: this.firstFormGroup.get("last_name_punjabi").value,

                                  beneficiary_fathersFirstName: this.firstFormGroup.get("father_first_name").value,
                                  beneficiary_fathersFirstName_pb: this.firstFormGroup.get("father_first_name_punjabi").value,              
                                  beneficiary_fathersMiddleName: this.firstFormGroup.get("father_middle_name").value,
                                  beneficiary_fathersMiddleName_pb: this.firstFormGroup.get("father_middle_name_punjabi").value,
                                  beneficiary_fathersLastName: this.firstFormGroup.get("father_last_name").value,
                                  beneficiary_fathersLastName_pb: this.firstFormGroup.get("father_last_name_punjabi").value,

                                  beneficiary_mothersFirstName: this.firstFormGroup.get("mother_first_name").value,
                                  beneficiary_mothersFirstName_pb: this.firstFormGroup.get("mother_first_name_punjabi").value,
                                  beneficiary_mothersMiddleName: this.firstFormGroup.get("mother_middle_name").value,
                                  beneficiary_mothersMiddleName_pb: this.firstFormGroup.get("mother_middle_name_punjabi").value,
                                  beneficiary_mothersLastName: this.firstFormGroup.get("mother_last_name").value,
                                  beneficiary_mothersLastName_pb: this.firstFormGroup.get("mother_last_name_punjabi").value,

                                  beneficiary_dob: this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.firstFormGroup.get("date_of_birth").value),
                                  beneficiary_age: this.firstFormGroup.get("age").value,
                                  beneficiary_months: this.firstFormGroup.get("months").value,
                                  beneficiary_placeOfBirth: this.firstFormGroup.get("place_of_birth").value,
                                  beneficiary_gender: this.firstFormGroup.get("gender").value,
                                  beneficiary_maritalStatus: {
                                    statusid : this.firstFormGroup.get("marital_status").value,
                                    status_title: _.find(this.maritalstatuslist, (pdstlst) => pdstlst.statusid == this.firstFormGroup.get("marital_status").value).status_title,
                                    status_title_pb: _.find(this.maritalstatuslist, (pdstlst) => pdstlst.statusid == this.firstFormGroup.get("marital_status").value).status_title_p,
                                  },
                                  //beneficiary_maritalStatus: this.firstFormGroup.get("marital_status").value,
                                  beneficiary_spouseName: this.firstFormGroup.get("SpouseName").value,
                                  beneficiary_spouseName_pb: this.firstFormGroup.get("SpouseNameinPunjabi").value,
                                  permanent_address:{
                                      address_isOutofState   : this.PermanenIsOutOfState == true ? "false" : "true",
                                      address_line_1  : this.secondFormGroup.get("address_line_1").value,
                                      // address_line_2  : this.secondFormGroup.get("address_line_2").value,
                                      // address_line_3  : this.secondFormGroup.get("address_line_3").value,
                                      address_line_2  : null,
                                      address_line_3  : null,
                                      outofstate_address  : this.secondFormGroup.get("outofstate_address").value,
                                      outofstate_address_pb  : this.secondFormGroup.get("outofstate_address_pb").value,
                                      address_pb  :"",
                                      address_pincode   : this.secondFormGroup.get("pincode").value,        
                                      address_region  : this.secondFormGroup.get("region").value,
                                      address_district   :{
                                        district_id : this.secondFormGroup.get("districtID").value,
                                        district_name: _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_name,
                                        district_code : _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).district_code,
                                        name_in_punjabi: _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value).name_in_punjabi,
                                      },
                                      address_tehsil   :{
                                        tehsil_id  : this.secondFormGroup.get("tehsilID").value,
                                        tehsil_name  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_name,
                                        district_name  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).district_name,
                                        name_in_punjabi  : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).name_in_punjabi,
                                        teh_user_code : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).tehsil_user_code,
                                        is_sub_tehsil : _.find(this.tehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("tehsilID").value).is_sub_tehsil,
                                      }  ,            
                                      address_village  :{
                                        village_code :  this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_code : null,
                                        village_name : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_name : null,
                                        village_id : this.secondFormGroup.get("PermanentVillage").value,
                                        tehsil_name : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).tehsil_name : null,
                                        district_name : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).district_name : null,
                                        name_in_punjabi : this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).name_in_punjabi : null,
                                        village_user_code: this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_user_code : null,
                                        village_code_agri: this.secondFormGroup.get("region").value === 'Rural' ? _.find(this.villageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("PermanentVillage").value).village_code_agri : null,
                                      },
                                  },
                                  currentaddress_is_same_as_permanentaddress : this.secondFormGroup.get("Currentaddress_is_same_as_permanentaddress").value,
                                  currentaddress_is_out_of_state : this.PermanenIsOutOfState == true ? false : true,
                                  current_address: {
                                    address_isOutofState   : this.CurrentIsOutOfState == true ? "false" : "true",
                                    address_line_1  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine1").value : null,
                                    //address_line_2  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine2").value : null,
                                    //address_line_3  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentAddressLine3").value : null,
                                    address_line_2  : null,
                                    address_line_3  : null,
                                    outofstate_address  : this.secondFormGroup.get("Currentoutofstate_address").value,
                                    outofstate_address_pb  : this.secondFormGroup.get("Currentoutofstate_address_pb").value,
                                    address_pb  : "",
                                    address_pincode   : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("Currentpincode").value : null,
                                    address_region  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value : null,
                                    address_district : {
                                      district_id : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentdistrictID").value : null,
                                      district_name: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).district_name : null,
                                      district_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).district_code : null,
                                      name_in_punjabi: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currentdistrictList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value).name_in_punjabi : null,
                                    },
                                    address_tehsil   :{
                                      tehsil_id  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrenttehsilID").value : null,
                                      tehsil_name  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).tehsil_name : null,
                                      district_name  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).district_name : null,
                                      name_in_punjabi  : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).name_in_punjabi : null,
                                      teh_user_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).tehsil_user_code : null,
                                      is_sub_tehsil : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? _.find(this.currenttehsilList, (pdstlst) => pdstlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value).is_sub_tehsil : null,
                                    }  ,            
                                    address_village  :{
                                      village_code : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_code : null : null,
                                      village_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_name : null : null,
                                      village_id : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentVillage").value : null,
                                      tehsil_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).tehsil_name : null : null,
                                      district_name : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).district_name : null : null,
                                      name_in_punjabi : this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).name_in_punjabi : null : null,
                                      village_user_code: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_user_code : null : null,
                                      village_code_agri: this.secondFormGroup.get("CurrentAddressIsOutOfState").value != 'True' ? this.secondFormGroup.get("CurrentRegion").value === 'Rural' ? _.find(this.currentvillageList, (pdstlst) => pdstlst.village_id == this.secondFormGroup.get("CurrentVillage").value).village_code_agri : null : null,
                                    },
                                  },

                                  // permanent_address : this.secondFormGroup.get("address_line_1").value,
                                  // current_address : this.secondFormGroup.get("CurrentAddressLine1").value,
                                  beneficiary_email: this.secondFormGroup.get("EmailID").value,
                                  beneficiary_mobileNo: this.secondFormGroup.get("MobileNo").value,
                                  beneficiary_phoneNo: this.secondFormGroup.get("PhoneNo").value,

                                  beneficiary_voterId: this.firstFormGroup.get("VoterIdCardNumber").value,
                                  beneficiary_aadhaarEnrollment: this.firstFormGroup.get("AadhaarEnrollmentNumber").value,
                                  beneficiary_aadhaar: this.firstFormGroup.get("AadhaarNumber").value,
                                  
                                  // applicant_religion : {
                                  //   religionid :"",
                                  //   religionname :"",
                                  // },
                                  beneficiary_religion: "",
                                  beneficiary_bplNumber : this.firstFormGroup.get("BPLCardNumber").value,
                                  beneficiary_verificationNumber : "",
                                  issued_to : "",
                                  designation_of_issuingPerson : "",
                                  remarks : "",
                                  enc_aadhaar : "",
                                  //End Personal_Details
                                  beneficiary_details : null,

                                  DoesSocialSecurityNumberExists : this.thirdFormGroup.get("DoesSocialSecurityNumberExists").value,
                                  SocialSecurityNumber : this.thirdFormGroup.get("SocialSecurityNumber").value,
                                  CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry : this.thirdFormGroup.get("CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountry").value,
                                  CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi : this.thirdFormGroup.get("CurrentAddressOfProspectiveBrideOrBridegroomInForeignCountryInPunjabi").value,
                                  DateTillUnmarried : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("DateTillUnmarried").value),
                                  ServiceDetailPlaceOfBirth : this.thirdFormGroup.get("ServiceDetailPlaceOfBirth").value,
                                  ServiceDetailDateOfBirth : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("ServiceDetailDateOfBirth").value),
                                  IsCitizenResidingOutsideOfIndia : this.thirdFormGroup.get("IsCitizenResidingOutsideOfIndia").value,
                                  FromDate : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("FromDate").value),
                                  ToDate : this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("ToDate").value),
                                  CitizenIsNRI : this.thirdFormGroup.get("CitizenIsNRI").value,
                                  CurrentAddressInIndia : this.thirdFormGroup.get("CurrentAddressInIndia").value,
                                  CurrentAddressInIndiaInPunjabi : this.thirdFormGroup.get("CurrentAddressInIndiaInPunjabi").value,

                                  currentStage : MappingStage[0]["userID"],
                                  currentStageRefID : MappingStage[0]["stageID"],
                                  UserID : this.userID,

                                  // Processing Details
                                  processing_region : this.fourthFormGroup.get("ProcessingRegion").value,
                                  processing_district : this.fourthFormGroup.get("ProcessingdistrictID").value,
                                  processing_district_name : _.find(this.processingDistricts, (pdstlst) => pdstlst.district_id == this.fourthFormGroup.get("ProcessingdistrictID").value).district_name,
                                  processing_district_name_pb : _.find(this.processingDistricts, (pdstlst) => pdstlst.district_id == this.fourthFormGroup.get("ProcessingdistrictID").value).name_in_punjabi,
                                  
                                  processing_tehsil : this.fourthFormGroup.get("ProcessingtehsilID").value,
                                  processing_tehsil_name : _.find(this.processingOfficeTehsil, (pdstlst) => pdstlst.tehsil_id == this.fourthFormGroup.get("ProcessingtehsilID").value).tehsil_name,
                                  processing_tehsil_name_pb : _.find(this.processingOfficeTehsil, (pdstlst) => pdstlst.tehsil_id == this.fourthFormGroup.get("ProcessingtehsilID").value).name_in_punjabi,
                                  //processing_office : this.fourthFormGroup.get("ProcessingofficeID").value,
                                  processing_office : 0,
                                  //processing_office_name : _.find(this.processingOfficesList, (pdstlst) => pdstlst.office_id == this.fourthFormGroup.get("ProcessingofficeID").value).office_name,
                                  processing_office_name : null,
                              
                                  //  Application Approve Actor Detail
                                  applicationapprovedactordetail : null,
                                  sspvideno : null,
                                  sspvidedate : null
                                },
                                applicant_address : this.secondFormGroup.get("address_line_1").value,
                                applicant_name : 
                                this.firstFormGroup.get("first_name").value + " " +
                                this.firstFormGroup.get("middle_name").value + " " +
                                this.firstFormGroup.get("last_name").value,
                                dob : this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.firstFormGroup.get("date_of_birth").value),
                                fatherfullname : 
                                  this.firstFormGroup.get("father_first_name").value + " " +
                                  this.firstFormGroup.get("father_middle_name").value + " " +
                                  this.firstFormGroup.get("father_last_name").value,
                                motherfullname :
                                this.firstFormGroup.get("mother_first_name").value + " " +
                                this.firstFormGroup.get("mother_middle_name").value + " " +
                                this.firstFormGroup.get("mother_last_name").value,
                                marital_status : this.firstFormGroup.get("marital_status").value,
                                gender : this.firstFormGroup.get("gender").value,
                                pincode : this.secondFormGroup.get("pincode").value,
                                region : this.secondFormGroup.get("region").value,
                                state_code : this.secondFormGroup.get("stateID").value,
                                state_name : "Punjab",
                                district_code : this.fourthFormGroup.get("ProcessingdistrictID").value,
                                district_name : "",
                                division_code : 0,
                                division_name : "",
                                tehsil_code : this.fourthFormGroup.get("ProcessingtehsilID").value,
                                tehsil_name : "",
                                block_code : 0,
                                block_name : "",
                                village_code : 0,
                                village_name : "",
                                citizenID : this.citizenRefCode,
                                assignmentLevel : "District",
                                assignmentID : this.secondFormGroup.get("districtID").value,
                                application_type : "Issuance",
                                doc_user_case : "",
                                doc_user_case_value : "",
                                currentStage : MappingStage[0]["userID"],
                                currentStageRefID : MappingStage[0]["stageID"],
                                UserID : this.userID,

                                // Processing Details
                                processing_region : this.fourthFormGroup.get("ProcessingRegion").value,
                                processing_district : this.fourthFormGroup.get("ProcessingdistrictID").value,
                                processing_tehsil : this.fourthFormGroup.get("ProcessingtehsilID").value,
                                //processing_office : this.fourthFormGroup.get("ProcessingofficeID").value,
                                processing_office : 0
                            }
                            url = '';
                            url =  this.MarriageServicesAPI;
                            var ApplicationSubmit = this._appSettings.ApplicationSubmit;
                            url = url + ApplicationSubmit;
                            //this.loaderService.hide();
                            this._ConfigService.post(url, submitData)
                            .subscribe(response => {
                              this.loaderService.hide();
                              if(response["response"] == 1){
                                this.firstFormGroup.reset();
                                this.secondFormGroup.reset();
                                this.thirdFormGroup.reset();
                                this.fourthFormGroup.reset();
                                this._notification.success("Application has been submitted successfully!","success");
                                window.location.href = environment.uploadDocumentURL + "uploaddocuments/" +
                                this.token + '/' + this.applicationID + '/submit/'+ environment.serviceID_marriageability;
                              }
                              else{ 
                                this.loaderService.hide();
                                this._notification.info("Application has been not submitted successfully!","info");
                              }
                            });
                        
                      }
                      else{ 
                        this.loaderService.hide();
                      }
                    }
                    else{
                      this.loaderService.hide();     
                      this._notification.info("eSewa not generated application id due to some reason!","info");
                    }
                    });
                  }
                }
                else{
                  this.loaderService.hide();     
                  this._notification.info("Beneficiary picture did not upload due to some reason!","info");
                }
              });
            }
            else{
              this.loaderService.hide();     
              this._notification.info("First user mapping is null!","info");
            }
        });
      }
    }
  }
  dateConvertIntoMMDDYYYtoDDMMYYYY(date_data){  
    return(this.pipe.transform(date_data, 'dd/MM/yyyy'))
  }
  dateConvertIntoDDMMYYYtoMMDDYYYY(data_date){
    return(moment(moment(data_date, 'DD/MM/YYYY')).format('MM/DD/YYYY'))
  }
  dateConvertIntoMMDDYYYtoYYYYMMDD(date_data){  
    return(this.pipe.transform(date_data, 'yyyy/MM/dd'))
  }
  getErrorMessageStep1(control: string) {
    if ( this.isStep1Next){
     this.isProcessing=false;
     // console.log(this.step1.value);
      return FormErrorMessage(this.firstFormGroup, control);
    }
  }
  getErrorMessageStep2(control: string) {
    if ( this.isStep2Next){
    this.isProcessing=false;
    // console.log(this.step1.value);
      return FormErrorMessage(this.secondFormGroup, control);
    }
  }
  getErrorMessageStep3(control: string) {
    if ( this.isStep3Next){
    this.isProcessing=false;
    // console.log(this.step1.value);
      return FormErrorMessage(this.thirdFormGroup, control);
    }
  }
  getErrorMessageStep4(control: string) {
    if ( this.isStep4Next){
    this.isProcessing=false;
    // console.log(this.step1.value);
      return FormErrorMessage(this.fourthFormGroup, control);
    }
  }
}
