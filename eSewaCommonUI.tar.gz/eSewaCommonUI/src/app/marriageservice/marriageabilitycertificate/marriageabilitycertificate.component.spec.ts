import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarriageabilitycertificateComponent } from './marriageabilitycertificate.component';

describe('MarriageabilitycertificateComponent', () => {
  let component: MarriageabilitycertificateComponent;
  let fixture: ComponentFixture<MarriageabilitycertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarriageabilitycertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarriageabilitycertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
