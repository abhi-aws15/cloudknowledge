// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-specialmarriage',
//   templateUrl: './specialmarriage.component.html',
//   styleUrls: ['./specialmarriage.component.css']
// })
// export class SpecialmarriageComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }



//anand marriage code
import { Component, OnInit,ElementRef,  Renderer2, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AppsettingsService } from 'src/app/config/appsettings.service';
import { ConfigService } from 'src/app/config/config.service';
import { NotificationService } from 'src/app/services/notification.service';
import { CommonservicesService } from 'src/app/services/commonservices.service';
import { Aadhaar, AlphaNumericValidator,AlphaValidator,email, EnglishAddress, AadhaarEnrolmentNumber, FormErrorMessage,mobile,NumOnly,OnlyPunjabi, PassportNo, PunjabiAddress, SocialSecurityNumber, VoterID, NumericValidator } from 'src/app/services/custom.validators';
import { environment } from 'src/environments/environment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _ from 'lodash';
import { mapTo } from 'rxjs/operators';
import { Moment } from 'moment';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { LoaderService } from 'src/app/loader.service';
import { EncryptiondecryptionserviceService } from 'src/app/services/encryptiondecryptionservice.service';

//import 'moment-range';

@Component({
  selector: 'app-specialmarriage',
  templateUrl: './specialmarriage.component.html',
  styleUrls: ['./specialmarriage.component.css']
})

export class SpecialmarriageComponent implements OnInit {
  isLinear = false;
  isStep1Next=false;
  isStep2Next=false;
  isStep3Next=false;
  isStep4Next=false;
  isStep5Next=false;
  isStep6Next=false;
  isStep7Next=false;
  isStep8Next=false;
//declare form group
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  fourthFormGroup: FormGroup;
  fifthFormGroup: FormGroup;
  sixthFormGroup: FormGroup;
  seventhFormGroup: FormGroup;
  eighthFormGroup: FormGroup;

  public isProcessing: boolean;
  public apiRes:any;
  pipe = new DatePipe('en-US');

  token: string;
  action: string;
  citizenRefCode: string;
  minDate: Date;
  maxDate: Date;
  maxDateOfSolemnizationOfmarriage:Date;
  maxDobofBride:Date;
  maxDobofGroom:Date;

  dobdt:any;
  private sub: any;
  public eSewaURL: any;
  public redirect :any;
  public userID :any;
  public serviceID :any;
  public responseData :any;
  public districtList :[];
  public currentdistrictList :[];
  public tehsilList: [];    
  public bridetehsilList:[]; 
  public groomtehsilList:[];
  public currenttehsilList: [];
  public villageList: [];
  public currentvillageList: [];
  public bridevillageList:[];
  public groomvillageList:[];
  public PostGreMasterAPI: any;
  public MarriageServicesAPI: any;
  
  public CurrentRegion: boolean;
  public PermanentRegion: boolean;
  public BrideRegionRural: boolean;
  public GroomRegionRural: boolean;
  
  
  public brideRegion: boolean;
  public groomRegion: boolean;
  public processingtehsilList:[];
  public citizenData: any;
  public citizenAddress : [];
  public maritalstatuslist: [];
  public citizenID: string;  
  public selectedmaritialDetails:any;
  public permanentaddressdistrictDetails:any;
  public currentaddressdistrictDetails:any;
  public permanentaddresstehsilDetails: any;
  public permanentaddressvillageDetails: any;

  public currentaddresstehsilDetails: any;
  public currentaddressvillageDetails: any;

  public BridedistrictDetails: any;
  public BridetehsilDetails: any;
  public BridevillageDetails: any;

  public GroomdistrictDetails: any;
  public GroomtehsilDetails: any;
  public GroomvillageDetails: any;

  public Maritalstatus : boolean = false;
  public IsPermanentAddressInPunjab : boolean = true;
  public IsPermanentAddressOutOfState: boolean = false;
  public IsCurrentAddressNotOutofPunjab : boolean = true;
  public IsCurrentAddressOutOfState: boolean = false;
  public BrideNotNRI: boolean=true;
  public BrideNRIDetails: boolean=false;
  public IsBrideAddressOutOfState: boolean=false;
  public IsGroomAddressOutOfState: boolean=false;
  public IsBrideFromOtherStateInIndia: boolean=true;
  public IsGroonFromOtherStateInIndia: boolean=true;
  

  public GroomNotNRI: boolean=true;
  public GroomNRIDetails: boolean=false;
  public showCurrentaddressCheckbox:boolean=true;
  public ShowCurrentAddressIsSameAsParentAddress :boolean=false;

  public processingOfficesList:any;

  public stateMaster:any;
  public button_text: string = 'Submit'; 
  public captures: Array<any>;
  
 public imagesList: any;
 public appImagesList: any;
 public applicationID: any;
 

  @ViewChild('video', { static: true }) videoElement: ElementRef;
  @ViewChild('video1', { static: true }) videoElement1: ElementRef;

  @ViewChild('canvas', { static: true }) canvas: ElementRef;
  @ViewChild('canvas1', { static: true }) canvas1: ElementRef;
  @ViewChild('canvas2', { static: true }) canvas2: ElementRef;
  @ViewChild('canvas3', { static: true }) canvas3: ElementRef;
  @ViewChild('canvas4', { static: true }) canvas4: ElementRef;

    videoWidth = 0;
    videoHeight = 0;
    constraints = {
        video: {
            facingMode: "environment",
            width: { ideal: 4096 },
            height: { ideal: 2160 }
            // width: { ideal: 2000 },
            // height: { ideal: 4000 }
        }
    };
  public selected: any;
  firstDate: Moment;
  secondDate: Moment;
  diffInDays: number;
 
  public service_data : any;
  public response_data : any;
  public selectedBridemaritialDetails: any;
  public selectedGroommaritialDetails: any;
  bridestateMaster:  any;
  groomstateMaster:  any;
  currentstateMaster:any;
  BridestateDetails: any;
  GroomstateDetails: any;
  citizenCurrentAddress: any;
 
   

    constructor(private _formBuilder: FormBuilder,
      private renderer: Renderer2,
      private route: ActivatedRoute, 
      private _appSettings: AppsettingsService, 
      private _ConfigService: ConfigService,
      private _notification: NotificationService,
      private _commonService: CommonservicesService,
      private loaderService: LoaderService,
      private adapter: DateAdapter<any>,
      private _encdecrService: EncryptiondecryptionserviceService
      ) {
        this.captures = [];
      }
  
      ngOnInit() {
        this.loaderService.show();
        this.sub = this.route.params.subscribe(params => {
          this.token = params['token']; // (+) converts string 'token' to a number      
          this.action = params['action'];  
          if(this.action === 'resubmit'){
            this.applicationID = params['applicationID'];
            this.button_text = 'Resubmit';
          }
          else{
            this.citizenRefCode = params['userID']; 
          }
        });
      
        if(window.localStorage.getItem("TokenID")=='' || window.localStorage.getItem("TokenID")== null || window.localStorage.getItem("TokenID")== undefined ){
          this.ValidateToken(1);
        }
        else{
          if (window.localStorage.getItem("TokenID") == this.token) {
            this.ValidateToken(0);
          }
          else{        
            window.localStorage.clear();
            this.ValidateToken(1);
          }
        }
          //from Group 1 to 8          
          this.firstFormGroup = this._formBuilder.group({     
            Salutation: new FormControl(null,Validators.required),
            first_name: new FormControl(null, [Validators.required,AlphaValidator,Validators.minLength(2), Validators.maxLength(100)]),
            first_name_punjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
            middle_name: new FormControl(null,[AlphaValidator]),
            middle_name_punjabi: new FormControl(null,[OnlyPunjabi]),
            last_name: new FormControl(null,[AlphaValidator]),
            last_name_punjabi: new FormControl(null,[OnlyPunjabi]),

            father_first_name: new FormControl(null,Validators.required),
            father_first_name_punjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
            father_middle_name: new FormControl(null,[AlphaValidator]),
            father_middle_name_punjabi: new FormControl(null,[OnlyPunjabi]),
            father_last_name: new FormControl(null,[AlphaValidator]),
            father_last_name_punjabi: new FormControl(null,[OnlyPunjabi]),

            mother_first_name: new FormControl(null,[Validators.required,AlphaValidator]),
            mother_first_name_punjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
            mother_middle_name: new FormControl(null,[AlphaValidator]),
            mother_middle_name_punjabi: new FormControl(null,[OnlyPunjabi]),
            mother_last_name: new FormControl(null,[AlphaValidator]),
            mother_last_name_punjabi: new FormControl(null,[OnlyPunjabi]),

            gender: new FormControl(null,Validators.required),
            date_of_birth: new FormControl(null,[Validators.required]),
            ApplicantAgeInYear: new FormControl(null),
            ApplicantAgeInMonth: new FormControl(null),
            place_of_birth: new FormControl(null,[Validators.required,EnglishAddress]),
            marital_status: new FormControl(null,[Validators.required]),
            SpouseName: new FormControl(null,[AlphaValidator]),
            SpouseNameinPunjabi: new FormControl(null,[OnlyPunjabi]),
            VoterIdCardNumber: new FormControl(null,[VoterID]),
            AadhaarNumber: new FormControl(null,[Aadhaar]),
            AadhaarEnrollmentNumber: new FormControl(null,[AadhaarEnrolmentNumber]),
            BPLCardNumber: new FormControl(null),
           });                                     
           this.secondFormGroup = this._formBuilder.group({ 
            EmailID: new FormControl(null,[email]),
            PhoneNo : new FormControl(null,[NumericValidator]),
            mobile_no: new FormControl(null,[Validators.required,mobile]),
            isCurrentPermanentaddressSame: new FormControl(null),
            
            // Permanent Address
            AddressIsOutOfState: new FormControl(null),
            address_line_1: new FormControl(null,[ EnglishAddress]),
            address_line_2: new FormControl(null,[ EnglishAddress]),
            address_line_3: new FormControl(null,[ EnglishAddress]),
            PermanentAddressOutOfStateDetails: new FormControl(null,[ EnglishAddress]),
            PermanentAddressOutOfStateDetailsPunjabi: new FormControl(null,[PunjabiAddress]),
            region: new FormControl(null),
            stateID: new FormControl(null),
            districtID: new FormControl(null),
            tehsilID: new FormControl(null),
            villageID: new FormControl(null),
            pincode: new FormControl(null,[Validators.minLength(6)]),
            
             // Current Address
            CurrentAddressIsOutOfState: new FormControl(null),
            CurrentAddressLine1: new FormControl(null,[ EnglishAddress] ),
            CurrentAddressLine2: new FormControl(null,[ EnglishAddress] ),
            CurrentAddressLine3: new FormControl(null ,[ EnglishAddress]),
            CurrentAddressOutOfStateDetails: new FormControl(null,[ EnglishAddress]),
            CurrentAddressOutOfStateDetailsPunjabi: new FormControl(null,[PunjabiAddress]),
            CurrentRegion: new FormControl(null),
            CurrentstateID: new FormControl(null),
            CurrentdistrictID: new FormControl(null),
            CurrenttehsilID: new FormControl(null),
            CurrentVillageID: new FormControl(null),
            Currentpincode: new FormControl(null,[Validators.minLength(6)]),
           });
           this.thirdFormGroup = this._formBuilder.group({
            //thirdCtrl: ['', Validators.required]
            applicantname:new FormControl(null ),  
            applicantaddress:new FormControl(null),          
            PlaceSolemnizationMarriage: new FormControl(null,[Validators.required,EnglishAddress]),           
            // PersonPresentingMemorandum: new FormControl(null,Validators.required),
            ServiceMobileNumber: new FormControl(null,[mobile]),
            ServiceEmail: new FormControl(null,[email]),
            // NameOfPriest: new FormControl(null,[Validators.required,AlphaValidator]),
            // FatherNameOfPriest: new FormControl(null,[AlphaValidator]),
            // AddressOfPriest: new FormControl(null,[Validators.required,EnglishAddress]),
           });
           this.fourthFormGroup = this._formBuilder.group({
             BrideName: new FormControl(null,[Validators.required,AlphaValidator]),
             BrideNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
            //  BrideMotherName: new FormControl(null,[Validators.required,AlphaValidator]),
            //  BrideMotherNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
             BrideFatherName: new FormControl(null,[Validators.required,AlphaValidator]),
             BrideFatherNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
             BrideDateOfBirth: new FormControl(null,Validators.required),
             BrideAgeAtTimeOfMarriageInYear: new FormControl(null),
             BrideAgeAtTimeOfMarriageInMonth: new FormControl(null),
             BrideNationality: new FormControl(null,[Validators.required,AlphaValidator]),
             IsBrideFromOtherState: new FormControl(null),
             BrideAddressOutOfStateDetails: new FormControl(null,[EnglishAddress]),
             BrideAddressOutOfStateDetailsPunjabi: new FormControl(null,[PunjabiAddress]),
             BrideRegion: new FormControl(null),
             BrideState: new FormControl(null),
             BrideDistrict: new FormControl(null),
             BrideTehsil: new FormControl(null),
             BrideVillage: new FormControl(null),
             BridePincode: new FormControl(null,[Validators.minLength(6)]),
             BrideStreetAddressLandmark: new FormControl(null,[ EnglishAddress]),
             BrideStreetAddressLandmarkPunjabi: new FormControl(null,[PunjabiAddress]),
             BrideStatusAtTimeOfMarriage: new FormControl(null,Validators.required),
             BrideAadhaarNumber: new FormControl(null,[Aadhaar]),
             BrideAadhaarEnrollmentNumber: new FormControl(null,[AadhaarEnrolmentNumber]),
             
             Bridecurrentaddressinforeign: new FormControl(null,[EnglishAddress]),
             Bridecurrentaddressinforeignpunjabi: new FormControl(null,[PunjabiAddress]),
             Bridelengthstaycurrentresidance: new FormControl(null,[Validators.required]),
             Brideoccupation: new FormControl(null,[AlphaValidator]),

             IsBrideNRI: new FormControl(null ),
             BridePassportNumber: new FormControl(null,PassportNo ),
             BridePassportIssuanceDate: new FormControl(null ),
             BrideVisaGrantedByCountry: new FormControl(null ),
             BrideVisaType: new FormControl(null),
             BrideVisaDurationInYear: new FormControl(null,[NumOnly]),
             BrideVisaDurationInMonth: new FormControl(null,[NumOnly] ),
             BrideDateOfVisitInIndia: new FormControl(null ),
             BrideSocialSecurityNumber: new FormControl(null,[SocialSecurityNumber] ),
             BrideNRIAddress: new FormControl(null,[ EnglishAddress] ),
             BrideNRIAddressPunjabi: new FormControl(null ,[ PunjabiAddress]),
           });
       
           this.fifthFormGroup = this._formBuilder.group({
             //thirdCtrl: ['', Validators.required]
             GroomName: new FormControl(null,[Validators.required,AlphaValidator]),
             GroomNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
            //  GroomMotherName: new FormControl(null,[Validators.required,AlphaValidator]),
            //  GroomMotherNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
             GroomFatherName: new FormControl(null,[Validators.required,AlphaValidator]),
             GroomFatherNamePunjabi: new FormControl(null,[Validators.required,OnlyPunjabi]),
             GroomDateOfBirth: new FormControl(null,Validators.required),
             GroomAgeAtTimeOfMarriageInYear: new FormControl(null),
             GroomAgeAtTimeOfMarriageInMonth: new FormControl(null),
             GroomNationality: new FormControl(null,[Validators.required,AlphaValidator]),
             IsGroomFromOtherState: new FormControl(null),
             GroomAddressOutOfStateDetails: new FormControl(null,[EnglishAddress]),
             GroomAddressOutOfStateDetailsPunjabi: new FormControl(null,[PunjabiAddress]),
             GroomRegion: new FormControl(null),
             GroomState: new FormControl(null),
             GroomDistrict: new FormControl(null),
             GroomTehsil: new FormControl(null),
             GroomVillage: new FormControl(null),
             GroomPincode: new FormControl(null,[Validators.minLength(6)]),
             GroomStreetAddressLandmark: new FormControl(null),
             GroomStreetAddressLandmarkPunjabi: new FormControl(null),
             GroomStatusAtTimeOfMarriage: new FormControl(null,Validators.required),
             GroomAadhaarNumber: new FormControl(null,[Aadhaar]),
             GroomAadhaarEnrollmentNumber: new FormControl(null,[AadhaarEnrolmentNumber]),
             
             Groomcurrentaddressinforeign: new FormControl(null,[EnglishAddress]),
             Groomcurrentaddressinforeignpunjabi: new FormControl(null,[PunjabiAddress]),
             Groomlengthstaycurrentresidance: new FormControl(null,[Validators.required]),
             Groomoccupation: new FormControl(null,[AlphaValidator]),
             
             IsGroomNRI: new FormControl(null ),
             GroomPassportNumber: new FormControl(null,[PassportNo] ),
             GroomPassportIssuanceDate: new FormControl(null ),
             GroomVisaGrantedByCountry: new FormControl(null ),
             GroomVisaType: new FormControl(null ),
             GroomVisaDurationInYear: new FormControl(null,[NumOnly] ),
             GroomVisaDurationInMonth: new FormControl(null,[NumOnly] ),
             GroomDateOfVisitInIndia: new FormControl(null ),
             GroomSocialSecurityNumber: new FormControl(null,[SocialSecurityNumber] ),
             GroomNRIAddress: new FormControl(null,[EnglishAddress] ),
             GroomNRIAddressPunjabi: new FormControl(null,[PunjabiAddress] ),
        
            });
            this.sixthFormGroup = this._formBuilder.group({
             //thirdCtrl: ['', Validators.required]
             CommonfirstWitnessName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonFirstWitnessRelation: new FormControl(null,[Validators.required]),
             CommonFirstWitnessFatherHusbandName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonFirstWitnessAddress: new FormControl(null,[Validators.required,EnglishAddress]),
             CommonSecondWitnessName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonSecondWitnessRelation: new FormControl(null,[Validators.required]),
             CommonSecondWitnessFatherHusbandName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonSecondWitnessAddress: new FormControl(null,[Validators.required,EnglishAddress]),
             CommonThirdWitnessName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonThirdWitnessRelation: new FormControl(null,[Validators.required]),
             CommonThirdWitnessFatherHusbandName: new FormControl(null,[Validators.required,AlphaValidator]),
             CommonThirdWitnessAddress: new FormControl(null,[Validators.required,EnglishAddress]), 
            });
            this.seventhFormGroup = this._formBuilder.group({
             //thirdCtrl: ['', Validators.required] 
            });
       
            this.eighthFormGroup = this._formBuilder.group({
             //thirdCtrl: ['', Validators.required] 
             ProcessingRegion: new FormControl(null,Validators.required),
             ProcessingDistrict: new FormControl(null,Validators.required),
             ProcessingTehsil: new FormControl(null,Validators.required),
             ProcessingOffice: new FormControl(null,Validators.required),
             ApplicantDeclaration: new FormControl(true,Validators.required),
            });
            this.loaderService.hide();
               // end from Group 1 to 8 
      }
      ValidateToken(redirect){
        // window.localStorage.getItem("token")
         if(this.token != null || this.token !=""){
           var url = this._appSettings.eSewaURL;
           var ValidateToken = this._appSettings.ValidateToken;
           url = url + ValidateToken + this.token;
           
           this._ConfigService.getWithoutHeader(url)
           .subscribe(response => {
             this._notification.responseHandler(response);
             if(response["response"] == 1){  
               if(redirect === 1){
                  window.localStorage.clear();
                  window.localStorage.setItem("TokenID", this.token);
                  //window.localStorage.setItem("token", response["data"][0]["Token"]);
                  window.localStorage.setItem("token", this._encdecrService.Encrypt(response["data"][0]["Token"]));
                  //window.localStorage.setItem("session", response["data"][0]["Session"]);
                  window.localStorage.setItem("session", this._encdecrService.Encrypt(response["data"][0]["Session"]));
                  window.localStorage.setItem("user_type", response["data"][0]["user_type"]);
                  window.location.reload();
               }
               else{
                  this.PostGreMasterAPI = this._appSettings.PostGreMasterAPI;   
                  this.MarriageServicesAPI=this._appSettings.MarriageServicesAPI;               
                  this.eSewaURL = this._appSettings.eSewaURL;
                  this.responseData = response["data"][0];
                  this._commonService.BindMenu();
                  this.userID = this.responseData.userID;                  
                  this.stateMaster= [{response:"1",state_code:"1",state_name:"Punjab"}]; 
                  this.currentstateMaster= [{response:"1",state_code:"1",state_name:"Punjab"}]; 
                  this.bridestateMaster= [{response:"1",state_code:"1",state_name:"Punjab"}];
                  this.groomstateMaster= [{response:"1",state_code:"1",state_name:"Punjab"}];   
                  this.imagesList = [{
                    id: 0,
                    name: 'ApplicantImage',
                    base64: '',
                    docID:''
                  },{
                    id: 1,
                    name: 'ProspectiveBride',
                    base64: '',
                    docID: ''
                  },{
                    id: 2,
                    name: 'ProspectiveBrideGroom',
                    base64: '',
                    docID:''
                  },{
                    id: 3,
                    name: 'BrideGroomAndBrideJoint',
                    base64: '',
                    docID:''
                  },{
                    id: 4,
                    name: 'GroupPhotoOfBrideGroomBrideAndWitness',
                    base64: '',
                    docID:''
                  }]; 
                  this.appImagesList   = [{
                    id: 0,
                    name: 'ApplicantImage',
                    base64: '',
                    docID:''
                  },{
                    id: 1,
                    name: 'ProspectiveBride',
                    base64: '',
                    docID:''
                  },{
                    id: 2,
                    name: 'ProspectiveBrideGroom',
                    base64: '',
                    docID:''
                  },{
                    id: 3,
                    name: 'BrideGroomAndBrideJoint',
                    base64: '',
                    docID:''
                  },{
                    id: 4,
                    name: 'GroupPhotoOfBrideGroomBrideAndWitness',
                    base64: '',
                    docID:''
                  }];          
                  this.serviceID=105;
                  this.fetchAllMasters();
                  this.startCamera();
                //  this.setDefaultImageonload();
                  this.isProcessing=true;
                  this.fetchCitizenProfile();
                  //this.fetchCitizenAddress();
               }
             }
             else {
                window.localStorage.clear();
                this._commonService.BindMenu();
               // window.sessionStorage.clear();
               // window.location.href = environment.eSewaURL;
             }
           },
           err=>{
            // console.log("status code--->"+err.status)
           });
           // In a real app: dispatch action to load the details here.
           }
           else{
             // window.localStorage.clear();
             // window.sessionStorage.clear();
             // window.location.href = environment.eSewaURL;
           }
     }
  
     startCamera() {
      if (!!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) {
          navigator.mediaDevices.getUserMedia(this.constraints).then(this.attachVideo.bind(this)).catch(this.handleError);
      } else {
        this._notification.warning("Sorry, camera not available.","warning");
      }
  }
  
  attachVideo(stream) {
      this.renderer.setProperty(this.videoElement.nativeElement, 'srcObject', stream);
      this.renderer.listen(this.videoElement.nativeElement, 'play', (event) => {
          this.videoHeight = this.videoElement.nativeElement.videoHeight;
          this.videoWidth = this.videoElement.nativeElement.videoWidth;
      });
  
      this.renderer.setProperty(this.videoElement1.nativeElement, 'srcObject', stream);
      this.renderer.listen(this.videoElement1.nativeElement, 'play', (event) => {
          this.videoHeight = this.videoElement1.nativeElement.videoHeight;
          this.videoWidth = this.videoElement1.nativeElement.videoWidth;
      });
  }
  setDefaultImageonload(){      
    {
      var ctx0 = this.canvas.nativeElement.getContext('2d');
      var image0 = new Image();
      image0.onload = function() {
        ctx0.drawImage(image0,0,0,320,150);
      };
     // image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAACI7Fo9AAATEElEQVR4Xu2dC8x1RXWGH61ptQpivCBQDUSUioo3qsVqpFVsK7aVEMUqlRRNjAoNxsaaWFJrW1MvLV4Sb5EGRbyg4gWwamuoLaGKSJWCqCgWQ7FFBZTYimBpVtl/+vHnnDN7n5l9zuw9zyRf/j/51qyZ9ax5v3P27LncAYsEJDB7AneYfYQGKAEJoNAdBBJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojoEaCNwfeAZwGPAo4IA1O/VD4HLgK8BHgLPX9DO7agp9dimtIqA7AvcE7g3cp/t30f+fOHJvTwdeDNw4cjvVu1fo1aeo6g7+AnAw8JDuJ/7/UGCPinr9beCRwHUV9WnjXVHoG0e+9QZLfU3eeiADOvBR4KgB9rMzVejzSWk81x4KPLr7iU/XfecTXnYkxwBnZnuZqAOFPq3EtfhpXCpD/wiMPSdQqq/F/Sj04kiXOpzC8+zmaGy+pWuBvTffbB0tKvS8PMQkz9HA4cCBLQ+kPIwbq313IF7BNVcUer+Uh4hP6GaY49l3v37VtKqMwF7ADyrr00a6o9BXYw4+IfDXAnfeSEZsZCwCVwIPGMt57X4V+uoMfaj7al57Hu1fmkDkMlbfNVkU+vK0HwvEyirLPAg8ATh/HqEMj0KhL2a2D/BVYM/hSK1RIYFTgedX2K+NdUmhL0b9h8DrNpYFGxqTQCyBPaTVSbhdYBX64iEWnwDHjzn69L0RAu8BTgRu2EhrFTei0Bcn54Juy2TFqbNrCwjs3KZ6FnCOlG4joNAXj4R4Pj/IQbJRArcClwCfAj4GxB9bSyECCn0xyPO61W6FMDft5ptALD/9bvez7P//CdzcNKkRg1foi+GeApw0Ive5uQ6Bfh24rDvdJf6NnyuAW+YW7BTjUeiLs3YccNoUE9qzz9cDFwMXds+xfk3uCW6qZgp9cebuNsHjh3ZNRH0J+CJwEXCpX4enKs2y/Vboy3neBPxsWdxFvPlpXARjW04U+vJ8x2aWN48wHHyeHQGqLlcTUOjL+dwX+E7mAHpwt5Q2043VJZBHQKGv5hfvdnPKw7t3wzk+rCuBbAIKfVyhxw64M7KzpAMJZBJQ6KsBfrnbELEu5hcA71i3svUkUIqAQl9NMq71eXoG7BB5iN0iga0SUOir8Z8MvCojQ/E+O85at0hgqwQU+mr8TwXOzchQvEq7q4tWMghatQgBhb4aY1wQGJstcsr+wFU5DqwrgVwCCj1NMPcVm+/S04y1GJmAQk8DVuhpRlpUTkChpxOUewiFn+hpxlqMTEChpwEr9DQjLSonoNDTCVLoaUZaVE5AoacTpNDTjLSonIBCTydIoacZaVE5AYWeTpBCTzPSonICCj2dIIWeZqRF5QQUejpBCj3NSIvKCSj0dIIUepqRFpUTUOjpBCn0NCMtKieg0NMJUuhpRlpUTkChpxOk0NOMtKicgEJPJ0ihpxlpUTkBhZ5OkEJPM9KicgIKPZ0ghZ5mpEXlBBR6OkEKPc1Ii8oJKPR0ghR6mpEWlRNQ6OkEKfQ0Iy0qJ6DQ0wlS6GlGWlROQKGnE6TQ04y0qJyAQk8nSKGnGWlROQGFnk6QQk8z0qJyAgo9nSCFnmakReUEFHo6QQo9zUiLygko9HSCFHqakRaVE1Do6QQp9DQjLSonoNDTCVLoaUZaVE5AoacTlCv0Q4B/TTejhQTGI6DQ02xzhX4McGa6GS0kMB4BhZ5mewnwsLTZUoujgbMy6ltVAtkEFHoa4aeBI9JmSy1eDrwmo75VJZBNQKGnEb4FeGHabKnFqcDzM+pbVQLZBBR6GuFLgL9Omy21+CxweEZ9q0ogm4BCTyP8LeDjabOlFtcA+2XUt6oEsgko9DTCXwQuT5uttLgHcEOmD6tLYG0CCj2N7meAW9JmKy2OBD6R6cPqElibgELvh+5bwP79TBdavQ54WUZ9q0ogi4BC74cv9xXbF4DH9GtKKwmUJ6DQ+zF9BfDn/UyXWsUjwP9k+rC6BNYioND7YfsV4Px+pkut4qv/VZk+rC6BtQgo9H7Y7gTc3M90qdVLM9/HZzZv9ZYJKPT+2b+1v+lCy9jBFjvZLBLYOAGF3h/55zMn1H4M/DyQ+wejf4+1lEBHQKH3HwrvB2LLaU7ZG7g2x4F1JbAOAYXen9rvAe/ub77Q8sFA7G+3SGCjBBR6f9x3A27sb77QsuYJuUcCsXc+NuAcCMS3jzHKj4ArgFhbcA5wLvDTMRrS5/8TUOjDRkPu83UNE3KP6AR9KPAQ4H7DEIxiHUuMTwG+0f0RiH+vdj6jHGuFPozl14AHDatyO+ttTcjtAzwbeB4Qjw9TKNcBn+welz41hQ7X3EeFPiw7U5qQuwtwFPDc7oScOw4LtSrrz3WHd1xWVa8m1BmFPixZU5iQOww4HngWEPMKcyk/Ad4E/DFw01yC2lQcCn0Y6RITcmPMvO8FHAucABw0LKRJWkesZ0yy51vqtEIfDj53Qq7UOe8HADGh1upR0hcCvwP8x/AUtldDoQ/PeQysnFdP65zzvkvUj+7EHQK/+/Cuz7JG7Co8eZaRFQxKoQ+HuYlz3uM5+ynAY4HHKepkkuJdfMyfXJ+0bNRAoQ9PfO4hFMvOeW/tOXs4+dU1/r3bNBSv5Sy7EVDow4dE6XPeHwrEkdLPAX5ueHessYNATNDFRJ1FoWePgVLnvMfRUq8EfjO7RzrYSeAk4I0iuT0BP9GHj4jcc96Ht2iNoQTGeIU5tA9V2Sv04ekocc778FatMZSAYt9BTKEPHT5Q4pz34a1aYyiBeA36q24Lvg2bQh86fG6zz100s16r1hpKIMQe225jM1LTRaGvl/44tnnu7GIjSWwd/XCh/eKx2CcmMuNTdt/1sK9V6+LuCLCm97zPfbCuNTJ6VIpTYuawpjx2g/1NtxX0ez3iLmUSd9HF4RYP7P59UeZqw1S/4lz+V6eM5vx7hb5edqcs9B8A7+sEHqe81FL2AN7Q7bwbo09xes5ZYziegk+Fvl6Wpij0uKf9ncAHK9/m+Xjgn9ZLS7JWPDJ8J2k1QwOFvl5SpyL07wPvAt7aHdO0XrSbrxWHZMQqt9hTX7JcAMStO80Vhb5eymuddY/bZGLTzTXAB7pP7ziwYarlL4E/Ktz53wbOLuyzencKfXiK4vy1ENK2S4j6S0DMKn8RuAi4tMDVUduOa/f247k6jsQqWeKKraZm4RX68OETRza/fni1YjVeCMStMXMU9SJId+6OhX5SMYK3PcrETH8zRaEPT3VMaMVpqpsqU33OLsmntNjjcSbOsf9KyU7W7EuhD89OTOjEwRBjlyuBaCv+qEz5ObsUpxB7XP5Q6jTbOIoqDvZooij04Wkee8Y9bjH5M+C9rT1H9khFicM5dzbzVOBve7Q7eROFPjyF53Xrp4fXXFxj10z5Dd2rMAW+mmzcNBMLfWJCLbfEjTCxOm/2RaEPT3Gs/47DDXJLPOvHaTWtTKrl8tpZ/1UFD4SMq6z/u2TnavSl0Idn5TjgtOHVblcjnjNrfRefGdpGqseRW3G9VYkSbzHeVsJRzT4U+vDsxHNifOVb98jnJwDnD2/WGrsRuG+h5azxByOur5p1Uejrpfdpa66uOrW7Q2y9Vq21O4G4nikmLnPLkcAncp3UXF+hr5+d0weeOPrt7jji2D1mKUMgJuRiMjO3xEafZ+Y6qbm+Ql8/O8HuROA1QLzjXVXe09nGzLqlLIESb0G2dZ11WRIrvCn0fNRxgEJcbnhw97Mf8EPg8m7lVazVPie/GT0sIVBicjRcx5zLtXOlrNDnmtl24sqdHN1Fatanxir0dgQx50jXnRzdyUShz3mEGNtsCOSuS1DosxkKBjJnAjHRmXOVtEKf8+gwttkQyN1spNBnMxQMZM4E/Oru67U5j29j6wgodIWuGGZOoMTFl351n/kgMbzpE4gFSbFePafcD7g6x0HNdX2PXnN27FsfAiV2sd0ExMKbW/o0OEUbhT7FrNnnXQRij0GJQyP+HjhizlgV+pyzO+/YQuTnAr9WIMzZHz6h0AuMEl1snECc0BMi/40CLcds/b2A6wr4qtaFQq82NXZsBYGXdduDS0D6DPDkEo5q9qHQa86OfVtEYC/gKmDPQniauItNoRcaLbrZGIFXAn9SqLW4uy5ubJl9UeizT/GsAoxP83/L3LyyE8jTgY/NitCSYBR6C1meT4z/ADyxUDjNfJoHL4VeaNToZnQCcUPLvxRs5deBTxf0V7UrhV51euxcRyBOe/1ydyZfCShnDDzBt0SbW/Wh0LeK38Z7Eih1fns0dw0QG1jiAM9mikJvJtWTDbTEWvadwc96l9qyLCv0yY7/Jjpeai37LlhNitzJuCa0Mtkg4yLFuCapxFr2gPDygqvpJgfVT/TJpayZDsedavFsXqI09SptETCFXmIY6aM0gXiV9gUgZttLlGYWxviMXmK46GMTBOIAiBsLNhR/MB5T0N8kXfmJPsm0zbbTsf30Rz0urewLIE6MeXh3B17fOrO0U+izTOtkg3o/cEzB3r8VeFFBf5N1pdAnm7pZdTw+yd/QXS1dMrB4xv9pSYdT9aXQp5q5+fQ73pXHDrKnFA6pqbXsKXYKPUXI349JIET+ue45umQ7za1lT8FT6ClC/n4sAnF809+N4LzJtewpjgo9RcjflyYQK97eATy3tOPOX7PLXFfxVOgjjTbdLiTwQODDwMNG4nM0cNZIviftVqFPOn2T6vyzu0/yu47U61cArx7J9+TdKvTJp7D6APYAvgHcZ8Sefg+I7ay+SlsCWaGPOPp0zbOAvwL2HZnFQcDXR25j0u4V+qTTV23nHwW8HTh0Az38A+DNG2hn0k0o9Emnr7rOPwj42gZ75RLXnrAVek9Qmq0kcG/g48Avb5DTFcAhwI832OZkm1Lok03d1jt+GHAk8AwgPsk3WT4JHAdcu8lGp9yWQp9y9jbf97gp5VjgBCAmwLZR/qLgyTPb6P9W2lToW8E+qUYP6CbVztxyr38CxCTfZVvuxySbV+jjpe3A7pPv4O7igXiffHl3CMJHgLPHazrL8/2BZwJHAI8teM9ZTqdi/fqTgK/mOGm5rkIvn/1gemJ34mjszlpWTgdeXPjYpHWiuWd3n1n0pdSJq+v0Y1mduDYpHhe+W9Jpa74UevmMfwiINdd9ytXdJ+emP6niU/t3gViWGuvOax0HIfDYcmrJJFBrgjPD2lr1GJjxST1GibPUvgVcAnwWiJtFh6wG2xP4feA5wC+N0cGCPmM+IPr6XwV9Nu1KoZdL/z7dM2QIalvleuBi4MLujrHo0+HA47bVoYHtxumvxwPxrchSkIBCLwfzpcDry7lrzlPclnpU962lueDHDlihlyP8TuB55dw14ylem/0p8Fogjme2jEBAoZeDegEQq8Us/QnE5QrxLO678f7M1rJU6GthW1jpvO55uJzHeXuKFW4nA7fOO8w6olPo5fJwCnBSOXez9XRld0XS92cbYYWBKfRySYlNFqeVczdLT/E1XUZbSK1CLwc9LgeMI5P2Ludy8p5i6Wos9X0X8M+Tj2bCASj0ssl7WsVr2MtGutpb3Hf2mYELejbZv+baUujlU/4++L+z0loq8bwdn9px4kt8q7FURkChl09IbGQ5p9ttVd57HR5v7pbixlfzDwAfBOJ9uKVSAgp9nMTMUeyx1v4lwEXApUCI3TIRAgp9vESF2M+tdOtnn6jj0zr2zb8XiMVAlgkTUOjjJi/E/lEgrvCdSnnBGjvjphJbs/1U6OOnvu9BFOP3ZHkLsYglzmCP3W+WGRJQ6JtL6u5HS+23W9NxT3isrotLCHe/WmjXKTCx5TR+SlxS+PnuWKu4lDAmDy0zJqDQ55PcODUmjl5+PPAIYP8Bf0jmQ8FIFhJQ6A4MCTRAQKE3kGRDlIBCdwxIoAECCr2BJBuiBBS6Y0ACDRBQ6A0k2RAloNAdAxJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojgEJNEBAoTeQZEOUgEJ3DEigAQIKvYEkG6IEFLpjQAINEFDoDSTZECWg0B0DEmiAgEJvIMmGKAGF7hiQQAMEFHoDSTZECSh0x4AEGiCg0BtIsiFK4H8B2KFPGcGg0XAAAAAASUVORK5CYII=";
     image0.src =('data:image/png;base64,'+this.imagesList[0].base64);    
   //  console.log((this.imagesList));
    }
    {
    //  console.log(this.imagesList[1].base64);
    var ctx1 = this.canvas1.nativeElement.getContext('2d');
    var image1 = new Image();
    image1.onload = function() {
      ctx1.drawImage(image1, 0, 0,300,200);
    };
   // image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAACI7Fo9AAATEElEQVR4Xu2dC8x1RXWGH61ptQpivCBQDUSUioo3qsVqpFVsK7aVEMUqlRRNjAoNxsaaWFJrW1MvLV4Sb5EGRbyg4gWwamuoLaGKSJWCqCgWQ7FFBZTYimBpVtl/+vHnnDN7n5l9zuw9zyRf/j/51qyZ9ax5v3P27LncAYsEJDB7AneYfYQGKAEJoNAdBBJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojoEaCNwfeAZwGPAo4IA1O/VD4HLgK8BHgLPX9DO7agp9dimtIqA7AvcE7g3cp/t30f+fOHJvTwdeDNw4cjvVu1fo1aeo6g7+AnAw8JDuJ/7/UGCPinr9beCRwHUV9WnjXVHoG0e+9QZLfU3eeiADOvBR4KgB9rMzVejzSWk81x4KPLr7iU/XfecTXnYkxwBnZnuZqAOFPq3EtfhpXCpD/wiMPSdQqq/F/Sj04kiXOpzC8+zmaGy+pWuBvTffbB0tKvS8PMQkz9HA4cCBLQ+kPIwbq313IF7BNVcUer+Uh4hP6GaY49l3v37VtKqMwF7ADyrr00a6o9BXYw4+IfDXAnfeSEZsZCwCVwIPGMt57X4V+uoMfaj7al57Hu1fmkDkMlbfNVkU+vK0HwvEyirLPAg8ATh/HqEMj0KhL2a2D/BVYM/hSK1RIYFTgedX2K+NdUmhL0b9h8DrNpYFGxqTQCyBPaTVSbhdYBX64iEWnwDHjzn69L0RAu8BTgRu2EhrFTei0Bcn54Juy2TFqbNrCwjs3KZ6FnCOlG4joNAXj4R4Pj/IQbJRArcClwCfAj4GxB9bSyECCn0xyPO61W6FMDft5ptALD/9bvez7P//CdzcNKkRg1foi+GeApw0Ive5uQ6Bfh24rDvdJf6NnyuAW+YW7BTjUeiLs3YccNoUE9qzz9cDFwMXds+xfk3uCW6qZgp9cebuNsHjh3ZNRH0J+CJwEXCpX4enKs2y/Vboy3neBPxsWdxFvPlpXARjW04U+vJ8x2aWN48wHHyeHQGqLlcTUOjL+dwX+E7mAHpwt5Q2043VJZBHQKGv5hfvdnPKw7t3wzk+rCuBbAIKfVyhxw64M7KzpAMJZBJQ6KsBfrnbELEu5hcA71i3svUkUIqAQl9NMq71eXoG7BB5iN0iga0SUOir8Z8MvCojQ/E+O85at0hgqwQU+mr8TwXOzchQvEq7q4tWMghatQgBhb4aY1wQGJstcsr+wFU5DqwrgVwCCj1NMPcVm+/S04y1GJmAQk8DVuhpRlpUTkChpxOUewiFn+hpxlqMTEChpwEr9DQjLSonoNDTCVLoaUZaVE5AoacTpNDTjLSonIBCTydIoacZaVE5AYWeTpBCTzPSonICCj2dIIWeZqRF5QQUejpBCj3NSIvKCSj0dIIUepqRFpUTUOjpBCn0NCMtKieg0NMJUuhpRlpUTkChpxOk0NOMtKicgEJPJ0ihpxlpUTkBhZ5OkEJPM9KicgIKPZ0ghZ5mpEXlBBR6OkEKPc1Ii8oJKPR0ghR6mpEWlRNQ6OkEKfQ0Iy0qJ6DQ0wlS6GlGWlROQKGnE6TQ04y0qJyAQk8nSKGnGWlROQGFnk6QQk8z0qJyAgo9nSCFnmakReUEFHo6QQo9zUiLygko9HSCFHqakRaVE1Do6QQp9DQjLSonoNDTCVLoaUZaVE5AoacTlCv0Q4B/TTejhQTGI6DQ02xzhX4McGa6GS0kMB4BhZ5mewnwsLTZUoujgbMy6ltVAtkEFHoa4aeBI9JmSy1eDrwmo75VJZBNQKGnEb4FeGHabKnFqcDzM+pbVQLZBBR6GuFLgL9Omy21+CxweEZ9q0ogm4BCTyP8LeDjabOlFtcA+2XUt6oEsgko9DTCXwQuT5uttLgHcEOmD6tLYG0CCj2N7meAW9JmKy2OBD6R6cPqElibgELvh+5bwP79TBdavQ54WUZ9q0ogi4BC74cv9xXbF4DH9GtKKwmUJ6DQ+zF9BfDn/UyXWsUjwP9k+rC6BNYioND7YfsV4Px+pkut4qv/VZk+rC6BtQgo9H7Y7gTc3M90qdVLM9/HZzZv9ZYJKPT+2b+1v+lCy9jBFjvZLBLYOAGF3h/55zMn1H4M/DyQ+wejf4+1lEBHQKH3HwrvB2LLaU7ZG7g2x4F1JbAOAYXen9rvAe/ub77Q8sFA7G+3SGCjBBR6f9x3A27sb77QsuYJuUcCsXc+NuAcCMS3jzHKj4ArgFhbcA5wLvDTMRrS5/8TUOjDRkPu83UNE3KP6AR9KPAQ4H7DEIxiHUuMTwG+0f0RiH+vdj6jHGuFPozl14AHDatyO+ttTcjtAzwbeB4Qjw9TKNcBn+welz41hQ7X3EeFPiw7U5qQuwtwFPDc7oScOw4LtSrrz3WHd1xWVa8m1BmFPixZU5iQOww4HngWEPMKcyk/Ad4E/DFw01yC2lQcCn0Y6RITcmPMvO8FHAucABw0LKRJWkesZ0yy51vqtEIfDj53Qq7UOe8HADGh1upR0hcCvwP8x/AUtldDoQ/PeQysnFdP65zzvkvUj+7EHQK/+/Cuz7JG7Co8eZaRFQxKoQ+HuYlz3uM5+ynAY4HHKepkkuJdfMyfXJ+0bNRAoQ9PfO4hFMvOeW/tOXs4+dU1/r3bNBSv5Sy7EVDow4dE6XPeHwrEkdLPAX5ueHessYNATNDFRJ1FoWePgVLnvMfRUq8EfjO7RzrYSeAk4I0iuT0BP9GHj4jcc96Ht2iNoQTGeIU5tA9V2Sv04ekocc778FatMZSAYt9BTKEPHT5Q4pz34a1aYyiBeA36q24Lvg2bQh86fG6zz100s16r1hpKIMQe225jM1LTRaGvl/44tnnu7GIjSWwd/XCh/eKx2CcmMuNTdt/1sK9V6+LuCLCm97zPfbCuNTJ6VIpTYuawpjx2g/1NtxX0ez3iLmUSd9HF4RYP7P59UeZqw1S/4lz+V6eM5vx7hb5edqcs9B8A7+sEHqe81FL2AN7Q7bwbo09xes5ZYziegk+Fvl6Wpij0uKf9ncAHK9/m+Xjgn9ZLS7JWPDJ8J2k1QwOFvl5SpyL07wPvAt7aHdO0XrSbrxWHZMQqt9hTX7JcAMStO80Vhb5eymuddY/bZGLTzTXAB7pP7ziwYarlL4E/Ktz53wbOLuyzencKfXiK4vy1ENK2S4j6S0DMKn8RuAi4tMDVUduOa/f247k6jsQqWeKKraZm4RX68OETRza/fni1YjVeCMStMXMU9SJId+6OhX5SMYK3PcrETH8zRaEPT3VMaMVpqpsqU33OLsmntNjjcSbOsf9KyU7W7EuhD89OTOjEwRBjlyuBaCv+qEz5ObsUpxB7XP5Q6jTbOIoqDvZooij04Wkee8Y9bjH5M+C9rT1H9khFicM5dzbzVOBve7Q7eROFPjyF53Xrp4fXXFxj10z5Dd2rMAW+mmzcNBMLfWJCLbfEjTCxOm/2RaEPT3Gs/47DDXJLPOvHaTWtTKrl8tpZ/1UFD4SMq6z/u2TnavSl0Idn5TjgtOHVblcjnjNrfRefGdpGqseRW3G9VYkSbzHeVsJRzT4U+vDsxHNifOVb98jnJwDnD2/WGrsRuG+h5azxByOur5p1Uejrpfdpa66uOrW7Q2y9Vq21O4G4nikmLnPLkcAncp3UXF+hr5+d0weeOPrt7jji2D1mKUMgJuRiMjO3xEafZ+Y6qbm+Ql8/O8HuROA1QLzjXVXe09nGzLqlLIESb0G2dZ11WRIrvCn0fNRxgEJcbnhw97Mf8EPg8m7lVazVPie/GT0sIVBicjRcx5zLtXOlrNDnmtl24sqdHN1Fatanxir0dgQx50jXnRzdyUShz3mEGNtsCOSuS1DosxkKBjJnAjHRmXOVtEKf8+gwttkQyN1spNBnMxQMZM4E/Oru67U5j29j6wgodIWuGGZOoMTFl351n/kgMbzpE4gFSbFePafcD7g6x0HNdX2PXnN27FsfAiV2sd0ExMKbW/o0OEUbhT7FrNnnXQRij0GJQyP+HjhizlgV+pyzO+/YQuTnAr9WIMzZHz6h0AuMEl1snECc0BMi/40CLcds/b2A6wr4qtaFQq82NXZsBYGXdduDS0D6DPDkEo5q9qHQa86OfVtEYC/gKmDPQniauItNoRcaLbrZGIFXAn9SqLW4uy5ubJl9UeizT/GsAoxP83/L3LyyE8jTgY/NitCSYBR6C1meT4z/ADyxUDjNfJoHL4VeaNToZnQCcUPLvxRs5deBTxf0V7UrhV51euxcRyBOe/1ydyZfCShnDDzBt0SbW/Wh0LeK38Z7Eih1fns0dw0QG1jiAM9mikJvJtWTDbTEWvadwc96l9qyLCv0yY7/Jjpeai37LlhNitzJuCa0Mtkg4yLFuCapxFr2gPDygqvpJgfVT/TJpayZDsedavFsXqI09SptETCFXmIY6aM0gXiV9gUgZttLlGYWxviMXmK46GMTBOIAiBsLNhR/MB5T0N8kXfmJPsm0zbbTsf30Rz0urewLIE6MeXh3B17fOrO0U+izTOtkg3o/cEzB3r8VeFFBf5N1pdAnm7pZdTw+yd/QXS1dMrB4xv9pSYdT9aXQp5q5+fQ73pXHDrKnFA6pqbXsKXYKPUXI349JIET+ue45umQ7za1lT8FT6ClC/n4sAnF809+N4LzJtewpjgo9RcjflyYQK97eATy3tOPOX7PLXFfxVOgjjTbdLiTwQODDwMNG4nM0cNZIviftVqFPOn2T6vyzu0/yu47U61cArx7J9+TdKvTJp7D6APYAvgHcZ8Sefg+I7ay+SlsCWaGPOPp0zbOAvwL2HZnFQcDXR25j0u4V+qTTV23nHwW8HTh0Az38A+DNG2hn0k0o9Emnr7rOPwj42gZ75RLXnrAVek9Qmq0kcG/g48Avb5DTFcAhwI832OZkm1Lok03d1jt+GHAk8AwgPsk3WT4JHAdcu8lGp9yWQp9y9jbf97gp5VjgBCAmwLZR/qLgyTPb6P9W2lToW8E+qUYP6CbVztxyr38CxCTfZVvuxySbV+jjpe3A7pPv4O7igXiffHl3CMJHgLPHazrL8/2BZwJHAI8teM9ZTqdi/fqTgK/mOGm5rkIvn/1gemJ34mjszlpWTgdeXPjYpHWiuWd3n1n0pdSJq+v0Y1mduDYpHhe+W9Jpa74UevmMfwiINdd9ytXdJ+emP6niU/t3gViWGuvOax0HIfDYcmrJJFBrgjPD2lr1GJjxST1GibPUvgVcAnwWiJtFh6wG2xP4feA5wC+N0cGCPmM+IPr6XwV9Nu1KoZdL/z7dM2QIalvleuBi4MLujrHo0+HA47bVoYHtxumvxwPxrchSkIBCLwfzpcDry7lrzlPclnpU962lueDHDlihlyP8TuB55dw14ylem/0p8Fogjme2jEBAoZeDegEQq8Us/QnE5QrxLO678f7M1rJU6GthW1jpvO55uJzHeXuKFW4nA7fOO8w6olPo5fJwCnBSOXez9XRld0XS92cbYYWBKfRySYlNFqeVczdLT/E1XUZbSK1CLwc9LgeMI5P2Ludy8p5i6Wos9X0X8M+Tj2bCASj0ssl7WsVr2MtGutpb3Hf2mYELejbZv+baUujlU/4++L+z0loq8bwdn9px4kt8q7FURkChl09IbGQ5p9ttVd57HR5v7pbixlfzDwAfBOJ9uKVSAgp9nMTMUeyx1v4lwEXApUCI3TIRAgp9vESF2M+tdOtnn6jj0zr2zb8XiMVAlgkTUOjjJi/E/lEgrvCdSnnBGjvjphJbs/1U6OOnvu9BFOP3ZHkLsYglzmCP3W+WGRJQ6JtL6u5HS+23W9NxT3isrotLCHe/WmjXKTCx5TR+SlxS+PnuWKu4lDAmDy0zJqDQ55PcODUmjl5+PPAIYP8Bf0jmQ8FIFhJQ6A4MCTRAQKE3kGRDlIBCdwxIoAECCr2BJBuiBBS6Y0ACDRBQ6A0k2RAloNAdAxJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojgEJNEBAoTeQZEOUgEJ3DEigAQIKvYEkG6IEFLpjQAINEFDoDSTZECWg0B0DEmiAgEJvIMmGKAGF7hiQQAMEFHoDSTZECSh0x4AEGiCg0BtIsiFK4H8B2KFPGcGg0XAAAAAASUVORK5CYII=";
   image1.src =('data:image/png;base64,'+this.imagesList[1].base64);  
   //console.log(this.imagesList[1].base64);
  }
  {
    var ctx2 = this.canvas2.nativeElement.getContext('2d');
    var image2 = new Image();
    image2.onload = function() {
      ctx2.drawImage(image2, 0, 0,300,200);
    };
   // image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAACI7Fo9AAATEElEQVR4Xu2dC8x1RXWGH61ptQpivCBQDUSUioo3qsVqpFVsK7aVEMUqlRRNjAoNxsaaWFJrW1MvLV4Sb5EGRbyg4gWwamuoLaGKSJWCqCgWQ7FFBZTYimBpVtl/+vHnnDN7n5l9zuw9zyRf/j/51qyZ9ax5v3P27LncAYsEJDB7AneYfYQGKAEJoNAdBBJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojoEaCNwfeAZwGPAo4IA1O/VD4HLgK8BHgLPX9DO7agp9dimtIqA7AvcE7g3cp/t30f+fOHJvTwdeDNw4cjvVu1fo1aeo6g7+AnAw8JDuJ/7/UGCPinr9beCRwHUV9WnjXVHoG0e+9QZLfU3eeiADOvBR4KgB9rMzVejzSWk81x4KPLr7iU/XfecTXnYkxwBnZnuZqAOFPq3EtfhpXCpD/wiMPSdQqq/F/Sj04kiXOpzC8+zmaGy+pWuBvTffbB0tKvS8PMQkz9HA4cCBLQ+kPIwbq313IF7BNVcUer+Uh4hP6GaY49l3v37VtKqMwF7ADyrr00a6o9BXYw4+IfDXAnfeSEZsZCwCVwIPGMt57X4V+uoMfaj7al57Hu1fmkDkMlbfNVkU+vK0HwvEyirLPAg8ATh/HqEMj0KhL2a2D/BVYM/hSK1RIYFTgedX2K+NdUmhL0b9h8DrNpYFGxqTQCyBPaTVSbhdYBX64iEWnwDHjzn69L0RAu8BTgRu2EhrFTei0Bcn54Juy2TFqbNrCwjs3KZ6FnCOlG4joNAXj4R4Pj/IQbJRArcClwCfAj4GxB9bSyECCn0xyPO61W6FMDft5ptALD/9bvez7P//CdzcNKkRg1foi+GeApw0Ive5uQ6Bfh24rDvdJf6NnyuAW+YW7BTjUeiLs3YccNoUE9qzz9cDFwMXds+xfk3uCW6qZgp9cebuNsHjh3ZNRH0J+CJwEXCpX4enKs2y/Vboy3neBPxsWdxFvPlpXARjW04U+vJ8x2aWN48wHHyeHQGqLlcTUOjL+dwX+E7mAHpwt5Q2043VJZBHQKGv5hfvdnPKw7t3wzk+rCuBbAIKfVyhxw64M7KzpAMJZBJQ6KsBfrnbELEu5hcA71i3svUkUIqAQl9NMq71eXoG7BB5iN0iga0SUOir8Z8MvCojQ/E+O85at0hgqwQU+mr8TwXOzchQvEq7q4tWMghatQgBhb4aY1wQGJstcsr+wFU5DqwrgVwCCj1NMPcVm+/S04y1GJmAQk8DVuhpRlpUTkChpxOUewiFn+hpxlqMTEChpwEr9DQjLSonoNDTCVLoaUZaVE5AoacTpNDTjLSonIBCTydIoacZaVE5AYWeTpBCTzPSonICCj2dIIWeZqRF5QQUejpBCj3NSIvKCSj0dIIUepqRFpUTUOjpBCn0NCMtKieg0NMJUuhpRlpUTkChpxOk0NOMtKicgEJPJ0ihpxlpUTkBhZ5OkEJPM9KicgIKPZ0ghZ5mpEXlBBR6OkEKPc1Ii8oJKPR0ghR6mpEWlRNQ6OkEKfQ0Iy0qJ6DQ0wlS6GlGWlROQKGnE6TQ04y0qJyAQk8nSKGnGWlROQGFnk6QQk8z0qJyAgo9nSCFnmakReUEFHo6QQo9zUiLygko9HSCFHqakRaVE1Do6QQp9DQjLSonoNDTCVLoaUZaVE5AoacTlCv0Q4B/TTejhQTGI6DQ02xzhX4McGa6GS0kMB4BhZ5mewnwsLTZUoujgbMy6ltVAtkEFHoa4aeBI9JmSy1eDrwmo75VJZBNQKGnEb4FeGHabKnFqcDzM+pbVQLZBBR6GuFLgL9Omy21+CxweEZ9q0ogm4BCTyP8LeDjabOlFtcA+2XUt6oEsgko9DTCXwQuT5uttLgHcEOmD6tLYG0CCj2N7meAW9JmKy2OBD6R6cPqElibgELvh+5bwP79TBdavQ54WUZ9q0ogi4BC74cv9xXbF4DH9GtKKwmUJ6DQ+zF9BfDn/UyXWsUjwP9k+rC6BNYioND7YfsV4Px+pkut4qv/VZk+rC6BtQgo9H7Y7gTc3M90qdVLM9/HZzZv9ZYJKPT+2b+1v+lCy9jBFjvZLBLYOAGF3h/55zMn1H4M/DyQ+wejf4+1lEBHQKH3HwrvB2LLaU7ZG7g2x4F1JbAOAYXen9rvAe/ub77Q8sFA7G+3SGCjBBR6f9x3A27sb77QsuYJuUcCsXc+NuAcCMS3jzHKj4ArgFhbcA5wLvDTMRrS5/8TUOjDRkPu83UNE3KP6AR9KPAQ4H7DEIxiHUuMTwG+0f0RiH+vdj6jHGuFPozl14AHDatyO+ttTcjtAzwbeB4Qjw9TKNcBn+welz41hQ7X3EeFPiw7U5qQuwtwFPDc7oScOw4LtSrrz3WHd1xWVa8m1BmFPixZU5iQOww4HngWEPMKcyk/Ad4E/DFw01yC2lQcCn0Y6RITcmPMvO8FHAucABw0LKRJWkesZ0yy51vqtEIfDj53Qq7UOe8HADGh1upR0hcCvwP8x/AUtldDoQ/PeQysnFdP65zzvkvUj+7EHQK/+/Cuz7JG7Co8eZaRFQxKoQ+HuYlz3uM5+ynAY4HHKepkkuJdfMyfXJ+0bNRAoQ9PfO4hFMvOeW/tOXs4+dU1/r3bNBSv5Sy7EVDow4dE6XPeHwrEkdLPAX5ueHessYNATNDFRJ1FoWePgVLnvMfRUq8EfjO7RzrYSeAk4I0iuT0BP9GHj4jcc96Ht2iNoQTGeIU5tA9V2Sv04ekocc778FatMZSAYt9BTKEPHT5Q4pz34a1aYyiBeA36q24Lvg2bQh86fG6zz100s16r1hpKIMQe225jM1LTRaGvl/44tnnu7GIjSWwd/XCh/eKx2CcmMuNTdt/1sK9V6+LuCLCm97zPfbCuNTJ6VIpTYuawpjx2g/1NtxX0ez3iLmUSd9HF4RYP7P59UeZqw1S/4lz+V6eM5vx7hb5edqcs9B8A7+sEHqe81FL2AN7Q7bwbo09xes5ZYziegk+Fvl6Wpij0uKf9ncAHK9/m+Xjgn9ZLS7JWPDJ8J2k1QwOFvl5SpyL07wPvAt7aHdO0XrSbrxWHZMQqt9hTX7JcAMStO80Vhb5eymuddY/bZGLTzTXAB7pP7ziwYarlL4E/Ktz53wbOLuyzencKfXiK4vy1ENK2S4j6S0DMKn8RuAi4tMDVUduOa/f247k6jsQqWeKKraZm4RX68OETRza/fni1YjVeCMStMXMU9SJId+6OhX5SMYK3PcrETH8zRaEPT3VMaMVpqpsqU33OLsmntNjjcSbOsf9KyU7W7EuhD89OTOjEwRBjlyuBaCv+qEz5ObsUpxB7XP5Q6jTbOIoqDvZooij04Wkee8Y9bjH5M+C9rT1H9khFicM5dzbzVOBve7Q7eROFPjyF53Xrp4fXXFxj10z5Dd2rMAW+mmzcNBMLfWJCLbfEjTCxOm/2RaEPT3Gs/47DDXJLPOvHaTWtTKrl8tpZ/1UFD4SMq6z/u2TnavSl0Idn5TjgtOHVblcjnjNrfRefGdpGqseRW3G9VYkSbzHeVsJRzT4U+vDsxHNifOVb98jnJwDnD2/WGrsRuG+h5azxByOur5p1Uejrpfdpa66uOrW7Q2y9Vq21O4G4nikmLnPLkcAncp3UXF+hr5+d0weeOPrt7jji2D1mKUMgJuRiMjO3xEafZ+Y6qbm+Ql8/O8HuROA1QLzjXVXe09nGzLqlLIESb0G2dZ11WRIrvCn0fNRxgEJcbnhw97Mf8EPg8m7lVazVPie/GT0sIVBicjRcx5zLtXOlrNDnmtl24sqdHN1Fatanxir0dgQx50jXnRzdyUShz3mEGNtsCOSuS1DosxkKBjJnAjHRmXOVtEKf8+gwttkQyN1spNBnMxQMZM4E/Oru67U5j29j6wgodIWuGGZOoMTFl351n/kgMbzpE4gFSbFePafcD7g6x0HNdX2PXnN27FsfAiV2sd0ExMKbW/o0OEUbhT7FrNnnXQRij0GJQyP+HjhizlgV+pyzO+/YQuTnAr9WIMzZHz6h0AuMEl1snECc0BMi/40CLcds/b2A6wr4qtaFQq82NXZsBYGXdduDS0D6DPDkEo5q9qHQa86OfVtEYC/gKmDPQniauItNoRcaLbrZGIFXAn9SqLW4uy5ubJl9UeizT/GsAoxP83/L3LyyE8jTgY/NitCSYBR6C1meT4z/ADyxUDjNfJoHL4VeaNToZnQCcUPLvxRs5deBTxf0V7UrhV51euxcRyBOe/1ydyZfCShnDDzBt0SbW/Wh0LeK38Z7Eih1fns0dw0QG1jiAM9mikJvJtWTDbTEWvadwc96l9qyLCv0yY7/Jjpeai37LlhNitzJuCa0Mtkg4yLFuCapxFr2gPDygqvpJgfVT/TJpayZDsedavFsXqI09SptETCFXmIY6aM0gXiV9gUgZttLlGYWxviMXmK46GMTBOIAiBsLNhR/MB5T0N8kXfmJPsm0zbbTsf30Rz0urewLIE6MeXh3B17fOrO0U+izTOtkg3o/cEzB3r8VeFFBf5N1pdAnm7pZdTw+yd/QXS1dMrB4xv9pSYdT9aXQp5q5+fQ73pXHDrKnFA6pqbXsKXYKPUXI349JIET+ue45umQ7za1lT8FT6ClC/n4sAnF809+N4LzJtewpjgo9RcjflyYQK97eATy3tOPOX7PLXFfxVOgjjTbdLiTwQODDwMNG4nM0cNZIviftVqFPOn2T6vyzu0/yu47U61cArx7J9+TdKvTJp7D6APYAvgHcZ8Sefg+I7ay+SlsCWaGPOPp0zbOAvwL2HZnFQcDXR25j0u4V+qTTV23nHwW8HTh0Az38A+DNG2hn0k0o9Emnr7rOPwj42gZ75RLXnrAVek9Qmq0kcG/g48Avb5DTFcAhwI832OZkm1Lok03d1jt+GHAk8AwgPsk3WT4JHAdcu8lGp9yWQp9y9jbf97gp5VjgBCAmwLZR/qLgyTPb6P9W2lToW8E+qUYP6CbVztxyr38CxCTfZVvuxySbV+jjpe3A7pPv4O7igXiffHl3CMJHgLPHazrL8/2BZwJHAI8teM9ZTqdi/fqTgK/mOGm5rkIvn/1gemJ34mjszlpWTgdeXPjYpHWiuWd3n1n0pdSJq+v0Y1mduDYpHhe+W9Jpa74UevmMfwiINdd9ytXdJ+emP6niU/t3gViWGuvOax0HIfDYcmrJJFBrgjPD2lr1GJjxST1GibPUvgVcAnwWiJtFh6wG2xP4feA5wC+N0cGCPmM+IPr6XwV9Nu1KoZdL/z7dM2QIalvleuBi4MLujrHo0+HA47bVoYHtxumvxwPxrchSkIBCLwfzpcDry7lrzlPclnpU962lueDHDlihlyP8TuB55dw14ylem/0p8Fogjme2jEBAoZeDegEQq8Us/QnE5QrxLO678f7M1rJU6GthW1jpvO55uJzHeXuKFW4nA7fOO8w6olPo5fJwCnBSOXez9XRld0XS92cbYYWBKfRySYlNFqeVczdLT/E1XUZbSK1CLwc9LgeMI5P2Ludy8p5i6Wos9X0X8M+Tj2bCASj0ssl7WsVr2MtGutpb3Hf2mYELejbZv+baUujlU/4++L+z0loq8bwdn9px4kt8q7FURkChl09IbGQ5p9ttVd57HR5v7pbixlfzDwAfBOJ9uKVSAgp9nMTMUeyx1v4lwEXApUCI3TIRAgp9vESF2M+tdOtnn6jj0zr2zb8XiMVAlgkTUOjjJi/E/lEgrvCdSnnBGjvjphJbs/1U6OOnvu9BFOP3ZHkLsYglzmCP3W+WGRJQ6JtL6u5HS+23W9NxT3isrotLCHe/WmjXKTCx5TR+SlxS+PnuWKu4lDAmDy0zJqDQ55PcODUmjl5+PPAIYP8Bf0jmQ8FIFhJQ6A4MCTRAQKE3kGRDlIBCdwxIoAECCr2BJBuiBBS6Y0ACDRBQ6A0k2RAloNAdAxJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojgEJNEBAoTeQZEOUgEJ3DEigAQIKvYEkG6IEFLpjQAINEFDoDSTZECWg0B0DEmiAgEJvIMmGKAGF7hiQQAMEFHoDSTZECSh0x4AEGiCg0BtIsiFK4H8B2KFPGcGg0XAAAAAASUVORK5CYII=";
   image2.src =('data:image/png;base64,'+this.imagesList[2].base64);  
  // console.log((this.imagesList));
  }
  {
    var ctx3 = this.canvas3.nativeElement.getContext('2d');
    var image3 = new Image();
    image3.onload = function() {
      ctx3.drawImage(image3, 0, 0,300,200);
    };
   // image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAACI7Fo9AAATEElEQVR4Xu2dC8x1RXWGH61ptQpivCBQDUSUioo3qsVqpFVsK7aVEMUqlRRNjAoNxsaaWFJrW1MvLV4Sb5EGRbyg4gWwamuoLaGKSJWCqCgWQ7FFBZTYimBpVtl/+vHnnDN7n5l9zuw9zyRf/j/51qyZ9ax5v3P27LncAYsEJDB7AneYfYQGKAEJoNAdBBJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojoEaCNwfeAZwGPAo4IA1O/VD4HLgK8BHgLPX9DO7agp9dimtIqA7AvcE7g3cp/t30f+fOHJvTwdeDNw4cjvVu1fo1aeo6g7+AnAw8JDuJ/7/UGCPinr9beCRwHUV9WnjXVHoG0e+9QZLfU3eeiADOvBR4KgB9rMzVejzSWk81x4KPLr7iU/XfecTXnYkxwBnZnuZqAOFPq3EtfhpXCpD/wiMPSdQqq/F/Sj04kiXOpzC8+zmaGy+pWuBvTffbB0tKvS8PMQkz9HA4cCBLQ+kPIwbq313IF7BNVcUer+Uh4hP6GaY49l3v37VtKqMwF7ADyrr00a6o9BXYw4+IfDXAnfeSEZsZCwCVwIPGMt57X4V+uoMfaj7al57Hu1fmkDkMlbfNVkU+vK0HwvEyirLPAg8ATh/HqEMj0KhL2a2D/BVYM/hSK1RIYFTgedX2K+NdUmhL0b9h8DrNpYFGxqTQCyBPaTVSbhdYBX64iEWnwDHjzn69L0RAu8BTgRu2EhrFTei0Bcn54Juy2TFqbNrCwjs3KZ6FnCOlG4joNAXj4R4Pj/IQbJRArcClwCfAj4GxB9bSyECCn0xyPO61W6FMDft5ptALD/9bvez7P//CdzcNKkRg1foi+GeApw0Ive5uQ6Bfh24rDvdJf6NnyuAW+YW7BTjUeiLs3YccNoUE9qzz9cDFwMXds+xfk3uCW6qZgp9cebuNsHjh3ZNRH0J+CJwEXCpX4enKs2y/Vboy3neBPxsWdxFvPlpXARjW04U+vJ8x2aWN48wHHyeHQGqLlcTUOjL+dwX+E7mAHpwt5Q2043VJZBHQKGv5hfvdnPKw7t3wzk+rCuBbAIKfVyhxw64M7KzpAMJZBJQ6KsBfrnbELEu5hcA71i3svUkUIqAQl9NMq71eXoG7BB5iN0iga0SUOir8Z8MvCojQ/E+O85at0hgqwQU+mr8TwXOzchQvEq7q4tWMghatQgBhb4aY1wQGJstcsr+wFU5DqwrgVwCCj1NMPcVm+/S04y1GJmAQk8DVuhpRlpUTkChpxOUewiFn+hpxlqMTEChpwEr9DQjLSonoNDTCVLoaUZaVE5AoacTpNDTjLSonIBCTydIoacZaVE5AYWeTpBCTzPSonICCj2dIIWeZqRF5QQUejpBCj3NSIvKCSj0dIIUepqRFpUTUOjpBCn0NCMtKieg0NMJUuhpRlpUTkChpxOk0NOMtKicgEJPJ0ihpxlpUTkBhZ5OkEJPM9KicgIKPZ0ghZ5mpEXlBBR6OkEKPc1Ii8oJKPR0ghR6mpEWlRNQ6OkEKfQ0Iy0qJ6DQ0wlS6GlGWlROQKGnE6TQ04y0qJyAQk8nSKGnGWlROQGFnk6QQk8z0qJyAgo9nSCFnmakReUEFHo6QQo9zUiLygko9HSCFHqakRaVE1Do6QQp9DQjLSonoNDTCVLoaUZaVE5AoacTlCv0Q4B/TTejhQTGI6DQ02xzhX4McGa6GS0kMB4BhZ5mewnwsLTZUoujgbMy6ltVAtkEFHoa4aeBI9JmSy1eDrwmo75VJZBNQKGnEb4FeGHabKnFqcDzM+pbVQLZBBR6GuFLgL9Omy21+CxweEZ9q0ogm4BCTyP8LeDjabOlFtcA+2XUt6oEsgko9DTCXwQuT5uttLgHcEOmD6tLYG0CCj2N7meAW9JmKy2OBD6R6cPqElibgELvh+5bwP79TBdavQ54WUZ9q0ogi4BC74cv9xXbF4DH9GtKKwmUJ6DQ+zF9BfDn/UyXWsUjwP9k+rC6BNYioND7YfsV4Px+pkut4qv/VZk+rC6BtQgo9H7Y7gTc3M90qdVLM9/HZzZv9ZYJKPT+2b+1v+lCy9jBFjvZLBLYOAGF3h/55zMn1H4M/DyQ+wejf4+1lEBHQKH3HwrvB2LLaU7ZG7g2x4F1JbAOAYXen9rvAe/ub77Q8sFA7G+3SGCjBBR6f9x3A27sb77QsuYJuUcCsXc+NuAcCMS3jzHKj4ArgFhbcA5wLvDTMRrS5/8TUOjDRkPu83UNE3KP6AR9KPAQ4H7DEIxiHUuMTwG+0f0RiH+vdj6jHGuFPozl14AHDatyO+ttTcjtAzwbeB4Qjw9TKNcBn+welz41hQ7X3EeFPiw7U5qQuwtwFPDc7oScOw4LtSrrz3WHd1xWVa8m1BmFPixZU5iQOww4HngWEPMKcyk/Ad4E/DFw01yC2lQcCn0Y6RITcmPMvO8FHAucABw0LKRJWkesZ0yy51vqtEIfDj53Qq7UOe8HADGh1upR0hcCvwP8x/AUtldDoQ/PeQysnFdP65zzvkvUj+7EHQK/+/Cuz7JG7Co8eZaRFQxKoQ+HuYlz3uM5+ynAY4HHKepkkuJdfMyfXJ+0bNRAoQ9PfO4hFMvOeW/tOXs4+dU1/r3bNBSv5Sy7EVDow4dE6XPeHwrEkdLPAX5ueHessYNATNDFRJ1FoWePgVLnvMfRUq8EfjO7RzrYSeAk4I0iuT0BP9GHj4jcc96Ht2iNoQTGeIU5tA9V2Sv04ekocc778FatMZSAYt9BTKEPHT5Q4pz34a1aYyiBeA36q24Lvg2bQh86fG6zz100s16r1hpKIMQe225jM1LTRaGvl/44tnnu7GIjSWwd/XCh/eKx2CcmMuNTdt/1sK9V6+LuCLCm97zPfbCuNTJ6VIpTYuawpjx2g/1NtxX0ez3iLmUSd9HF4RYP7P59UeZqw1S/4lz+V6eM5vx7hb5edqcs9B8A7+sEHqe81FL2AN7Q7bwbo09xes5ZYziegk+Fvl6Wpij0uKf9ncAHK9/m+Xjgn9ZLS7JWPDJ8J2k1QwOFvl5SpyL07wPvAt7aHdO0XrSbrxWHZMQqt9hTX7JcAMStO80Vhb5eymuddY/bZGLTzTXAB7pP7ziwYarlL4E/Ktz53wbOLuyzencKfXiK4vy1ENK2S4j6S0DMKn8RuAi4tMDVUduOa/f247k6jsQqWeKKraZm4RX68OETRza/fni1YjVeCMStMXMU9SJId+6OhX5SMYK3PcrETH8zRaEPT3VMaMVpqpsqU33OLsmntNjjcSbOsf9KyU7W7EuhD89OTOjEwRBjlyuBaCv+qEz5ObsUpxB7XP5Q6jTbOIoqDvZooij04Wkee8Y9bjH5M+C9rT1H9khFicM5dzbzVOBve7Q7eROFPjyF53Xrp4fXXFxj10z5Dd2rMAW+mmzcNBMLfWJCLbfEjTCxOm/2RaEPT3Gs/47DDXJLPOvHaTWtTKrl8tpZ/1UFD4SMq6z/u2TnavSl0Idn5TjgtOHVblcjnjNrfRefGdpGqseRW3G9VYkSbzHeVsJRzT4U+vDsxHNifOVb98jnJwDnD2/WGrsRuG+h5azxByOur5p1Uejrpfdpa66uOrW7Q2y9Vq21O4G4nikmLnPLkcAncp3UXF+hr5+d0weeOPrt7jji2D1mKUMgJuRiMjO3xEafZ+Y6qbm+Ql8/O8HuROA1QLzjXVXe09nGzLqlLIESb0G2dZ11WRIrvCn0fNRxgEJcbnhw97Mf8EPg8m7lVazVPie/GT0sIVBicjRcx5zLtXOlrNDnmtl24sqdHN1Fatanxir0dgQx50jXnRzdyUShz3mEGNtsCOSuS1DosxkKBjJnAjHRmXOVtEKf8+gwttkQyN1spNBnMxQMZM4E/Oru67U5j29j6wgodIWuGGZOoMTFl351n/kgMbzpE4gFSbFePafcD7g6x0HNdX2PXnN27FsfAiV2sd0ExMKbW/o0OEUbhT7FrNnnXQRij0GJQyP+HjhizlgV+pyzO+/YQuTnAr9WIMzZHz6h0AuMEl1snECc0BMi/40CLcds/b2A6wr4qtaFQq82NXZsBYGXdduDS0D6DPDkEo5q9qHQa86OfVtEYC/gKmDPQniauItNoRcaLbrZGIFXAn9SqLW4uy5ubJl9UeizT/GsAoxP83/L3LyyE8jTgY/NitCSYBR6C1meT4z/ADyxUDjNfJoHL4VeaNToZnQCcUPLvxRs5deBTxf0V7UrhV51euxcRyBOe/1ydyZfCShnDDzBt0SbW/Wh0LeK38Z7Eih1fns0dw0QG1jiAM9mikJvJtWTDbTEWvadwc96l9qyLCv0yY7/Jjpeai37LlhNitzJuCa0Mtkg4yLFuCapxFr2gPDygqvpJgfVT/TJpayZDsedavFsXqI09SptETCFXmIY6aM0gXiV9gUgZttLlGYWxviMXmK46GMTBOIAiBsLNhR/MB5T0N8kXfmJPsm0zbbTsf30Rz0urewLIE6MeXh3B17fOrO0U+izTOtkg3o/cEzB3r8VeFFBf5N1pdAnm7pZdTw+yd/QXS1dMrB4xv9pSYdT9aXQp5q5+fQ73pXHDrKnFA6pqbXsKXYKPUXI349JIET+ue45umQ7za1lT8FT6ClC/n4sAnF809+N4LzJtewpjgo9RcjflyYQK97eATy3tOPOX7PLXFfxVOgjjTbdLiTwQODDwMNG4nM0cNZIviftVqFPOn2T6vyzu0/yu47U61cArx7J9+TdKvTJp7D6APYAvgHcZ8Sefg+I7ay+SlsCWaGPOPp0zbOAvwL2HZnFQcDXR25j0u4V+qTTV23nHwW8HTh0Az38A+DNG2hn0k0o9Emnr7rOPwj42gZ75RLXnrAVek9Qmq0kcG/g48Avb5DTFcAhwI832OZkm1Lok03d1jt+GHAk8AwgPsk3WT4JHAdcu8lGp9yWQp9y9jbf97gp5VjgBCAmwLZR/qLgyTPb6P9W2lToW8E+qUYP6CbVztxyr38CxCTfZVvuxySbV+jjpe3A7pPv4O7igXiffHl3CMJHgLPHazrL8/2BZwJHAI8teM9ZTqdi/fqTgK/mOGm5rkIvn/1gemJ34mjszlpWTgdeXPjYpHWiuWd3n1n0pdSJq+v0Y1mduDYpHhe+W9Jpa74UevmMfwiINdd9ytXdJ+emP6niU/t3gViWGuvOax0HIfDYcmrJJFBrgjPD2lr1GJjxST1GibPUvgVcAnwWiJtFh6wG2xP4feA5wC+N0cGCPmM+IPr6XwV9Nu1KoZdL/z7dM2QIalvleuBi4MLujrHo0+HA47bVoYHtxumvxwPxrchSkIBCLwfzpcDry7lrzlPclnpU962lueDHDlihlyP8TuB55dw14ylem/0p8Fogjme2jEBAoZeDegEQq8Us/QnE5QrxLO678f7M1rJU6GthW1jpvO55uJzHeXuKFW4nA7fOO8w6olPo5fJwCnBSOXez9XRld0XS92cbYYWBKfRySYlNFqeVczdLT/E1XUZbSK1CLwc9LgeMI5P2Ludy8p5i6Wos9X0X8M+Tj2bCASj0ssl7WsVr2MtGutpb3Hf2mYELejbZv+baUujlU/4++L+z0loq8bwdn9px4kt8q7FURkChl09IbGQ5p9ttVd57HR5v7pbixlfzDwAfBOJ9uKVSAgp9nMTMUeyx1v4lwEXApUCI3TIRAgp9vESF2M+tdOtnn6jj0zr2zb8XiMVAlgkTUOjjJi/E/lEgrvCdSnnBGjvjphJbs/1U6OOnvu9BFOP3ZHkLsYglzmCP3W+WGRJQ6JtL6u5HS+23W9NxT3isrotLCHe/WmjXKTCx5TR+SlxS+PnuWKu4lDAmDy0zJqDQ55PcODUmjl5+PPAIYP8Bf0jmQ8FIFhJQ6A4MCTRAQKE3kGRDlIBCdwxIoAECCr2BJBuiBBS6Y0ACDRBQ6A0k2RAloNAdAxJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojgEJNEBAoTeQZEOUgEJ3DEigAQIKvYEkG6IEFLpjQAINEFDoDSTZECWg0B0DEmiAgEJvIMmGKAGF7hiQQAMEFHoDSTZECSh0x4AEGiCg0BtIsiFK4H8B2KFPGcGg0XAAAAAASUVORK5CYII=";
   image3.src =('data:image/png;base64,'+this.imagesList[3].base64);  
  // console.log((this.imagesList));
  }
  {
    var ctx4 = this.canvas4.nativeElement.getContext('2d');
    var image4 = new Image();
    image4.onload = function() {
      ctx4.drawImage(image4, 0, 0,300,200);
    };
   // image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAYAAACI7Fo9AAATEElEQVR4Xu2dC8x1RXWGH61ptQpivCBQDUSUioo3qsVqpFVsK7aVEMUqlRRNjAoNxsaaWFJrW1MvLV4Sb5EGRbyg4gWwamuoLaGKSJWCqCgWQ7FFBZTYimBpVtl/+vHnnDN7n5l9zuw9zyRf/j/51qyZ9ax5v3P27LncAYsEJDB7AneYfYQGKAEJoNAdBBJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojoEaCNwfeAZwGPAo4IA1O/VD4HLgK8BHgLPX9DO7agp9dimtIqA7AvcE7g3cp/t30f+fOHJvTwdeDNw4cjvVu1fo1aeo6g7+AnAw8JDuJ/7/UGCPinr9beCRwHUV9WnjXVHoG0e+9QZLfU3eeiADOvBR4KgB9rMzVejzSWk81x4KPLr7iU/XfecTXnYkxwBnZnuZqAOFPq3EtfhpXCpD/wiMPSdQqq/F/Sj04kiXOpzC8+zmaGy+pWuBvTffbB0tKvS8PMQkz9HA4cCBLQ+kPIwbq313IF7BNVcUer+Uh4hP6GaY49l3v37VtKqMwF7ADyrr00a6o9BXYw4+IfDXAnfeSEZsZCwCVwIPGMt57X4V+uoMfaj7al57Hu1fmkDkMlbfNVkU+vK0HwvEyirLPAg8ATh/HqEMj0KhL2a2D/BVYM/hSK1RIYFTgedX2K+NdUmhL0b9h8DrNpYFGxqTQCyBPaTVSbhdYBX64iEWnwDHjzn69L0RAu8BTgRu2EhrFTei0Bcn54Juy2TFqbNrCwjs3KZ6FnCOlG4joNAXj4R4Pj/IQbJRArcClwCfAj4GxB9bSyECCn0xyPO61W6FMDft5ptALD/9bvez7P//CdzcNKkRg1foi+GeApw0Ive5uQ6Bfh24rDvdJf6NnyuAW+YW7BTjUeiLs3YccNoUE9qzz9cDFwMXds+xfk3uCW6qZgp9cebuNsHjh3ZNRH0J+CJwEXCpX4enKs2y/Vboy3neBPxsWdxFvPlpXARjW04U+vJ8x2aWN48wHHyeHQGqLlcTUOjL+dwX+E7mAHpwt5Q2043VJZBHQKGv5hfvdnPKw7t3wzk+rCuBbAIKfVyhxw64M7KzpAMJZBJQ6KsBfrnbELEu5hcA71i3svUkUIqAQl9NMq71eXoG7BB5iN0iga0SUOir8Z8MvCojQ/E+O85at0hgqwQU+mr8TwXOzchQvEq7q4tWMghatQgBhb4aY1wQGJstcsr+wFU5DqwrgVwCCj1NMPcVm+/S04y1GJmAQk8DVuhpRlpUTkChpxOUewiFn+hpxlqMTEChpwEr9DQjLSonoNDTCVLoaUZaVE5AoacTpNDTjLSonIBCTydIoacZaVE5AYWeTpBCTzPSonICCj2dIIWeZqRF5QQUejpBCj3NSIvKCSj0dIIUepqRFpUTUOjpBCn0NCMtKieg0NMJUuhpRlpUTkChpxOk0NOMtKicgEJPJ0ihpxlpUTkBhZ5OkEJPM9KicgIKPZ0ghZ5mpEXlBBR6OkEKPc1Ii8oJKPR0ghR6mpEWlRNQ6OkEKfQ0Iy0qJ6DQ0wlS6GlGWlROQKGnE6TQ04y0qJyAQk8nSKGnGWlROQGFnk6QQk8z0qJyAgo9nSCFnmakReUEFHo6QQo9zUiLygko9HSCFHqakRaVE1Do6QQp9DQjLSonoNDTCVLoaUZaVE5AoacTlCv0Q4B/TTejhQTGI6DQ02xzhX4McGa6GS0kMB4BhZ5mewnwsLTZUoujgbMy6ltVAtkEFHoa4aeBI9JmSy1eDrwmo75VJZBNQKGnEb4FeGHabKnFqcDzM+pbVQLZBBR6GuFLgL9Omy21+CxweEZ9q0ogm4BCTyP8LeDjabOlFtcA+2XUt6oEsgko9DTCXwQuT5uttLgHcEOmD6tLYG0CCj2N7meAW9JmKy2OBD6R6cPqElibgELvh+5bwP79TBdavQ54WUZ9q0ogi4BC74cv9xXbF4DH9GtKKwmUJ6DQ+zF9BfDn/UyXWsUjwP9k+rC6BNYioND7YfsV4Px+pkut4qv/VZk+rC6BtQgo9H7Y7gTc3M90qdVLM9/HZzZv9ZYJKPT+2b+1v+lCy9jBFjvZLBLYOAGF3h/55zMn1H4M/DyQ+wejf4+1lEBHQKH3HwrvB2LLaU7ZG7g2x4F1JbAOAYXen9rvAe/ub77Q8sFA7G+3SGCjBBR6f9x3A27sb77QsuYJuUcCsXc+NuAcCMS3jzHKj4ArgFhbcA5wLvDTMRrS5/8TUOjDRkPu83UNE3KP6AR9KPAQ4H7DEIxiHUuMTwG+0f0RiH+vdj6jHGuFPozl14AHDatyO+ttTcjtAzwbeB4Qjw9TKNcBn+welz41hQ7X3EeFPiw7U5qQuwtwFPDc7oScOw4LtSrrz3WHd1xWVa8m1BmFPixZU5iQOww4HngWEPMKcyk/Ad4E/DFw01yC2lQcCn0Y6RITcmPMvO8FHAucABw0LKRJWkesZ0yy51vqtEIfDj53Qq7UOe8HADGh1upR0hcCvwP8x/AUtldDoQ/PeQysnFdP65zzvkvUj+7EHQK/+/Cuz7JG7Co8eZaRFQxKoQ+HuYlz3uM5+ynAY4HHKepkkuJdfMyfXJ+0bNRAoQ9PfO4hFMvOeW/tOXs4+dU1/r3bNBSv5Sy7EVDow4dE6XPeHwrEkdLPAX5ueHessYNATNDFRJ1FoWePgVLnvMfRUq8EfjO7RzrYSeAk4I0iuT0BP9GHj4jcc96Ht2iNoQTGeIU5tA9V2Sv04ekocc778FatMZSAYt9BTKEPHT5Q4pz34a1aYyiBeA36q24Lvg2bQh86fG6zz100s16r1hpKIMQe225jM1LTRaGvl/44tnnu7GIjSWwd/XCh/eKx2CcmMuNTdt/1sK9V6+LuCLCm97zPfbCuNTJ6VIpTYuawpjx2g/1NtxX0ez3iLmUSd9HF4RYP7P59UeZqw1S/4lz+V6eM5vx7hb5edqcs9B8A7+sEHqe81FL2AN7Q7bwbo09xes5ZYziegk+Fvl6Wpij0uKf9ncAHK9/m+Xjgn9ZLS7JWPDJ8J2k1QwOFvl5SpyL07wPvAt7aHdO0XrSbrxWHZMQqt9hTX7JcAMStO80Vhb5eymuddY/bZGLTzTXAB7pP7ziwYarlL4E/Ktz53wbOLuyzencKfXiK4vy1ENK2S4j6S0DMKn8RuAi4tMDVUduOa/f247k6jsQqWeKKraZm4RX68OETRza/fni1YjVeCMStMXMU9SJId+6OhX5SMYK3PcrETH8zRaEPT3VMaMVpqpsqU33OLsmntNjjcSbOsf9KyU7W7EuhD89OTOjEwRBjlyuBaCv+qEz5ObsUpxB7XP5Q6jTbOIoqDvZooij04Wkee8Y9bjH5M+C9rT1H9khFicM5dzbzVOBve7Q7eROFPjyF53Xrp4fXXFxj10z5Dd2rMAW+mmzcNBMLfWJCLbfEjTCxOm/2RaEPT3Gs/47DDXJLPOvHaTWtTKrl8tpZ/1UFD4SMq6z/u2TnavSl0Idn5TjgtOHVblcjnjNrfRefGdpGqseRW3G9VYkSbzHeVsJRzT4U+vDsxHNifOVb98jnJwDnD2/WGrsRuG+h5azxByOur5p1Uejrpfdpa66uOrW7Q2y9Vq21O4G4nikmLnPLkcAncp3UXF+hr5+d0weeOPrt7jji2D1mKUMgJuRiMjO3xEafZ+Y6qbm+Ql8/O8HuROA1QLzjXVXe09nGzLqlLIESb0G2dZ11WRIrvCn0fNRxgEJcbnhw97Mf8EPg8m7lVazVPie/GT0sIVBicjRcx5zLtXOlrNDnmtl24sqdHN1Fatanxir0dgQx50jXnRzdyUShz3mEGNtsCOSuS1DosxkKBjJnAjHRmXOVtEKf8+gwttkQyN1spNBnMxQMZM4E/Oru67U5j29j6wgodIWuGGZOoMTFl351n/kgMbzpE4gFSbFePafcD7g6x0HNdX2PXnN27FsfAiV2sd0ExMKbW/o0OEUbhT7FrNnnXQRij0GJQyP+HjhizlgV+pyzO+/YQuTnAr9WIMzZHz6h0AuMEl1snECc0BMi/40CLcds/b2A6wr4qtaFQq82NXZsBYGXdduDS0D6DPDkEo5q9qHQa86OfVtEYC/gKmDPQniauItNoRcaLbrZGIFXAn9SqLW4uy5ubJl9UeizT/GsAoxP83/L3LyyE8jTgY/NitCSYBR6C1meT4z/ADyxUDjNfJoHL4VeaNToZnQCcUPLvxRs5deBTxf0V7UrhV51euxcRyBOe/1ydyZfCShnDDzBt0SbW/Wh0LeK38Z7Eih1fns0dw0QG1jiAM9mikJvJtWTDbTEWvadwc96l9qyLCv0yY7/Jjpeai37LlhNitzJuCa0Mtkg4yLFuCapxFr2gPDygqvpJgfVT/TJpayZDsedavFsXqI09SptETCFXmIY6aM0gXiV9gUgZttLlGYWxviMXmK46GMTBOIAiBsLNhR/MB5T0N8kXfmJPsm0zbbTsf30Rz0urewLIE6MeXh3B17fOrO0U+izTOtkg3o/cEzB3r8VeFFBf5N1pdAnm7pZdTw+yd/QXS1dMrB4xv9pSYdT9aXQp5q5+fQ73pXHDrKnFA6pqbXsKXYKPUXI349JIET+ue45umQ7za1lT8FT6ClC/n4sAnF809+N4LzJtewpjgo9RcjflyYQK97eATy3tOPOX7PLXFfxVOgjjTbdLiTwQODDwMNG4nM0cNZIviftVqFPOn2T6vyzu0/yu47U61cArx7J9+TdKvTJp7D6APYAvgHcZ8Sefg+I7ay+SlsCWaGPOPp0zbOAvwL2HZnFQcDXR25j0u4V+qTTV23nHwW8HTh0Az38A+DNG2hn0k0o9Emnr7rOPwj42gZ75RLXnrAVek9Qmq0kcG/g48Avb5DTFcAhwI832OZkm1Lok03d1jt+GHAk8AwgPsk3WT4JHAdcu8lGp9yWQp9y9jbf97gp5VjgBCAmwLZR/qLgyTPb6P9W2lToW8E+qUYP6CbVztxyr38CxCTfZVvuxySbV+jjpe3A7pPv4O7igXiffHl3CMJHgLPHazrL8/2BZwJHAI8teM9ZTqdi/fqTgK/mOGm5rkIvn/1gemJ34mjszlpWTgdeXPjYpHWiuWd3n1n0pdSJq+v0Y1mduDYpHhe+W9Jpa74UevmMfwiINdd9ytXdJ+emP6niU/t3gViWGuvOax0HIfDYcmrJJFBrgjPD2lr1GJjxST1GibPUvgVcAnwWiJtFh6wG2xP4feA5wC+N0cGCPmM+IPr6XwV9Nu1KoZdL/z7dM2QIalvleuBi4MLujrHo0+HA47bVoYHtxumvxwPxrchSkIBCLwfzpcDry7lrzlPclnpU962lueDHDlihlyP8TuB55dw14ylem/0p8Fogjme2jEBAoZeDegEQq8Us/QnE5QrxLO678f7M1rJU6GthW1jpvO55uJzHeXuKFW4nA7fOO8w6olPo5fJwCnBSOXez9XRld0XS92cbYYWBKfRySYlNFqeVczdLT/E1XUZbSK1CLwc9LgeMI5P2Ludy8p5i6Wos9X0X8M+Tj2bCASj0ssl7WsVr2MtGutpb3Hf2mYELejbZv+baUujlU/4++L+z0loq8bwdn9px4kt8q7FURkChl09IbGQ5p9ttVd57HR5v7pbixlfzDwAfBOJ9uKVSAgp9nMTMUeyx1v4lwEXApUCI3TIRAgp9vESF2M+tdOtnn6jj0zr2zb8XiMVAlgkTUOjjJi/E/lEgrvCdSnnBGjvjphJbs/1U6OOnvu9BFOP3ZHkLsYglzmCP3W+WGRJQ6JtL6u5HS+23W9NxT3isrotLCHe/WmjXKTCx5TR+SlxS+PnuWKu4lDAmDy0zJqDQ55PcODUmjl5+PPAIYP8Bf0jmQ8FIFhJQ6A4MCTRAQKE3kGRDlIBCdwxIoAECCr2BJBuiBBS6Y0ACDRBQ6A0k2RAloNAdAxJogIBCbyDJhigBhe4YkEADBBR6A0k2RAkodMeABBogoNAbSLIhSkChOwYk0AABhd5Akg1RAgrdMSCBBggo9AaSbIgSUOiOAQk0QEChN5BkQ5SAQncMSKABAgq9gSQbogQUumNAAg0QUOgNJNkQJaDQHQMSaICAQm8gyYYoAYXuGJBAAwQUegNJNkQJKHTHgAQaIKDQG0iyIUpAoTsGJNAAAYXeQJINUQIK3TEggQYIKPQGkmyIElDojgEJNEBAoTeQZEOUgEJ3DEigAQIKvYEkG6IEFLpjQAINEFDoDSTZECWg0B0DEmiAgEJvIMmGKAGF7hiQQAMEFHoDSTZECSh0x4AEGiCg0BtIsiFK4H8B2KFPGcGg0XAAAAAASUVORK5CYII=";
   image4.src =('data:image/png;base64,'+this.imagesList[4].base64);  
   //console.log((this.imagesList));
  }
  
  }
  
  
  capture(index, canvas) {
    if(canvas === 'canvas1'){
      this.renderer.setProperty(this.canvas1.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas1.nativeElement, 'height', this.videoHeight);
      this.canvas1.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      this.saveImagesData(index, this.canvas1.nativeElement.toDataURL("image/png"));       
    }
    else if(canvas === 'canvas2'){
      this.renderer.setProperty(this.canvas2.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas2.nativeElement, 'height', this.videoHeight);
      this.canvas2.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      this.saveImagesData(index, this.canvas2.nativeElement.toDataURL("image/png"));
    }
    else if(canvas === 'canvas3'){
      this.renderer.setProperty(this.canvas3.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas3.nativeElement, 'height', this.videoHeight);
      this.canvas3.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      this.saveImagesData(index, this.canvas3.nativeElement.toDataURL("image/png"));
    }
    else if(canvas === 'canvas4'){
      this.renderer.setProperty(this.canvas4.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas4.nativeElement, 'height', this.videoHeight);
      this.canvas4.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      this.saveImagesData(index, this.canvas4.nativeElement.toDataURL("image/png"));
    }
    else{
      this.renderer.setProperty(this.canvas.nativeElement, 'width', this.videoWidth);
      this.renderer.setProperty(this.canvas.nativeElement, 'height', this.videoHeight);
      this.canvas.nativeElement.getContext('2d').drawImage(this.videoElement.nativeElement, 0, 0);
      this.saveImagesData(index, this.canvas.nativeElement.toDataURL("image/png"));
    }
  }
  handleError(error) {
    //  console.log('Error: ', error);
  }
  saveImagesData(item, base64: string){
    const Count = this.imagesList.length;
    if(Count > 0) {
      const index: number = this.imagesList.indexOf(item);
      this.imagesList[item].base64 = base64;
    }
  }
//select change
fetchProcessingOfficeMasterByTehsilID(event){
  var url = this.MarriageServicesAPI;
  //var url='http://localhost:50943/'
  var fetchProcessingOfficeMaster = this._appSettings.fetchProcessingOfficeMaster;
  url = url + fetchProcessingOfficeMaster + event;

  this._ConfigService.get(url)
    .subscribe(response => {
      this._notification.responseHandler(response);
      if(response["response"] == 1){
        this.processingOfficesList = response["data"];
      //  console.log(this.processingOfficesList);
      }
    });
}
bindDynamicCalendar(){
  const currentYear = new Date().getFullYear();
  const currentDate = new Date().getDate();
  const currentMonth = new Date().getMonth();

  this.minDate = new Date(currentYear - 100, 0, 1);
  this.maxDateOfSolemnizationOfmarriage=new Date(currentYear - 0, currentMonth, currentDate);
  this.maxDobofBride=new Date(currentYear - 18, currentMonth, currentDate);
  this.maxDobofGroom=new Date(currentYear - 21, currentMonth, currentDate);
  
  if(this.firstFormGroup.get("gender").value === 'Female'){
    this.maxDate = new Date(currentYear - 18, currentMonth, currentDate);
  }
  else{
    this.maxDate = new Date(currentYear - 21, currentMonth, currentDate);
    if (this.firstFormGroup.get("ApplicantAgeInYear").value <21){
      
      this.firstFormGroup.get("date_of_birth").setValue(null);
      this.firstFormGroup.get("ApplicantAgeInYear").setValue(null);
      this.firstFormGroup.get("ApplicantAgeInMonth").setValue(null);       
      this._notification.info("In case of bride Applicant must be 18 or greater than 18, In case of bridegroom Applicant must be 21 or greater than 21  !","info");
    }
  }
}

findAge(current_date, current_month, current_year, birth_date, birth_month, birth_year) {

  if (birth_date > current_date) {
    current_date = current_date + this.daysInMonth(current_month - 1, current_year);
    current_month = current_month - 1;
  }

  if (birth_month > current_month) {
    current_year = current_year - 1;
    current_month = current_month + 12;
  }
  
  var calculated_date = current_date - birth_date;
  var calculated_month = current_month - birth_month;
  var calculated_year = current_year - birth_year;

  let calAge={
    years:calculated_year,
    months:calculated_month,
    days:calculated_date
  }
 return (calAge)
}
daysInMonth(month, year) {
  if (month < 0)
    return 31;
  return new Date(year, month, 0).getDate();
}
calculateAge(event){
  //console.log(event);
  //console.log(this.firstFormGroup.get("date_of_birth").value);
  const m: Moment = event.value;
  //console.log('m'+m);
  if(m){
    var startDate = moment(event.value).format('yyyy-MM');
    var endDate = moment(new Date()).format('yyyy-MM'); 

    var years = moment(endDate).diff(startDate, "years");
    var months = moment(endDate).diff(startDate, "month");

    //
    let b_day = event.value.getDate();
    let b_month = event.value.getMonth() + 1;
    let b_year = event.value.getFullYear();

    let c_day = new Date().getDate();
    let c_month = new Date().getMonth() + 1;
    let c_year = new Date().getFullYear();

    let ageDetails=this.findAge(c_day, c_month, c_year, b_day, b_month, b_year);

  //  console.log(this.findAge(c_day, c_month, c_year, b_day, b_month, b_year)); 

    //ar diff = moment.preciseDiff(starts, ends, true);
    if(ageDetails.years < 18 && this.firstFormGroup.get("gender").value === 'Female'){
      alert('Applicant not eligible for marriageablility certificate!');
      this.firstFormGroup.get("ApplicantAgeInYear").setValue(null);   
      this.firstFormGroup.get("ApplicantAgeInMonth").setValue(null);      
     // this.firstFormGroup.get('age').setValidators([Validators.required]);
    }
    else if(ageDetails.years < 21 && this.firstFormGroup.get("gender").value === 'Male'){
      alert('Applicant not eligible for marriageablility certificate!');
      this.firstFormGroup.get("ApplicantAgeInYear").setValue(null);   
      this.firstFormGroup.get("ApplicantAgeInMonth").setValue(null);    
     // this.firstFormGroup.get('age').setValidators([Validators.required]);
    }
    else{
      //this.firstFormGroup.get("age").setValue(ageDetails.years);
      this.firstFormGroup.get("ApplicantAgeInYear").setValue(ageDetails.years);   
      this.firstFormGroup.get("ApplicantAgeInMonth").setValue(ageDetails.months);
    }
  //  this.firstFormGroup.get('age').updateValueAndValidity();
  }
}
calculateAgeBride(event){
  const m: Moment = event.value;
  if(m){
    var startDate = moment(event.value).format('yyyy-MM');
    var endDate = moment(new Date()).format('yyyy-MM'); 

    // var years = moment(endDate).diff(startDate, "years");
    // var months = moment(endDate).diff(startDate, "month");

    //
    let b_day = event.value.getDate();
    let b_month = event.value.getMonth() + 1;
    let b_year = event.value.getFullYear();

    let c_day = new Date().getDate();
    let c_month = new Date().getMonth() + 1;
    let c_year = new Date().getFullYear();

    let ageDetails=this.findAge(c_day, c_month, c_year, b_day, b_month, b_year);

   // console.log(this.findAge(c_day, c_month, c_year, b_day, b_month, b_year)); 

    this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInYear").setValue(ageDetails.years);
    this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInMonth").setValue(ageDetails.months);

    //ar diff = moment.preciseDiff(starts, ends, true);
    // if(ageDetails.years < 18 && this.firstFormGroup.get("gender").value === 'Female'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);        
    //  // this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else if(ageDetails.years < 21 && this.firstFormGroup.get("gender").value === 'Male'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);     
    //  // this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else{
    //   this.firstFormGroup.get("age").setValue(ageDetails.years);
    // }
  //  this.firstFormGroup.get('age').updateValueAndValidity();
  }
}
calculateAgeGroom(event){
  const m: Moment = event.value;
  if(m){
    var startDate = moment(event.value).format('yyyy-MM');
    var endDate = moment(new Date()).format('yyyy-MM'); 

    // var years = moment(endDate).diff(startDate, "years");
    // var months = moment(endDate).diff(startDate, "month");

    //
    let b_day = event.value.getDate();
    let b_month = event.value.getMonth() + 1;
    let b_year = event.value.getFullYear();

    let c_day = new Date().getDate();
    let c_month = new Date().getMonth() + 1;
    let c_year = new Date().getFullYear();

    let ageDetails=this.findAge(c_day, c_month, c_year, b_day, b_month, b_year);

   // console.log(this.findAge(c_day, c_month, c_year, b_day, b_month, b_year)); 

    this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInYear").setValue(ageDetails.years);
    this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInMonth").setValue(ageDetails.months);

    //ar diff = moment.preciseDiff(starts, ends, true);
    // if(ageDetails.years < 18 && this.firstFormGroup.get("gender").value === 'Female'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);        
    //  // this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else if(ageDetails.years < 21 && this.firstFormGroup.get("gender").value === 'Male'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);     
    //  // this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else{
    //   this.firstFormGroup.get("age").setValue(ageDetails.years);
    // }
  //  this.firstFormGroup.get('age').updateValueAndValidity();
  }
}
calculateMarriageMonth(event){
  const m: Moment = event.value;
  if(m){
    
    // var startDate = moment(event.value).format('yyyy-MM');
    // var endDate = moment(new Date()).format('yyyy-MM'); 
    this.firstDate = moment(event.value) ;
    this.secondDate = moment(new Date());
    // var years = moment(endDate).diff(startDate, "years");
    // var months = moment(endDate).diff(startDate, "month");
    // var days = moment(endDate).diff(startDate, "days");
    // this.diffInDays = Math.abs(this.firstDate.diff(this.secondDate, 'days')); 
    // if(this.diffInDays>365){
    //   this.serviceID=188
    //   this.thirdFormGroup.get("PresentationMemorandumMarriage").setValue("After Year");
      
    // }
    // else if(this.diffInDays<=365 && this.diffInDays>180 ){
    //   this.serviceID=187
    //   this.thirdFormGroup.get("PresentationMemorandumMarriage").setValue("Within Year");
    // }
    // else if(this.diffInDays<=180 && this.diffInDays>90 ){
    //   this.serviceID=193
    //   this.thirdFormGroup.get("PresentationMemorandumMarriage").setValue("Within 6 Months");
    // }
    // else if(this.diffInDays<=90 && this.diffInDays>=0 ){
    //   this.serviceID=193
    //   this.thirdFormGroup.get("PresentationMemorandumMarriage").setValue("Within 3 Months");
    // }
    this.serviceID=105
    
    //alert(this.diffInDays);

    // if(years < 18 && this.firstFormGroup.get("gender").value === 'Female'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);        
    //   this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else if(years < 21 && this.firstFormGroup.get("gender").value === 'Male'){
    //   alert('Applicant not eligible for marriageablility certificate!');
    //   this.firstFormGroup.get("age").setValue(null);     
    //   this.firstFormGroup.get('age').setValidators([Validators.required]);
    // }
    // else{
    //   this.firstFormGroup.get("age").setValue(years);
    // }
    // this.firstFormGroup.get('age').updateValueAndValidity();
  }
}
CheckIsBrideNRI(completed: boolean){
  if(completed){
    if(this.fourthFormGroup.get("IsBrideFromOtherState").value == false){
    this.BrideNotNRI=false;
    this.BrideNRIDetails=true;
    //case outside punjab in india
    this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValidators(null);
    this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValidators(null);
    //case in punjab
    this.fourthFormGroup.get('BrideRegion').setValidators(null);
    this.fourthFormGroup.get('BrideState').setValidators(null);
    this.fourthFormGroup.get('BrideDistrict').setValidators(null);
    this.fourthFormGroup.get('BrideTehsil').setValidators(null);
    this.fourthFormGroup.get('BrideVillage').setValidators(null);
    this.fourthFormGroup.get('BridePincode').setValidators(null);
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValidators(null);
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValidators(null);
    
     
    // case NRI
    this.fourthFormGroup.get('BridePassportNumber').setValidators([Validators.required,PassportNo]);
    this.fourthFormGroup.get('BridePassportIssuanceDate').setValidators([Validators.required]);
    this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValidators([Validators.required,AlphaValidator]);
    this.fourthFormGroup.get('BrideVisaType').setValidators([Validators.required]);
    this.fourthFormGroup.get('BrideVisaDurationInYear').setValidators([Validators.required]);
    this.fourthFormGroup.get('BrideVisaDurationInMonth').setValidators([Validators.required]);
    this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValidators([Validators.required]);
    this.fourthFormGroup.get('BrideSocialSecurityNumber').setValidators([Validators.required,SocialSecurityNumber]);
    this.fourthFormGroup.get('BrideNRIAddress').setValidators([Validators.required,EnglishAddress]);
    this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValidators([Validators.required,PunjabiAddress]);

    //case outside punjab in india
    this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValue(null); 
    this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValue(null); 
     
    // case Punjab
    this.fourthFormGroup.get('BrideRegion').setValue(null); 
    this.fourthFormGroup.get('BrideState').setValue(null); 
    this.fourthFormGroup.get('BrideDistrict').setValue(null); 
    this.fourthFormGroup.get('BrideTehsil').setValue(null); 
    this.fourthFormGroup.get('BrideVillage').setValue(null); 
    this.fourthFormGroup.get('BridePincode').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValue(null); 
  }
  else{
    this.fourthFormGroup.get("IsBrideNRI").setValue(false);
    this._notification.error('msg','Can not select Both Nri and other state');
    // this.BrideNotNRI=true;
    // this.BrideNRIDetails=false;

  }
}
  else{
    this.BrideNotNRI=true;
    this.BrideNRIDetails=false;
    //case outside punjab in india
    this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValue(null); 
    this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValue(null); 
     
    // case Punjab
    this.fourthFormGroup.get('BrideRegion').setValue(null); 
    this.fourthFormGroup.get('BrideState').setValue(null); 
    this.fourthFormGroup.get('BrideDistrict').setValue(null); 
    this.fourthFormGroup.get('BrideTehsil').setValue(null); 
    this.fourthFormGroup.get('BrideVillage').setValue(null); 
    this.fourthFormGroup.get('BridePincode').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValue(null); 

     // case NRI
     this.fourthFormGroup.get('BridePassportNumber').setValue(null); 
     this.fourthFormGroup.get('BridePassportIssuanceDate').setValue(null); 
     this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValue(null); 
     this.fourthFormGroup.get('BrideVisaType').setValue(null); 
     this.fourthFormGroup.get('BrideVisaDurationInYear').setValue(null); 
     this.fourthFormGroup.get('BrideVisaDurationInMonth').setValue(null); 
     this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValue(null); 
     this.fourthFormGroup.get('BrideSocialSecurityNumber').setValue(null); 
     this.fourthFormGroup.get('BrideNRIAddress').setValue(null); 
     this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValue(null); 
  }

  //case outside punjab in india
  this.fourthFormGroup.get('BrideAddressOutOfStateDetails').updateValueAndValidity();
  this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
  //case in punjab
  this.fourthFormGroup.get('BrideRegion').updateValueAndValidity();
  this.fourthFormGroup.get('BrideState').updateValueAndValidity();
  this.fourthFormGroup.get('BrideDistrict').updateValueAndValidity();
  this.fourthFormGroup.get('BrideTehsil').updateValueAndValidity();
  this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
  this.fourthFormGroup.get('BridePincode').updateValueAndValidity();
  this.fourthFormGroup.get('BrideStreetAddressLandmark').updateValueAndValidity();
  this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').updateValueAndValidity();
  
   
  // case NRI
  this.fourthFormGroup.get('BridePassportNumber').updateValueAndValidity();
  this.fourthFormGroup.get('BridePassportIssuanceDate').updateValueAndValidity();
  this.fourthFormGroup.get('BrideVisaGrantedByCountry').updateValueAndValidity();
  this.fourthFormGroup.get('BrideVisaType').updateValueAndValidity();
  this.fourthFormGroup.get('BrideVisaDurationInYear').updateValueAndValidity();
  this.fourthFormGroup.get('BrideVisaDurationInMonth').updateValueAndValidity();
  this.fourthFormGroup.get('BrideDateOfVisitInIndia').updateValueAndValidity();
  this.fourthFormGroup.get('BrideSocialSecurityNumber').updateValueAndValidity();
  this.fourthFormGroup.get('BrideNRIAddress').updateValueAndValidity();
  this.fourthFormGroup.get('BrideNRIAddressPunjabi').updateValueAndValidity();

 
 
} 
CheckIsBrideFromOtherState(completed: boolean){
  if(completed){
    if(this.fourthFormGroup.get("IsBrideNRI").value == false){
    this.IsBrideAddressOutOfState=true;
    this.BrideNotNRI=false;
    this.BrideNRIDetails=false;
    
    //case outside punjab in india
    this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValidators([Validators.required,EnglishAddress]);
    this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValidators([Validators.required,PunjabiAddress]);
    //case in punjab
    this.fourthFormGroup.get('BrideRegion').setValidators(null);
    this.fourthFormGroup.get('BrideState').setValidators(null);
    this.fourthFormGroup.get('BrideDistrict').setValidators(null);
    this.fourthFormGroup.get('BrideTehsil').setValidators(null);
    this.fourthFormGroup.get('BrideVillage').setValidators(null);
    this.fourthFormGroup.get('BridePincode').setValidators(null);
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValidators(null);
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValidators(null);
    
     
    // case NRI
    this.fourthFormGroup.get('BridePassportNumber').setValidators(null);
    this.fourthFormGroup.get('BridePassportIssuanceDate').setValidators(null);
    this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValidators(null);
    this.fourthFormGroup.get('BrideVisaType').setValidators(null);
    this.fourthFormGroup.get('BrideVisaDurationInYear').setValidators(null);
    this.fourthFormGroup.get('BrideVisaDurationInMonth').setValidators(null);
    this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValidators(null);
    this.fourthFormGroup.get('BrideSocialSecurityNumber').setValidators(null);
    this.fourthFormGroup.get('BrideNRIAddress').setValidators(null);
    this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValidators(null);

    //
    // case Punjab
    this.fourthFormGroup.get('BrideRegion').setValue(null); 
    this.fourthFormGroup.get('BrideState').setValue(null); 
    this.fourthFormGroup.get('BrideDistrict').setValue(null); 
    this.fourthFormGroup.get('BrideTehsil').setValue(null); 
    this.fourthFormGroup.get('BrideVillage').setValue(null); 
    this.fourthFormGroup.get('BridePincode').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValue(null); 
    
    
     
    // case NRI
    this.fourthFormGroup.get('BrideRegion').setValue(null); 
    this.fourthFormGroup.get('BrideState').setValue(null); 
    this.fourthFormGroup.get('BrideDistrict').setValue(null); 
    this.fourthFormGroup.get('BrideTehsil').setValue(null); 
    this.fourthFormGroup.get('BrideVillage').setValue(null); 
    this.fourthFormGroup.get('BridePincode').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValue(null); 
   
  
  }
  else{
    // this.IsBrideAddressOutOfState=false;
    // this.BrideNotNRI=true;
    // this.BrideNRIDetails=false;
    this.fourthFormGroup.get("IsBrideFromOtherState").setValue(false);
    this._notification.error('msg','Can not select Both Nri and other state');

  }
}
  else{
    this.IsBrideAddressOutOfState=false;
    this.BrideNotNRI=true;
    this.BrideNRIDetails=false;

        //case outside punjab in india
        this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValidators(null);
        this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValidators(null);
        //case outside punjab in india
        this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValue(null); 
        this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValue(null); 
       //case outside punjab in india
    this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValue(null); 
    this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValue(null); 
     
    // case Punjab
    this.fourthFormGroup.get('BrideRegion').setValue(null); 
    this.fourthFormGroup.get('BrideState').setValue(null); 
    this.fourthFormGroup.get('BrideDistrict').setValue(null); 
    this.fourthFormGroup.get('BrideTehsil').setValue(null); 
    this.fourthFormGroup.get('BrideVillage').setValue(null); 
    this.fourthFormGroup.get('BridePincode').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmark').setValue(null); 
    this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValue(null); 
        
         
        // case NRI
     this.fourthFormGroup.get('BridePassportNumber').setValue(null); 
     this.fourthFormGroup.get('BridePassportIssuanceDate').setValue(null); 
     this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValue(null); 
     this.fourthFormGroup.get('BrideVisaType').setValue(null); 
     this.fourthFormGroup.get('BrideVisaDurationInYear').setValue(null); 
     this.fourthFormGroup.get('BrideVisaDurationInMonth').setValue(null); 
     this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValue(null); 
     this.fourthFormGroup.get('BrideSocialSecurityNumber').setValue(null); 
     this.fourthFormGroup.get('BrideNRIAddress').setValue(null); 
     this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValue(null); 
  }
   //case outside punjab in india
   this.fourthFormGroup.get('BrideAddressOutOfStateDetails').updateValueAndValidity();
   this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
   //case in punjab
   this.fourthFormGroup.get('BrideRegion').updateValueAndValidity();
   this.fourthFormGroup.get('BrideState').updateValueAndValidity();
   this.fourthFormGroup.get('BrideDistrict').updateValueAndValidity();
   this.fourthFormGroup.get('BrideTehsil').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
   this.fourthFormGroup.get('BridePincode').updateValueAndValidity();
   this.fourthFormGroup.get('BrideStreetAddressLandmark').updateValueAndValidity();
   this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').updateValueAndValidity();
   
    
   // case NRI
   this.fourthFormGroup.get('BridePassportNumber').updateValueAndValidity();
   this.fourthFormGroup.get('BridePassportIssuanceDate').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaGrantedByCountry').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaType').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaDurationInYear').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaDurationInMonth').updateValueAndValidity();
   this.fourthFormGroup.get('BrideDateOfVisitInIndia').updateValueAndValidity();
   this.fourthFormGroup.get('BrideSocialSecurityNumber').updateValueAndValidity();
   this.fourthFormGroup.get('BrideNRIAddress').updateValueAndValidity();
   this.fourthFormGroup.get('BrideNRIAddressPunjabi').updateValueAndValidity();
 
} 
CheckIsGroomNRI(completed: boolean){
  if(completed){
    if(this.fifthFormGroup.get("IsGroomFromOtherState").value == false){
    this.GroomNotNRI=false;
    this.GroomNRIDetails=true;
    //case outside punjab in india
    this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValidators(null);
    this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValidators(null);
    //case in punjab
    this.fifthFormGroup.get('GroomRegion').setValidators(null);
    this.fifthFormGroup.get('GroomState').setValidators(null);
    this.fifthFormGroup.get('GroomDistrict').setValidators(null);
    this.fifthFormGroup.get('GroomTehsil').setValidators(null);
    this.fifthFormGroup.get('GroomVillage').setValidators(null);
    this.fifthFormGroup.get('GroomPincode').setValidators(null);
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValidators(null);
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValidators(null);
    
     
    // case NRI
    this.fifthFormGroup.get('GroomPassportNumber').setValidators([Validators.required,PassportNo]);
    this.fifthFormGroup.get('GroomPassportIssuanceDate').setValidators([Validators.required]);
    this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValidators([Validators.required,AlphaValidator]);
    this.fifthFormGroup.get('GroomVisaType').setValidators([Validators.required]);
    this.fifthFormGroup.get('GroomVisaDurationInYear').setValidators([Validators.required]);
    this.fifthFormGroup.get('GroomVisaDurationInMonth').setValidators([Validators.required]);
    this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValidators([Validators.required]);
    this.fifthFormGroup.get('GroomSocialSecurityNumber').setValidators([Validators.required,SocialSecurityNumber]);
    this.fifthFormGroup.get('GroomNRIAddress').setValidators([Validators.required,EnglishAddress]);
    this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValidators([Validators.required,PunjabiAddress]);

    //case outside punjab in india
    this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValue(null); 
    this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValue(null); 
     
    // case Punjab
    this.fifthFormGroup.get('GroomRegion').setValue(null); 
    this.fifthFormGroup.get('GroomState').setValue(null); 
    this.fifthFormGroup.get('GroomDistrict').setValue(null); 
    this.fifthFormGroup.get('GroomTehsil').setValue(null); 
    this.fifthFormGroup.get('GroomVillage').setValue(null); 
    this.fifthFormGroup.get('GroomPincode').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValue(null); 
  }
  else{
    this.fifthFormGroup.get("IsGroomNRI").setValue(false);
    this._notification.error('msg','Can not select Both Nri and other state');
    // this.GroomNotNRI=true;
    // this.GroomNRIDetails=false;

  }
}
  else{
    this.GroomNotNRI=true;
    this.GroomNRIDetails=false;

    this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValue(null); 
    this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValue(null); 
    //case in punjab
    // case Punjab
    this.fifthFormGroup.get('GroomRegion').setValue(null); 
    this.fifthFormGroup.get('GroomState').setValue(null); 
    this.fifthFormGroup.get('GroomDistrict').setValue(null); 
    this.fifthFormGroup.get('GroomTehsil').setValue(null); 
    this.fifthFormGroup.get('GroomVillage').setValue(null); 
    this.fifthFormGroup.get('GroomPincode').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValue(null); 

     // case NRI
     this.fifthFormGroup.get('GroomPassportNumber').setValue(null); 
     this.fifthFormGroup.get('GroomPassportIssuanceDate').setValue(null); 
     this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValue(null); 
     this.fifthFormGroup.get('GroomVisaType').setValue(null); 
     this.fifthFormGroup.get('GroomVisaDurationInYear').setValue(null); 
     this.fifthFormGroup.get('GroomVisaDurationInMonth').setValue(null); 
     this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValue(null); 
     this.fifthFormGroup.get('GroomSocialSecurityNumber').setValue(null); 
     this.fifthFormGroup.get('GroomNRIAddress').setValue(null); 
     this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValue(null); 
  }

  //case outside punjab in india
  this.fifthFormGroup.get('GroomAddressOutOfStateDetails').updateValueAndValidity();
  this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
  //case in punjab
  this.fifthFormGroup.get('GroomRegion').updateValueAndValidity();
  this.fifthFormGroup.get('GroomState').updateValueAndValidity();
  this.fifthFormGroup.get('GroomDistrict').updateValueAndValidity();
  this.fifthFormGroup.get('GroomTehsil').updateValueAndValidity();
  this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
  this.fifthFormGroup.get('GroomPincode').updateValueAndValidity();
  this.fifthFormGroup.get('GroomStreetAddressLandmark').updateValueAndValidity();
  this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').updateValueAndValidity();
  
   
  // case NRI
  this.fifthFormGroup.get('GroomPassportNumber').updateValueAndValidity();
  this.fifthFormGroup.get('GroomPassportIssuanceDate').updateValueAndValidity();
  this.fifthFormGroup.get('GroomVisaGrantedByCountry').updateValueAndValidity();
  this.fifthFormGroup.get('GroomVisaType').updateValueAndValidity();
  this.fifthFormGroup.get('GroomVisaDurationInYear').updateValueAndValidity();
  this.fifthFormGroup.get('GroomVisaDurationInMonth').updateValueAndValidity();
  this.fifthFormGroup.get('GroomDateOfVisitInIndia').updateValueAndValidity();
  this.fifthFormGroup.get('GroomSocialSecurityNumber').updateValueAndValidity();
  this.fifthFormGroup.get('GroomNRIAddress').updateValueAndValidity();
  this.fifthFormGroup.get('GroomNRIAddressPunjabi').updateValueAndValidity();

 
 
} 
CheckIsGroomFromOtherState(completed: boolean){
  if(completed){
    if(this.fifthFormGroup.get("IsGroomNRI").value == false){
    this.IsGroomAddressOutOfState=true;
    this.GroomNotNRI=false;
    this.GroomNRIDetails=false;
    
    //case outside punjab in india
    this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValidators([Validators.required,EnglishAddress]);
    this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValidators([Validators.required,PunjabiAddress]);
    //case in punjab
    this.fifthFormGroup.get('GroomRegion').setValidators(null);
    this.fifthFormGroup.get('GroomState').setValidators(null);
    this.fifthFormGroup.get('GroomDistrict').setValidators(null);
    this.fifthFormGroup.get('GroomTehsil').setValidators(null);
    this.fifthFormGroup.get('GroomVillage').setValidators(null);
    this.fifthFormGroup.get('GroomPincode').setValidators(null);
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValidators(null);
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValidators(null);
    
     
    // case NRI
    this.fifthFormGroup.get('GroomPassportNumber').setValidators(null);
    this.fifthFormGroup.get('GroomPassportIssuanceDate').setValidators(null);
    this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValidators(null);
    this.fifthFormGroup.get('GroomVisaType').setValidators(null);
    this.fifthFormGroup.get('GroomVisaDurationInYear').setValidators(null);
    this.fifthFormGroup.get('GroomVisaDurationInMonth').setValidators(null);
    this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValidators(null);
    this.fifthFormGroup.get('GroomSocialSecurityNumber').setValidators(null);
    this.fifthFormGroup.get('GroomNRIAddress').setValidators(null);
    this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValidators(null);

    //
    // case Punjab
    this.fifthFormGroup.get('GroomRegion').setValue(null); 
    this.fifthFormGroup.get('GroomState').setValue(null); 
    this.fifthFormGroup.get('GroomDistrict').setValue(null); 
    this.fifthFormGroup.get('GroomTehsil').setValue(null); 
    this.fifthFormGroup.get('GroomVillage').setValue(null); 
    this.fifthFormGroup.get('GroomPincode').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValue(null); 
    
    
     
    // case NRI
    this.fifthFormGroup.get('GroomRegion').setValue(null); 
    this.fifthFormGroup.get('GroomState').setValue(null); 
    this.fifthFormGroup.get('GroomDistrict').setValue(null); 
    this.fifthFormGroup.get('GroomTehsil').setValue(null); 
    this.fifthFormGroup.get('GroomVillage').setValue(null); 
    this.fifthFormGroup.get('GroomPincode').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValue(null); 
   
  
  }
  else{
    // this.IsGroomAddressOutOfState=false;
    // this.GroomNotNRI=true;
    // this.GroomNRIDetails=false;
    this.fifthFormGroup.get("IsGroomFromOtherState").setValue(false);
    this._notification.error('msg','Can not select Both Nri and other state');

  }
}
  else{
    this.IsGroomAddressOutOfState=false;
    this.GroomNotNRI=true;
    this.GroomNRIDetails=false;

        //case outside punjab in india
        this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValidators(null);
        this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValidators(null);
        //case outside punjab in india
        this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValue(null); 
        this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValue(null); 
        //case in punjab 
        //set value
         //case outside punjab in india
    this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValue(null); 
    this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValue(null); 
     
    // case Punjab
    this.fifthFormGroup.get('GroomRegion').setValue(null); 
    this.fifthFormGroup.get('GroomState').setValue(null); 
    this.fifthFormGroup.get('GroomDistrict').setValue(null); 
    this.fifthFormGroup.get('GroomTehsil').setValue(null); 
    this.fifthFormGroup.get('GroomVillage').setValue(null); 
    this.fifthFormGroup.get('GroomPincode').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmark').setValue(null); 
    this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValue(null); 

     // case NRI
     this.fifthFormGroup.get('GroomPassportNumber').setValue(null); 
     this.fifthFormGroup.get('GroomPassportIssuanceDate').setValue(null); 
     this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValue(null); 
     this.fifthFormGroup.get('GroomVisaType').setValue(null); 
     this.fifthFormGroup.get('GroomVisaDurationInYear').setValue(null); 
     this.fifthFormGroup.get('GroomVisaDurationInMonth').setValue(null); 
     this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValue(null); 
     this.fifthFormGroup.get('GroomSocialSecurityNumber').setValue(null); 
     this.fifthFormGroup.get('GroomNRIAddress').setValue(null); 
     this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValue(null); 
  }
   //case outside punjab in india
   this.fifthFormGroup.get('GroomAddressOutOfStateDetails').updateValueAndValidity();
   this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
   //case in punjab
   this.fifthFormGroup.get('GroomRegion').updateValueAndValidity();
   this.fifthFormGroup.get('GroomState').updateValueAndValidity();
   this.fifthFormGroup.get('GroomDistrict').updateValueAndValidity();
   this.fifthFormGroup.get('GroomTehsil').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
   this.fifthFormGroup.get('GroomPincode').updateValueAndValidity();
   this.fifthFormGroup.get('GroomStreetAddressLandmark').updateValueAndValidity();
   this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').updateValueAndValidity();
   
    
   // case NRI
   this.fifthFormGroup.get('GroomPassportNumber').updateValueAndValidity();
   this.fifthFormGroup.get('GroomPassportIssuanceDate').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaGrantedByCountry').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaType').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaDurationInYear').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaDurationInMonth').updateValueAndValidity();
   this.fifthFormGroup.get('GroomDateOfVisitInIndia').updateValueAndValidity();
   this.fifthFormGroup.get('GroomSocialSecurityNumber').updateValueAndValidity();
   this.fifthFormGroup.get('GroomNRIAddress').updateValueAndValidity();
   this.fifthFormGroup.get('GroomNRIAddressPunjabi').updateValueAndValidity();
 
} 
CheckCurrentAddressOutOfState(completed: boolean){
  if(completed){
    if(this.IsPermanentAddressOutOfState==false){
    this.IsCurrentAddressNotOutofPunjab = false;
    this.IsCurrentAddressOutOfState=true;
    this.ShowCurrentAddressIsSameAsParentAddress=false;
    this.secondFormGroup.get('CurrentAddressLine1').setValidators(null);
    this.secondFormGroup.get('CurrentAddressLine2').setValidators(null);
    this.secondFormGroup.get('CurrentAddressLine3').setValidators(null);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetails').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').setValidators([Validators.required, PunjabiAddress]);      
    this.secondFormGroup.get('CurrentRegion').setValidators(null);
    this.secondFormGroup.get('CurrentstateID').setValidators(null);
    this.secondFormGroup.get('CurrentdistrictID').setValidators(null);
    this.secondFormGroup.get('CurrenttehsilID').setValidators(null);
    this.secondFormGroup.get('CurrentVillageID').setValidators(null);
    this.secondFormGroup.get('Currentpincode').setValidators(null);

    //set value     
     this.secondFormGroup.get('CurrentAddressLine1').setValue(null);
     this.secondFormGroup.get('CurrentAddressLine2').setValue(null);
     this.secondFormGroup.get('CurrentAddressLine3').setValue(null);
      this.secondFormGroup.get('CurrentRegion').setValue(null);
     this.secondFormGroup.get('CurrentstateID').setValue(null);
     this.secondFormGroup.get('CurrentdistrictID').setValue(null);
     this.secondFormGroup.get('CurrenttehsilID').setValue(null);
     this.secondFormGroup.get('CurrentVillageID').setValue(null);
     this.secondFormGroup.get('Currentpincode').setValue(null);  
     this.secondFormGroup.get('isCurrentPermanentaddressSame').setValue(false); 
     
     this.ShowCurrentAddressIsSameAsParentAddress=false;
    // this.secondFormGroup.get("CurrentAddressIsOutOfState").setValue(false);
     
    }
    else
    {
      this.IsCurrentAddressNotOutofPunjab = true;
      this.IsCurrentAddressOutOfState=false;
      this.ShowCurrentAddressIsSameAsParentAddress=true;
      this.secondFormGroup.get("CurrentAddressIsOutOfState").setValue(false);
      this._notification.error('msg','current and present both can not outside punjab');
    }
  }
  else{
    this.IsCurrentAddressNotOutofPunjab = true;
    this.IsCurrentAddressOutOfState=false;
    this.ShowCurrentAddressIsSameAsParentAddress=true;
    

    this.secondFormGroup.get('CurrentAddressLine1').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressLine2').setValidators([EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressLine3').setValidators([EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetails').setValidators(null);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').setValidators(null);      
    this.secondFormGroup.get('CurrentRegion').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentstateID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentdistrictID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrenttehsilID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
    this.secondFormGroup.get('Currentpincode').setValidators([Validators.required,Validators.minLength(6)]);

    //set value
    this.secondFormGroup.get('CurrentAddressOutOfStateDetails').setValue(null);
     this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').setValue(null);
   
  }

  this.secondFormGroup.get('CurrentAddressLine1').updateValueAndValidity();
  this.secondFormGroup.get('CurrentAddressLine2').updateValueAndValidity();
  this.secondFormGroup.get('CurrentAddressLine3').updateValueAndValidity();
  this.secondFormGroup.get('CurrentAddressOutOfStateDetails').updateValueAndValidity();
  this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').updateValueAndValidity();     
  this.secondFormGroup.get('CurrentRegion').updateValueAndValidity();
  this.secondFormGroup.get('CurrentstateID').updateValueAndValidity();
  this.secondFormGroup.get('CurrentdistrictID').updateValueAndValidity();
  this.secondFormGroup.get('CurrenttehsilID').updateValueAndValidity();
  this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
  this.secondFormGroup.get('Currentpincode').updateValueAndValidity();
}  
CheckPermanentAddressOutOfState(completed: boolean){
 
  if(completed){
    if(this.IsCurrentAddressOutOfState==false){
    this.IsPermanentAddressInPunjab = false;
    this.IsPermanentAddressOutOfState=true;
    this.showCurrentaddressCheckbox=false;    
    //this.secondFormGroup.get("isCurrentPermanentaddressSame").setValue(false);
    //set value null
    this.secondFormGroup.get('address_line_1').setValue(null);
    this.secondFormGroup.get('address_line_2').setValue(null);
    this.secondFormGroup.get('address_line_3').setValue(null);
    this.secondFormGroup.get('region').setValue(null);
    this.secondFormGroup.get('stateID').setValue(null);
    this.secondFormGroup.get('districtID').setValue(null);
    this.secondFormGroup.get('tehsilID').setValue(null);
    this.secondFormGroup.get('villageID').setValue(null);
    this.secondFormGroup.get('pincode').setValue(null);
    this.ShowCurrentAddressIsSameAsParentAddress=false;  
    
    this.secondFormGroup.get("isCurrentPermanentaddressSame").setValue(false);

    this.secondFormGroup.get('address_line_1').setValidators(null);
    this.secondFormGroup.get('address_line_2').setValidators(null);
    this.secondFormGroup.get('address_line_3').setValidators(null);
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').setValidators([Validators.required, PunjabiAddress]);      
    this.secondFormGroup.get('region').setValidators(null);
    this.secondFormGroup.get('stateID').setValidators(null);
    this.secondFormGroup.get('districtID').setValidators(null);
    this.secondFormGroup.get('tehsilID').setValidators(null);
    this.secondFormGroup.get('villageID').setValidators(null);
    this.secondFormGroup.get('pincode').setValidators(null);      

   // this.secondFormGroup.get("CurrentAddressIsOutOfState").setValue(false);

    }    
    else
    {
        this.IsPermanentAddressInPunjab = true;
        this.IsPermanentAddressOutOfState=false;   
        this.secondFormGroup.get("isCurrentPermanentaddressSame").setValue(false);     
        this.secondFormGroup.get("AddressIsOutOfState").setValue(false);
        this.ShowCurrentAddressIsSameAsParentAddress=false;
        //
        this.secondFormGroup.get('address_line_1').setValidators([Validators.required,EnglishAddress]);
        this.secondFormGroup.get('address_line_2').setValidators([EnglishAddress]);
        this.secondFormGroup.get('address_line_3').setValidators([EnglishAddress]);
        this.secondFormGroup.get('PermanentAddressOutOfStateDetails').setValidators(null); 
        this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').setValidators(null);       
        this.secondFormGroup.get('region').setValidators([Validators.required]);
        this.secondFormGroup.get('stateID').setValidators([Validators.required]);
        this.secondFormGroup.get('districtID').setValidators([Validators.required]);
        this.secondFormGroup.get('tehsilID').setValidators([Validators.required]);
        this.secondFormGroup.get('villageID').setValidators([Validators.required]);
        this.secondFormGroup.get('pincode').setValidators([Validators.required,Validators.minLength(6)]); 
       
       // this.showCurrentaddressCheckbox=false;
        this._notification.error('msg','current and present both cannot outside punjab');
    }
      this.secondFormGroup.get('address_line_1').updateValueAndValidity();
      this.secondFormGroup.get('address_line_2').updateValueAndValidity();
      this.secondFormGroup.get('address_line_3').updateValueAndValidity();
      this.secondFormGroup.get('PermanentAddressOutOfStateDetails').updateValueAndValidity();
      this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').updateValueAndValidity();       
      this.secondFormGroup.get('region').updateValueAndValidity();
      this.secondFormGroup.get('stateID').updateValueAndValidity();
      this.secondFormGroup.get('districtID').updateValueAndValidity();
      this.secondFormGroup.get('tehsilID').updateValueAndValidity();
      this.secondFormGroup.get('villageID').updateValueAndValidity();
      this.secondFormGroup.get('pincode').updateValueAndValidity();
    //
  }
  else{
    this.IsPermanentAddressInPunjab = true;
    this.IsPermanentAddressOutOfState=false;
    this.showCurrentaddressCheckbox=true;
    this.ShowCurrentAddressIsSameAsParentAddress=true;

    this.secondFormGroup.get('address_line_1').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('address_line_2').setValidators([EnglishAddress]);
    this.secondFormGroup.get('address_line_3').setValidators([EnglishAddress]);
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').setValidators(null); 
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').setValidators(null);       
    this.secondFormGroup.get('region').setValidators([Validators.required]);
    this.secondFormGroup.get('stateID').setValidators([Validators.required]);
    this.secondFormGroup.get('districtID').setValidators([Validators.required]);
    this.secondFormGroup.get('tehsilID').setValidators([Validators.required]);
    this.secondFormGroup.get('villageID').setValidators([Validators.required]);
    this.secondFormGroup.get('pincode').setValidators([Validators.required]);     

    //set value
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').setValue(null);  
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').setValue(null);

    this.secondFormGroup.get("isCurrentPermanentaddressSame").setValue(false);
    //set value null
    this.secondFormGroup.get('address_line_1').setValue(null);
    this.secondFormGroup.get('address_line_2').setValue(null);
    this.secondFormGroup.get('address_line_3').setValue(null);
     this.secondFormGroup.get('region').setValue(null);
    this.secondFormGroup.get('stateID').setValue(null);
    this.secondFormGroup.get('districtID').setValue(null);
    this.secondFormGroup.get('tehsilID').setValue(null);
    this.secondFormGroup.get('villageID').setValue(null);
    this.secondFormGroup.get('pincode').setValue(null);       
   
  }
    this.secondFormGroup.get('address_line_1').updateValueAndValidity();
    this.secondFormGroup.get('address_line_2').updateValueAndValidity();
    this.secondFormGroup.get('address_line_3').updateValueAndValidity();
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').updateValueAndValidity();
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').updateValueAndValidity();       
    this.secondFormGroup.get('region').updateValueAndValidity();
    this.secondFormGroup.get('stateID').updateValueAndValidity();
    this.secondFormGroup.get('districtID').updateValueAndValidity();
    this.secondFormGroup.get('tehsilID').updateValueAndValidity();
    this.secondFormGroup.get('villageID').updateValueAndValidity();
    this.secondFormGroup.get('pincode').updateValueAndValidity(); 
}
CheckCurrentAddressSameAsPermanentAddress(completed: boolean){
  if(completed){
    
    this.secondFormGroup.get("CurrentAddressLine1").setValue(this.secondFormGroup.get("address_line_1").value);
    this.secondFormGroup.get("CurrentAddressLine2").setValue(this.secondFormGroup.get("address_line_2").value);
    this.secondFormGroup.get("CurrentAddressLine3").setValue(this.secondFormGroup.get("address_line_3").value);

    this.secondFormGroup.get("CurrentRegion").setValue(this.secondFormGroup.get("region").value);
      this.secondFormGroup.get("CurrentstateID").setValue(this.secondFormGroup.get("stateID").value);
      this.secondFormGroup.get("CurrentdistrictID").setValue(this.secondFormGroup.get("districtID").value);
      this.secondFormGroup.get("CurrentAddressOutOfStateDetails").setValue(this.secondFormGroup.get("PermanentAddressOutOfStateDetails").value);
      this.secondFormGroup.get("CurrentAddressOutOfStateDetailsPunjabi").setValue(this.secondFormGroup.get("PermanentAddressOutOfStateDetailsPunjabi").value);
      this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
      this.secondFormGroup.get("CurrenttehsilID").setValue(this.secondFormGroup.get("tehsilID").value);
      this.secondFormGroup.get("Currentpincode").setValue(this.secondFormGroup.get("pincode").value);
      if(this.secondFormGroup.get("region").value === 'Rural'){
        this.CurrentRegion= true;
        this.fetchcurrentVillages(this.secondFormGroup.get("CurrenttehsilID").value);
        this.secondFormGroup.get("CurrentVillageID").setValue(this.secondFormGroup.get("villageID").value);
        this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
        this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
      }
      else{
        this.CurrentRegion= false;
        //this.fetchcurrentVillages(this.secondFormGroup.get("CurrenttehsilID").value);
       // this.secondFormGroup.get("CurrentVillageID").setValue(this.secondFormGroup.get("villageID").value);
       this.secondFormGroup.get("CurrentVillageID").setValue(null);
       //this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
       this.secondFormGroup.get('CurrentVillageID').setValidators(null);
       this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
      } 
  
  }
  else{
    this.secondFormGroup.get("CurrentAddressLine1").setValue(null);
    this.secondFormGroup.get("CurrentAddressLine2").setValue(null);
    this.secondFormGroup.get("CurrentAddressLine3").setValue(null);
    this.secondFormGroup.get("CurrentAddressOutOfStateDetails").setValue(null);
    this.secondFormGroup.get("CurrentAddressOutOfStateDetailsPunjabi").setValue(null);
    this.secondFormGroup.get("CurrentRegion").setValue(null);
    this.secondFormGroup.get("CurrentstateID").setValue(null);
    this.secondFormGroup.get("CurrentdistrictID").setValue(null);
    this.secondFormGroup.get("CurrenttehsilID").setValue(null);
    this.secondFormGroup.get("CurrentVillageID").setValue(null);
    this.secondFormGroup.get("Currentpincode").setValue(null);
    if(this.secondFormGroup.get("region").value === 'Urban'){
      this.CurrentRegion= false;
    }
    else if(this.secondFormGroup.get("region").value === 'Rural'){
      this.CurrentRegion= true;
    }
  }
} 
//
Changemaritalstatus(event){

  if(event == '1'){
    this.Maritalstatus = true;
    this.firstFormGroup.get('SpouseName').setValidators([Validators.required,AlphaValidator]);
    this.firstFormGroup.get('SpouseNameinPunjabi').setValidators([Validators.required, OnlyPunjabi]);
  }
  else{
    this.Maritalstatus = false;      
    this.firstFormGroup.get('SpouseName').setValidators(null);
    this.firstFormGroup.get('SpouseNameinPunjabi').setValidators(null);

    this.firstFormGroup.get('SpouseName').clearValidators();
    this.firstFormGroup.get('SpouseNameinPunjabi').clearValidators();
  }
  this.firstFormGroup.get('SpouseName').updateValueAndValidity();
  this.firstFormGroup.get('SpouseNameinPunjabi').updateValueAndValidity();
}
salutationSelected(event) {
  
  let target = event.source.selected._element.nativeElement;
   let selectedData = {
     value: event.value,
     text: target.innerText.trim()
   };
 //  console.log(selectedData);
}
witnessRelationSelected(event) {
  
  let target = event.source.selected._element.nativeElement;
   let selectedData = {
     value: event.value,
     text: target.innerText.trim()
   };
 //  console.log(selectedData);
}
addDynamicValidationInCaseOfBrideAddressInpunjab(){
  if(this.fourthFormGroup.get("IsBrideNRI").value == false && this.fourthFormGroup.get("IsBrideFromOtherState").value == false){
       //case outside punjab in india
       this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValidators(null);
       this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValidators(null);
       //case in punjab
       this.fourthFormGroup.get('BrideRegion').setValidators([Validators.required]);
       this.fourthFormGroup.get('BrideState').setValidators([Validators.required]);
       this.fourthFormGroup.get('BrideDistrict').setValidators([Validators.required]);
       this.fourthFormGroup.get('BrideTehsil').setValidators([Validators.required]);

       if(this.fourthFormGroup.get("BrideRegion").value =='Rural'  ){        
        this.BrideRegionRural = true;        
        this.fourthFormGroup.get('BrideVillage').setValidators([Validators.required]);
          this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();     
        } 
        else{
         this.BrideRegionRural = false;      
         this.fourthFormGroup.get("BrideVillage").setValue(null);
         this.fourthFormGroup.get('BrideVillage').setValidators(null);        
         this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
        } 
       this.fourthFormGroup.get('BridePincode').setValidators([Validators.required,Validators.minLength(6)]);
       this.fourthFormGroup.get('BrideStreetAddressLandmark').setValidators([Validators.required,EnglishAddress]);
       this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').setValidators([Validators.required,PunjabiAddress]);      
        
       // case NRI
       this.fourthFormGroup.get('BridePassportNumber').setValidators(null);
       this.fourthFormGroup.get('BridePassportIssuanceDate').setValidators(null);
       this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValidators(null);
       this.fourthFormGroup.get('BrideVisaType').setValidators(null);
       this.fourthFormGroup.get('BrideVisaDurationInYear').setValidators(null);
       this.fourthFormGroup.get('BrideVisaDurationInMonth').setValidators(null);
       this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValidators(null);
       this.fourthFormGroup.get('BrideSocialSecurityNumber').setValidators(null);
       this.fourthFormGroup.get('BrideNRIAddress').setValidators(null);
       this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValidators(null);
       //set value

       //case outside punjab in india
       this.fourthFormGroup.get('BrideAddressOutOfStateDetails').setValue(null); 
       this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').setValue(null); 
        
       // case NRI
       this.fourthFormGroup.get('BridePassportNumber').setValue(null); 
       this.fourthFormGroup.get('BridePassportIssuanceDate').setValue(null); 
       this.fourthFormGroup.get('BrideVisaGrantedByCountry').setValue(null); 
       this.fourthFormGroup.get('BrideVisaType').setValue(null); 
       this.fourthFormGroup.get('BrideVisaDurationInYear').setValue(null); 
       this.fourthFormGroup.get('BrideVisaDurationInMonth').setValue(null); 
       this.fourthFormGroup.get('BrideDateOfVisitInIndia').setValue(null); 
       this.fourthFormGroup.get('BrideSocialSecurityNumber').setValue(null); 
       this.fourthFormGroup.get('BrideNRIAddress').setValue(null); 
       this.fourthFormGroup.get('BrideNRIAddressPunjabi').setValue(null); 

       //new code
        //case outside punjab in india
   this.fourthFormGroup.get('BrideAddressOutOfStateDetails').updateValueAndValidity();
   this.fourthFormGroup.get('BrideAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
   //case in punjab
   this.fourthFormGroup.get('BrideRegion').updateValueAndValidity();
   this.fourthFormGroup.get('BrideState').updateValueAndValidity();
   this.fourthFormGroup.get('BrideDistrict').updateValueAndValidity();
   this.fourthFormGroup.get('BrideTehsil').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
   this.fourthFormGroup.get('BridePincode').updateValueAndValidity();
   this.fourthFormGroup.get('BrideStreetAddressLandmark').updateValueAndValidity();
   this.fourthFormGroup.get('BrideStreetAddressLandmarkPunjabi').updateValueAndValidity();
   // case NRI
   this.fourthFormGroup.get('BridePassportNumber').updateValueAndValidity();
   this.fourthFormGroup.get('BridePassportIssuanceDate').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaGrantedByCountry').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaType').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaDurationInYear').updateValueAndValidity();
   this.fourthFormGroup.get('BrideVisaDurationInMonth').updateValueAndValidity();
   this.fourthFormGroup.get('BrideDateOfVisitInIndia').updateValueAndValidity();
   this.fourthFormGroup.get('BrideSocialSecurityNumber').updateValueAndValidity();
   this.fourthFormGroup.get('BrideNRIAddress').updateValueAndValidity();
   this.fourthFormGroup.get('BrideNRIAddressPunjabi').updateValueAndValidity();
  }
  
}
addDynamicValidationInCaseOfGroomAddressInpunjab(){
  if(this.fifthFormGroup.get("IsGroomNRI").value == false && this.fifthFormGroup.get("IsGroomFromOtherState").value == false){
       //case outside punjab in india
       this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValidators(null);
       this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValidators(null);
       //case in punjab
       this.fifthFormGroup.get('GroomRegion').setValidators([Validators.required]);
       this.fifthFormGroup.get('GroomState').setValidators([Validators.required]);
       this.fifthFormGroup.get('GroomDistrict').setValidators([Validators.required]);
       this.fifthFormGroup.get('GroomTehsil').setValidators([Validators.required]);
       ////////////////////
       if(this.fifthFormGroup.get("GroomRegion").value =='Rural'  ){        
       this.GroomRegionRural = true;        
       this.fifthFormGroup.get('GroomVillage').setValidators([Validators.required]);
         this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();    
       }
       else{
        this.GroomRegionRural = false;      
        this.fifthFormGroup.get("GroomVillage").setValue(null);
        this.fifthFormGroup.get('GroomVillage').setValidators(null);        
        this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
       }
       this.fifthFormGroup.get('GroomPincode').setValidators([Validators.required,Validators.minLength(6)]);
       this.fifthFormGroup.get('GroomStreetAddressLandmark').setValidators([Validators.required,EnglishAddress]);
       this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').setValidators([Validators.required,PunjabiAddress]);
       // case NRI
       this.fifthFormGroup.get('GroomPassportNumber').setValidators(null);
       this.fifthFormGroup.get('GroomPassportIssuanceDate').setValidators(null);
       this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValidators(null);
       this.fifthFormGroup.get('GroomVisaType').setValidators(null);
       this.fifthFormGroup.get('GroomVisaDurationInYear').setValidators(null);
       this.fifthFormGroup.get('GroomVisaDurationInMonth').setValidators(null);
       this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValidators(null);
       this.fifthFormGroup.get('GroomSocialSecurityNumber').setValidators(null);
       this.fifthFormGroup.get('GroomNRIAddress').setValidators(null);
       this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValidators(null);
       //set value

       //case outside punjab in india
       this.fifthFormGroup.get('GroomAddressOutOfStateDetails').setValue(null); 
       this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').setValue(null); 
        
       // case NRI
       this.fifthFormGroup.get('GroomPassportNumber').setValue(null); 
       this.fifthFormGroup.get('GroomPassportIssuanceDate').setValue(null); 
       this.fifthFormGroup.get('GroomVisaGrantedByCountry').setValue(null); 
       this.fifthFormGroup.get('GroomVisaType').setValue(null); 
       this.fifthFormGroup.get('GroomVisaDurationInYear').setValue(null); 
       this.fifthFormGroup.get('GroomVisaDurationInMonth').setValue(null); 
       this.fifthFormGroup.get('GroomDateOfVisitInIndia').setValue(null); 
       this.fifthFormGroup.get('GroomSocialSecurityNumber').setValue(null); 
       this.fifthFormGroup.get('GroomNRIAddress').setValue(null); 
       this.fifthFormGroup.get('GroomNRIAddressPunjabi').setValue(null);        
  }
   //case outside punjab in india
   this.fifthFormGroup.get('GroomAddressOutOfStateDetails').updateValueAndValidity();
   this.fifthFormGroup.get('GroomAddressOutOfStateDetailsPunjabi').updateValueAndValidity();
   //case in punjab
   this.fifthFormGroup.get('GroomRegion').updateValueAndValidity();
   this.fifthFormGroup.get('GroomState').updateValueAndValidity();
   this.fifthFormGroup.get('GroomDistrict').updateValueAndValidity();
   this.fifthFormGroup.get('GroomTehsil').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
   this.fifthFormGroup.get('GroomPincode').updateValueAndValidity();
   this.fifthFormGroup.get('GroomStreetAddressLandmark').updateValueAndValidity();
   this.fifthFormGroup.get('GroomStreetAddressLandmarkPunjabi').updateValueAndValidity();
   // case NRI
   this.fifthFormGroup.get('GroomPassportNumber').updateValueAndValidity();
   this.fifthFormGroup.get('GroomPassportIssuanceDate').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaGrantedByCountry').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaType').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaDurationInYear').updateValueAndValidity();
   this.fifthFormGroup.get('GroomVisaDurationInMonth').updateValueAndValidity();
   this.fifthFormGroup.get('GroomDateOfVisitInIndia').updateValueAndValidity();
   this.fifthFormGroup.get('GroomSocialSecurityNumber').updateValueAndValidity();
   this.fifthFormGroup.get('GroomNRIAddress').updateValueAndValidity();
   this.fifthFormGroup.get('GroomNRIAddressPunjabi').updateValueAndValidity();
}

// genderSelected(event) {
 
//   let target = event.source.selected._element.nativeElement;
//    let selectedData = {
//      value: event.value,
//      text: target.innerText.trim()
//    };
//  //  console.log(selectedData);
// }
//end select change
step1Next(){
  //console.log(this.pipe.transform(now, 'dd/mm/yyyy'));
  //console.log(this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.firstFormGroup.get("date_of_birth").value));
 this.isStep1Next=true; 
 //dateConvertIntoMMDDYYYtoDDMMYYYY
 this.selectedmaritialDetails = _.find(this.maritalstatuslist, (mstl) => mstl.statusid == this.firstFormGroup.get("marital_status").value);
//console.log(this.selectedmaritialDetails);

//alert(this.pipe.transform(this.firstFormGroup.get("BrideDateOfBirth").value, 'MM/dd/yyyy'));
 //var now = Date.now();
    
// console.log(this.pipe.transform(now, 'dd/MM/yyyy'));
// //var convertedDate = moment('20/11/2016', 'dd/MM/yyyy');
// console.log(moment('20/11/2016', 'dd/MM/yyyy'));
// console.log(moment(moment('15-06-2010', 'DD-MM-YYYY')).format('MM-DD-YYYY'));

//console.log((this.pipe.transform(this.now, 'MM/dd/yyyy')));

//alert(this.firstFormGroup.get("BrideDateOfBirth").value);
this.thirdFormGroup.get("applicantname").setValue(this.firstFormGroup.get("first_name").value + " " +
this.firstFormGroup.get("middle_name").value + " " +
this.firstFormGroup.get("last_name").value);

 
}
step2Next(){
  this.isStep2Next=true; 
  this.thirdFormGroup.get("applicantaddress").setValue(this.secondFormGroup.get("CurrentAddressLine1").value + " " +
this.secondFormGroup.get("CurrentAddressLine2").value + " " +
this.secondFormGroup.get("CurrentAddressLine3").value);
  if((this.secondFormGroup.get("AddressIsOutOfState").value ==false)   ){
  this.permanentaddressdistrictDetails = _.find(this.districtList, (pdstlst) => pdstlst.district_id == this.secondFormGroup.get("districtID").value);
  //console.log(this.permanentaddressdistrictDetails);
  this.permanentaddresstehsilDetails = _.find(this.tehsilList, (ptehlst) => ptehlst.tehsil_id == this.secondFormGroup.get("tehsilID").value);
 // console.log(this.permanentaddresstehsilDetails);
  if(this.secondFormGroup.get("region").value =='Rural'  ){
  this.permanentaddressvillageDetails = _.find(this.villageList, (pvlglst) => pvlglst.village_id == this.secondFormGroup.get("villageID").value);
 // console.log(this.permanentaddressvillageDetails);
  }
  else{    
      this.permanentaddressvillageDetails={
      district_name: "",​
      name_in_punjabi: "",
      tehsil_name: "",​
      village_code: "0",​
      village_code_agri: "",​
      village_id: "",​
      village_name: "",​
      village_user_code: ""
      }
  }
}
else{
  this.permanentaddressdistrictDetails={
   district_id: "0",
   district_name : "",
   district_code : "",
   name_in_punjabi : "",
   dist_code_health : ""
  };
  this.permanentaddresstehsilDetails={
    
       tehsil_id : "0",
       tehsil_name : "",
       district_name : "",
       name_in_punjabi : "",
       teh_code_health : "",
       tehsil_user_code : "",
       is_sub_tehsil : ""
    
  }
  this.permanentaddressvillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    }
}
 
if( (this.secondFormGroup.get("CurrentAddressIsOutOfState").value ==false)){
  this.currentaddressdistrictDetails = _.find(this.currentdistrictList, (cdstlst) => cdstlst.district_id == this.secondFormGroup.get("CurrentdistrictID").value);
 // console.log(this.currentaddressdistrictDetails);
  this.currentaddresstehsilDetails = _.find(this.currenttehsilList, (ctehlst) => ctehlst.tehsil_id == this.secondFormGroup.get("CurrenttehsilID").value);
 // console.log(this.currentaddresstehsilDetails);
  if(this.secondFormGroup.get("CurrentRegion").value =='Rural'  ){
  this.currentaddressvillageDetails = _.find(this.currentvillageList, (cvlglst) => cvlglst.village_id == this.secondFormGroup.get("CurrentVillageID").value);
 // console.log(this.currentaddressvillageDetails);
  }
  else{    
    this.currentaddressvillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    }
}
}
else{
  this.currentaddressdistrictDetails={
   district_id: "0",
   district_name : "",
   district_code : "",
   name_in_punjabi : "",
   dist_code_health : ""
  };
  this.currentaddresstehsilDetails={    
       tehsil_id : "0",
       tehsil_name : "",
       district_name : "",
       name_in_punjabi : "",
       teh_code_health : "",
       tehsil_user_code : "",
       is_sub_tehsil : ""    
  }
  this.currentaddressvillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    }
}
 }
 step3Next(){
  this.isStep3Next=true; 
 }
 step4Next(){  
   this.addDynamicValidationInCaseOfBrideAddressInpunjab();
   this.selectedBridemaritialDetails = _.find(this.maritalstatuslist, (bmstl) => bmstl.statusid == this.fourthFormGroup.get("BrideStatusAtTimeOfMarriage").value);
  // console.log(this.selectedBridemaritialDetails);
   if((this.fourthFormGroup.get("IsBrideFromOtherState").value ==false) && (this.fourthFormGroup.get("IsBrideNRI").value ==false)){
    this.BridestateDetails = _.find(this.bridestateMaster, (bstlst) => bstlst.state_code == this.fourthFormGroup.get("BrideState").value);
    
   this.BridedistrictDetails = _.find(this.districtList, (bdstlst) => bdstlst.district_id == this.fourthFormGroup.get("BrideDistrict").value);
  // console.log(this.BridedistrictDetails);
   this.BridetehsilDetails = _.find(this.bridetehsilList, (btehlst) => btehlst.tehsil_id == this.fourthFormGroup.get("BrideTehsil").value);
  // console.log(this.BridetehsilDetails);
   this.selectBrideRegion(this.fourthFormGroup.get("BrideRegion").value);
   if(this.fourthFormGroup.get("BrideRegion").value ==='Rural'  ){
   this.BridevillageDetails = _.find(this.bridevillageList, (blglst) => blglst.village_id == this.fourthFormGroup.get("BrideVillage").value);
  // console.log(this.BridevillageDetails);
   }
   else{    
    this.BridevillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    }
  }
}
else{
  this.BridestateDetails= {
    response:"0",
    state_code:"0",
    state_name:""
  }; 
  this.BridedistrictDetails={
   district_id: "0",
   district_name : "",
   district_code : "",
   name_in_punjabi : "",
   dist_code_health : ""
  };
  this.BridetehsilDetails={
    
       tehsil_id : "0",
       tehsil_name : "",
       district_name : "",
       name_in_punjabi : "",
       teh_code_health : "",
       tehsil_user_code : "",
       is_sub_tehsil : ""
    
  };
  this.BridevillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    };
}
  this.isStep4Next=true; 
 }
 step5Next(){
   this.addDynamicValidationInCaseOfGroomAddressInpunjab();
   this.selectedGroommaritialDetails = _.find(this.maritalstatuslist, (gmstl) => gmstl.statusid == this.fifthFormGroup.get("GroomStatusAtTimeOfMarriage").value);
  // console.log(this.selectedGroommaritialDetails);
   if((this.fifthFormGroup.get("IsGroomFromOtherState").value ==false) && (this.fifthFormGroup.get("IsGroomNRI").value ==false)){   
    this.GroomstateDetails = _.find(this.groomstateMaster, (gstlst) => gstlst.state_code == this.fifthFormGroup.get("GroomState").value);
    
    this.GroomdistrictDetails = _.find(this.districtList, (gdstlst) => gdstlst.district_id == this.fifthFormGroup.get("GroomDistrict").value);
  //console.log(this.GroomdistrictDetails);
  this.GroomtehsilDetails = _.find(this.groomtehsilList, (gtehlst) => gtehlst.tehsil_id == this.fifthFormGroup.get("GroomTehsil").value);
  //console.log(this.GroomtehsilDetails);
  this.selectGroomRegion(this.fifthFormGroup.get("GroomRegion").value);
  if(this.fifthFormGroup.get("GroomRegion").value ==='Rural'  ){
  this.GroomvillageDetails = _.find(this.groomvillageList, (glglst) => glglst.village_id == this.fifthFormGroup.get("GroomVillage").value);
 //console.log(this.GroomvillageDetails);
  }
  else{    
    this.GroomvillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    }
}
}
else{
  this.GroomstateDetails= {
    response:"0",
    state_code:"0",
    state_name:""
  }; 
  this.GroomdistrictDetails={
   district_id: "0",
   district_name : "",
   district_code : "",
   name_in_punjabi : "",
   dist_code_health : ""
  };
  this.GroomtehsilDetails={    
       tehsil_id : "0",
       tehsil_name : "",
       district_name : "",
       name_in_punjabi : "",
       teh_code_health : "",
       tehsil_user_code : "",
       is_sub_tehsil : ""    
  };
  this.GroomvillageDetails={
    district_name: "",​
    name_in_punjabi: "",
    tehsil_name: "",​
    village_code: "0",​
    village_code_agri: "",​
    village_id: "",​
    village_name: "",​
    village_user_code: ""
    };
}
  
   this.isStep5Next=true; 
 }
 step6Next(){

  this.isStep6Next=true; 
 }
 step7Next(){
  this.isStep7Next=true; 
 }
 onSubmit(){
  this.isStep8Next=true; 
  this.step1Next();
  this.step2Next();
  this.step3Next();
  this.step4Next();
  this.step5Next();
  this.step6Next();
  this.step7Next();
  //this.step8Next();

  if (this.firstFormGroup.invalid === true || this.secondFormGroup.invalid === true || this.thirdFormGroup.invalid === true
    ||this.fourthFormGroup.invalid === true || this.fifthFormGroup.invalid === true || this.sixthFormGroup.invalid === true
    ||this.seventhFormGroup.invalid === true || this.eighthFormGroup.invalid === true  
    ) {    
      this._notification.warning("Please fill all required filled","warning");
    return;
  }
  for (var index in this.imagesList) {
   // console.log(index); // prints indexes: 0, 1, 2, 3  
    //console.log(arr[index]); // prints elements: 10, 20, 30, 40
  //  console.log(this.imagesList);
    var img = this.imagesList[index].base64;
    img = img.replace('data:image/png;base64,', '');
    this.imagesList[index].base64= img;
   // console.log(this.imagesList[index].base64);

  }
  let formData={};
  if(this.action === 'resubmit'){
    formData = {     
      applicationid : this.applicationID,
      serviceID :this.serviceID,
  
      service_data :{        
          citizenRefCode :this.citizenRefCode,
          applyingforself  :'Y',
          applicant_name  :this.firstFormGroup.get("first_name").value,
          applicant_name_pb  :this.firstFormGroup.get("first_name_punjabi").value,
          applicant_address  :this.secondFormGroup.get("CurrentAddressLine1").value, 
          applicant_address_pb:'',
  
          //
          salutation: this.firstFormGroup.get("Salutation").value,
          applicant_firstName  :this.firstFormGroup.get("first_name").value,
          applicant_firstName_pb  :this.firstFormGroup.get("first_name_punjabi").value,
          applicant_middleName  :this.firstFormGroup.get("middle_name").value,
          applicant_middleName_pb  :this.firstFormGroup.get("middle_name_punjabi").value,        
          applicant_lastName  :this.firstFormGroup.get("last_name").value,
          applicant_lastName_pb  :this.firstFormGroup.get("middle_name_punjabi").value,
  
          applicant_fathersFirstName :this.firstFormGroup.get("father_first_name").value,
          applicant_fathersFirstName_pb  :this.firstFormGroup.get("father_first_name_punjabi").value,
          applicant_fathersMiddleName  :this.firstFormGroup.get("father_middle_name").value,
          applicant_fathersMiddleName_pb  :this.firstFormGroup.get("father_middle_name_punjabi").value,
          applicant_fathersLastName  :this.firstFormGroup.get("father_last_name").value,
          applicant_fathersLastName_pb  :this.firstFormGroup.get("father_last_name_punjabi").value,
  
          applicant_mothersFirstName  :this.firstFormGroup.get("mother_first_name").value,
          applicant_mothersFirstName_pb  :this.firstFormGroup.get("mother_first_name_punjabi").value,
          applicant_mothersMiddleName  :this.firstFormGroup.get("mother_middle_name").value,
          applicant_mothersMiddleName_pb  :this.firstFormGroup.get("mother_middle_name_punjabi").value,
          applicant_mothersLastName  :this.firstFormGroup.get("mother_last_name").value,
          applicant_mothersLastName_pb :this.firstFormGroup.get("mother_last_name_punjabi").value,
  
          applicant_dob :this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.firstFormGroup.get("date_of_birth").value),
          applicant_age_in_year  :this.firstFormGroup.get("ApplicantAgeInYear").value,
          applicant_age_in_month  :this.firstFormGroup.get("ApplicantAgeInMonth").value,
          applicant_placeOfBirth :this.firstFormGroup.get("place_of_birth").value, 
          applicant_gender :this.firstFormGroup.get("gender").value,       
          ​
           
        //  applicant_maritalStatus:this.selectedmaritialDetails,
          applicant_maritalStatus:{
             statusid  :this.selectedmaritialDetails.statusid,
             status_title  :this.selectedmaritialDetails.status_title,
             status_title_pb  :this.selectedmaritialDetails.status_title_p,
              } ,
            applicant_spouseName  :this.firstFormGroup.get("SpouseName").value,
            applicant_spouseName_pb:this.firstFormGroup.get("SpouseNameinPunjabi").value,
            permanent_address:{
              address_isOutofState   :this.secondFormGroup.get("AddressIsOutOfState").value,
              address_line_1  :this.secondFormGroup.get("address_line_1").value,
              address_line_2  :this.secondFormGroup.get("address_line_2").value,
              address_line_3  :this.secondFormGroup.get("address_line_3").value,
              outofstate_address  :this.secondFormGroup.get("PermanentAddressOutOfStateDetails").value, 
              outofstate_address_pb:this.secondFormGroup.get("PermanentAddressOutOfStateDetailsPunjabi").value,
              address_pincode   :this.secondFormGroup.get("pincode").value,              
              address_region  :this.secondFormGroup.get("region").value,  
              address_district   :{
                  district_id :this.permanentaddressdistrictDetails.district_id,
                  district_name:this.permanentaddressdistrictDetails.district_name,
                  district_code :this.permanentaddressdistrictDetails.district_code,
                  name_in_punjabi:this.permanentaddressdistrictDetails.name_in_punjabi,                
              },
                address_tehsil   :{
                 tehsil_id   :this.permanentaddresstehsilDetails.tehsil_id,
                 tehsil_name  :this.permanentaddresstehsilDetails.tehsil_name,
                 district_name   :this.permanentaddresstehsilDetails.district_name,
                 name_in_punjabi   :this.permanentaddresstehsilDetails.name_in_punjabi,
                 teh_user_code  :this.permanentaddresstehsilDetails.tehsil_user_code,
                 is_sub_tehsil  :this.permanentaddresstehsilDetails.is_sub_tehsil,
  
              }  ,            
              address_village  :{
                  village_code :this.permanentaddressvillageDetails.village_code,
                  village_name :this.permanentaddressvillageDetails.village_name,
                  village_id :this.permanentaddressvillageDetails.village_id,
                  tehsil_name :this.permanentaddressvillageDetails.tehsil_name,
                  district_name :this.permanentaddressvillageDetails.district_name,
                  name_in_punjabi :this.permanentaddressvillageDetails.name_in_punjabi,
                  village_user_code:this.permanentaddressvillageDetails.village_user_code,
                  village_code_agri:this.permanentaddressvillageDetails.village_code_agri,         
                },
            },
            current_address: {
              address_isOutofState  :this.secondFormGroup.get("CurrentAddressIsOutOfState").value,
              address_line_1  :this.secondFormGroup.get("CurrentAddressLine1").value,            
              address_line_2  :this.secondFormGroup.get("CurrentAddressLine2").value,
              address_line_3  :this.secondFormGroup.get("CurrentAddressLine3").value,
              outofstate_address  :this.secondFormGroup.get("CurrentAddressOutOfStateDetails").value,
              outofstate_address_pb  :this.secondFormGroup.get("CurrentAddressOutOfStateDetailsPunjabi").value,
              address_pincode   :this.secondFormGroup.get("Currentpincode").value,              
              address_region  :this.secondFormGroup.get("CurrentRegion").value, 
              address_district   :{       
                  district_id :this.currentaddressdistrictDetails.district_id,
                  district_name:this.currentaddressdistrictDetails.district_name,
                  district_code :this.currentaddressdistrictDetails.district_code,
                  name_in_punjabi:this.currentaddressdistrictDetails.name_in_punjabi, 
              },
                address_tehsil   :{
                  tehsil_id   :this.currentaddresstehsilDetails.tehsil_id,
                  tehsil_name  :this.currentaddresstehsilDetails.tehsil_name,
                  district_name   :this.currentaddresstehsilDetails.district_name,
                  name_in_punjabi   :this.currentaddresstehsilDetails.name_in_punjabi,
                  teh_user_code  :this.currentaddresstehsilDetails.tehsil_user_code,
                  is_sub_tehsil  :this.currentaddresstehsilDetails.is_sub_tehsil,
   
               }    ,            
               address_village  :{
                  village_code :this.currentaddressvillageDetails.village_code,
                  village_name :this.currentaddressvillageDetails.village_name,
                  village_id :this.currentaddressvillageDetails.village_id,
                  tehsil_name :this.currentaddressvillageDetails.tehsil_name,
                  district_name :this.currentaddressvillageDetails.district_name,
                  name_in_punjabi :this.currentaddressvillageDetails.name_in_punjabi,
                  village_user_code:this.currentaddressvillageDetails.village_user_code,
                  village_code_agri:this.currentaddressvillageDetails.village_code_agri,         
                },
            },
              applicant_email :this.secondFormGroup.get("EmailID").value,
              applicant_mobileNo :this.secondFormGroup.get("mobile_no").value,
              applicant_phoneNo:this.secondFormGroup.get("PhoneNo").value,
              applicant_voterId :this.firstFormGroup.get("VoterIdCardNumber").value,
              applicant_aadhaarEnrollment:this.firstFormGroup.get("AadhaarEnrollmentNumber").value,
              applicant_aadhaar :this.firstFormGroup.get("AadhaarNumber").value,
              applicant_religion:{
                religionid :'',
                religionname:'',               
              }  ,
              applicant_bplNumber: this.firstFormGroup.get("BPLCardNumber").value, 
              applicant_verificationNumber:'', 
              issued_to :'', 
              designation_of_issuingPerson :'', 
              remarks :'', 
              enc_aadhaar :'', 
              service_details:{
             // dateSolemnizationMarriage: this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("DateSolemnizationMarriage").value),
              placeSolemnizationMarriage: this.thirdFormGroup.get("PlaceSolemnizationMarriage").value,
             // presentationMemorandumMarriage: this.thirdFormGroup.get("PresentationMemorandumMarriage").value,
             // personPresentingMemorandum : this.thirdFormGroup.get("PersonPresentingMemorandum").value,
              serviceMobileNumber: this.thirdFormGroup.get("ServiceMobileNumber").value,
              serviceEmail: this.thirdFormGroup.get("ServiceEmail").value,
              // nameOfPriest: this.thirdFormGroup.get("NameOfPriest").value,
              // fatherNameOfPriest: this.thirdFormGroup.get("FatherNameOfPriest").value,
              // addressOfPriest : this.thirdFormGroup.get("AddressOfPriest").value,
              },
              appImagesList:this.imagesList,
              bride_details:{
                name :this.fourthFormGroup.get("BrideName").value   , 
                name_pb :this.fourthFormGroup.get("BrideNamePunjabi").value   , 
                // mothersName:this.fourthFormGroup.get("BrideMotherName").value   , 
                // mothersName_pb:this.fourthFormGroup.get("BrideMotherNamePunjabi").value   , 
                fathersName :this.fourthFormGroup.get("BrideFatherName").value   , 
                fathersName_pb :this.fourthFormGroup.get("BrideFatherNamePunjabi").value   , 
                ageAtMarriage :'', 
                date_of_birth:this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fourthFormGroup.get("BrideDateOfBirth").value)  , 
                ageAtMarriage_years :this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInYear").value   , 
                ageAtMarriage_month :this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInMonth").value   , 
                nationality :this.fourthFormGroup.get("BrideNationality").value   , 
                isFromOtherState:this.fourthFormGroup.get("IsBrideFromOtherState").value   , 
                addressOutOfStateDetails:this.fourthFormGroup.get("BrideAddressOutOfStateDetails").value   , 
                addressOutOfStateDetailsPunjabi:this.fourthFormGroup.get("BrideAddressOutOfStateDetailsPunjabi").value   , 
                region:this.fourthFormGroup.get("BrideRegion").value   ,          
  
               // BridedistrictDetails
                state :this.BridestateDetails.state_name,  
                district:this.BridedistrictDetails.district_name,
                tehsil :this.BridetehsilDetails.tehsil_name,
                village :this.BridevillageDetails.village_name,
                stateID :this.BridestateDetails.state_code, 
                districtID :this.BridedistrictDetails.district_id,
                tehsilID :this.BridetehsilDetails.tehsil_id,            
                villageID :this.BridevillageDetails.village_id,
                pincode :this.fourthFormGroup.get("BridePincode").value   ,  
                addressLandmark:this.fourthFormGroup.get("BrideStreetAddressLandmark").value   , 
                addressLandmark_pb :this.fourthFormGroup.get("BrideStreetAddressLandmarkPunjabi").value   ,  
               // relationshipStatus_atMarr:this.fourthFormGroup.get("BrideStatusAtTimeOfMarriage").value   , 
               relationshipStatus_atMarriage:{
                  statusid  :this.selectedBridemaritialDetails.statusid,
                  status_title  :this.selectedBridemaritialDetails.status_title,
                  status_title_pb  :this.selectedBridemaritialDetails.status_title_p,
                   },  
                aadhaarNumber :this.fourthFormGroup.get("BrideAadhaarNumber").value   ,  
                aadhaarEnrollmentNumber :this.fourthFormGroup.get("BrideAadhaarEnrollmentNumber").value   ,  
                isNRI :this.fourthFormGroup.get("IsBrideNRI").value   , 
                nri_details:{
                    nri_passport :this.fourthFormGroup.get("BridePassportNumber").value   , 
                    nri_passportDateIssuance :this.fourthFormGroup.get("BridePassportIssuanceDate").value   , 
                    nri_visaGrantedByCountry :this.fourthFormGroup.get("BrideVisaGrantedByCountry").value   , 
                    nri_visaType :this.fourthFormGroup.get("BrideVisaType").value   , 
                    nri_visaDuration_years :this.fourthFormGroup.get("BrideVisaDurationInYear").value   , 
                    nri_visaDuration_months :this.fourthFormGroup.get("BrideVisaDurationInMonth").value   , 
                    nri_visitIndiaDate :this.fourthFormGroup.get("BrideDateOfVisitInIndia").value   , 
                    nri_foreignAddress :this.fourthFormGroup.get("BrideNRIAddress").value   , 
                    nri_foreignAddress_pb :this.fourthFormGroup.get("BrideNRIAddressPunjabi").value   , 
                    nri_foreignSSN :this.fourthFormGroup.get("BrideSocialSecurityNumber").value   ,                   
                }, 
                isAlive:'1', 
                currentaddressinforeign :this.fourthFormGroup.get("Bridecurrentaddressinforeign").value   , 
                currentaddressinforeignpunjabi :this.fourthFormGroup.get("Bridecurrentaddressinforeignpunjabi").value   , 
                lengthstaycurrentresidance :this.fourthFormGroup.get("Bridelengthstaycurrentresidance").value   , 
                occupation :this.fourthFormGroup.get("Brideoccupation").value   , 
              },
              groom_details:{
                name :this.fifthFormGroup.get("GroomName").value,
                name_pb :this.fifthFormGroup.get("GroomNamePunjabi").value,
                // mothersName:this.fifthFormGroup.get("GroomMotherName").value, 
                // mothersName_pb :this.fifthFormGroup.get("GroomMotherNamePunjabi").value, 
                fathersName :this.fifthFormGroup.get("GroomFatherName").value, 
                fathersName_pb :this.fifthFormGroup.get("GroomFatherNamePunjabi").value, 
                date_of_birth:this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fifthFormGroup.get("GroomDateOfBirth").value)   , 
                ageAtMarriage :'', 
                ageAtMarriage_years :this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInYear").value,
                ageAtMarriage_month :this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInMonth").value,
                nationality :this.fifthFormGroup.get("GroomNationality").value,
                isFromOtherState:this.fifthFormGroup.get("IsGroomFromOtherState").value   , 
                addressOutOfStateDetails:this.fifthFormGroup.get("GroomAddressOutOfStateDetails").value   , 
                addressOutOfStateDetailsPunjabi:this.fifthFormGroup.get("GroomAddressOutOfStateDetailsPunjabi").value   , 
                region:this.fifthFormGroup.get("GroomRegion").value   ,              
                state :this.GroomstateDetails.state_name,                
                district:this.GroomdistrictDetails.district_name,
                tehsil :this.GroomtehsilDetails.tehsil_name,
                village :this.GroomvillageDetails.village_name,
                stateID :this.GroomstateDetails.state_code,    
                districtID :this.GroomdistrictDetails.district_id,
                tehsilID :this.GroomtehsilDetails.tehsil_id,
                villageID :this.GroomvillageDetails.village_id,               
                pincode :this.fifthFormGroup.get("GroomPincode").value,
                addressLandmark:this.fifthFormGroup.get("GroomStreetAddressLandmark").value, 
                addressLandmark_pb :this.fifthFormGroup.get("GroomStreetAddressLandmarkPunjabi").value, 
               // relationshipStatus_atMarr:this.fifthFormGroup.get("GroomStatusAtTimeOfMarriage").value, 
               relationshipStatus_atMarriage:{
                  statusid  :this.selectedGroommaritialDetails.statusid,
                  status_title  :this.selectedGroommaritialDetails.status_title,
                  status_title_pb  :this.selectedGroommaritialDetails.status_title_p,
                   }, 
                aadhaarNumber :this.fifthFormGroup.get("GroomAadhaarNumber").value, 
                aadhaarEnrollmentNumber :this.fifthFormGroup.get("GroomAadhaarEnrollmentNumber").value,
                isNRI :this.fifthFormGroup.get("IsGroomNRI").value,
                nri_details:{
                    nri_passport :this.fifthFormGroup.get("GroomPassportNumber").value,
                    nri_passportDateIssuance :this.fifthFormGroup.get("GroomPassportIssuanceDate").value,
                    nri_visaGrantedByCountry :this.fifthFormGroup.get("GroomVisaGrantedByCountry").value,
                    nri_visaType :this.fifthFormGroup.get("GroomVisaType").value,
                    nri_visaDuration_years :this.fifthFormGroup.get("GroomVisaDurationInYear").value,
                    nri_visaDuration_months :this.fifthFormGroup.get("GroomVisaDurationInMonth").value,
                    nri_visitIndiaDate :this.fifthFormGroup.get("GroomDateOfVisitInIndia").value,
                    nri_foreignAddress :this.fifthFormGroup.get("GroomNRIAddress").value,
                    nri_foreignAddress_pb :this.fifthFormGroup.get("GroomNRIAddressPunjabi").value,
                    nri_foreignSSN :this.fifthFormGroup.get("GroomSocialSecurityNumber").value,                  
                }, 
                isAlive:'1',                  
                currentaddressinforeign :this.fifthFormGroup.get("Groomcurrentaddressinforeign").value   , 
                currentaddressinforeignpunjabi :this.fifthFormGroup.get("Groomcurrentaddressinforeignpunjabi").value   , 
                lengthstaycurrentresidance :this.fifthFormGroup.get("Groomlengthstaycurrentresidance").value   , 
                occupation :this.fifthFormGroup.get("Groomoccupation").value   , 
              },
              common_witness:[{
                witness_name :this.sixthFormGroup.get("CommonfirstWitnessName").value,
                witness_relation :this.sixthFormGroup.get("CommonFirstWitnessRelation").value,
                witness_father_husband_Name:this.sixthFormGroup.get("CommonFirstWitnessFatherHusbandName").value,
                witness_Address :this.sixthFormGroup.get("CommonFirstWitnessAddress").value,             
              },
              {
                witness_name :this.sixthFormGroup.get("CommonSecondWitnessName").value,
                witness_relation :this.sixthFormGroup.get("CommonSecondWitnessRelation").value,
                witness_father_husband_Name:this.sixthFormGroup.get("CommonSecondWitnessFatherHusbandName").value,
                witness_Address :this.sixthFormGroup.get("CommonSecondWitnessAddress").value,               
              },
              {
                witness_name :this.sixthFormGroup.get("CommonThirdWitnessName").value,
                witness_relation :this.sixthFormGroup.get("CommonThirdWitnessRelation").value,
                witness_father_husband_Name:this.sixthFormGroup.get("CommonThirdWitnessFatherHusbandName").value,
                witness_Address :this.sixthFormGroup.get("CommonThirdWitnessAddress").value,               
              }
            ],
               
              processing_region :this.eighthFormGroup.get("ProcessingRegion").value,
              processing_district:this.eighthFormGroup.get("ProcessingDistrict").value,
              processing_tehsil :this.eighthFormGroup.get("ProcessingTehsil").value,
              processing_office :this.eighthFormGroup.get("ProcessingOffice").value, 

              processing_district_dtl:_.find(this.currentdistrictList, (psdtnm) => psdtnm.district_id == this.eighthFormGroup.get("ProcessingDistrict").value),
   
              processing_tehsil_dtl : _.find(this.processingtehsilList, (psthnm) => psthnm.tehsil_id == this.eighthFormGroup.get("ProcessingTehsil").value),
              processing_office_dtl : _.find(this.processingOfficesList, (psolst) => psolst.office_id == this.eighthFormGroup.get("ProcessingOffice").value),

               },
      applicant_address :this.secondFormGroup.get("CurrentAddressLine1").value, 
      applicant_name :this.firstFormGroup.get("first_name").value + " " +
                      this.firstFormGroup.get("middle_name").value + " " +
                      this.firstFormGroup.get("last_name").value,
      dob :this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.firstFormGroup.get("date_of_birth").value),
      fatherfullname: this.firstFormGroup.get("father_first_name").value + " " +
                      this.firstFormGroup.get("father_middle_name").value + " " +
                      this.firstFormGroup.get("father_last_name").value,
      motherfullname :this.firstFormGroup.get("mother_first_name").value + " " +
                      this.firstFormGroup.get("mother_middle_name").value + " " +
                      this.firstFormGroup.get("mother_last_name").value,
      marital_status :this.firstFormGroup.get("marital_status").value,
      gender :this.firstFormGroup.get("gender").value,
      pincode :this.secondFormGroup.get("Currentpincode").value,
      region :this.secondFormGroup.get("CurrentRegion").value,   
      state_code :this.stateMaster.state_code,
      state_name :this.stateMaster.state_name,  
      district_code :this.currentaddressdistrictDetails.district_id,
      district_name :this.currentaddressdistrictDetails.district_name,
      division_code :'0',
      division_name :'',
      tehsil_code :this.currentaddresstehsilDetails.tehsil_id,
      tehsil_name :this.currentaddresstehsilDetails.tehsil_name,
      block_code :'0',
      block_name :'',
      village_code :this.currentaddressvillageDetails.village_code,
      village_name :this.currentaddressvillageDetails.village_name,
      citizenID : this.citizenRefCode,
      assignmentLevel :'',
      assignmentID :'',
      application_type:'', 
      doc_user_case :'',
      doc_user_case_value:'', 
      CurrentStage :'',
      currentStageRefID:'', 
      UserID     :''     
    }

  }
  else{
   formData = {     
    applicationid : '',
    serviceID :this.serviceID,

    service_data :{        
        citizenRefCode :this.citizenRefCode,
        applyingforself  :'Y',
        applicant_name  :this.firstFormGroup.get("first_name").value,
        applicant_name_pb  :this.firstFormGroup.get("first_name_punjabi").value,
        applicant_address  :this.secondFormGroup.get("CurrentAddressLine1").value, 
        applicant_address_pb:'',

        //
        salutation: this.firstFormGroup.get("Salutation").value,
        applicant_firstName  :this.firstFormGroup.get("first_name").value,
        applicant_firstName_pb  :this.firstFormGroup.get("first_name_punjabi").value,
        applicant_middleName  :this.firstFormGroup.get("middle_name").value,
        applicant_middleName_pb  :this.firstFormGroup.get("middle_name_punjabi").value,        
        applicant_lastName  :this.firstFormGroup.get("last_name").value,
        applicant_lastName_pb  :this.firstFormGroup.get("middle_name_punjabi").value,

        applicant_fathersFirstName :this.firstFormGroup.get("father_first_name").value,
        applicant_fathersFirstName_pb  :this.firstFormGroup.get("father_first_name_punjabi").value,
        applicant_fathersMiddleName  :this.firstFormGroup.get("father_middle_name").value,
        applicant_fathersMiddleName_pb  :this.firstFormGroup.get("father_middle_name_punjabi").value,
        applicant_fathersLastName  :this.firstFormGroup.get("father_last_name").value,
        applicant_fathersLastName_pb  :this.firstFormGroup.get("father_last_name_punjabi").value,

        applicant_mothersFirstName  :this.firstFormGroup.get("mother_first_name").value,
        applicant_mothersFirstName_pb  :this.firstFormGroup.get("mother_first_name_punjabi").value,
        applicant_mothersMiddleName  :this.firstFormGroup.get("mother_middle_name").value,
        applicant_mothersMiddleName_pb  :this.firstFormGroup.get("mother_middle_name_punjabi").value,
        applicant_mothersLastName  :this.firstFormGroup.get("mother_last_name").value,
        applicant_mothersLastName_pb :this.firstFormGroup.get("mother_last_name_punjabi").value,

        applicant_dob :this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.firstFormGroup.get("date_of_birth").value),
        applicant_age_in_year  :this.firstFormGroup.get("ApplicantAgeInYear").value,
        applicant_age_in_month  :this.firstFormGroup.get("ApplicantAgeInMonth").value,
        applicant_placeOfBirth :this.firstFormGroup.get("place_of_birth").value, 
        applicant_gender :this.firstFormGroup.get("gender").value,       
        ​
         
      //  applicant_maritalStatus:this.selectedmaritialDetails,
        applicant_maritalStatus:{
           statusid  :this.selectedmaritialDetails.statusid,
           status_title  :this.selectedmaritialDetails.status_title,
           status_title_pb  :this.selectedmaritialDetails.status_title_p,
            } ,
          applicant_spouseName  :this.firstFormGroup.get("SpouseName").value,
          applicant_spouseName_pb:this.firstFormGroup.get("SpouseNameinPunjabi").value,
          permanent_address:{
            address_isOutofState   :this.secondFormGroup.get("AddressIsOutOfState").value,
            address_line_1  :this.secondFormGroup.get("address_line_1").value,
            address_line_2  :this.secondFormGroup.get("address_line_2").value,
            address_line_3  :this.secondFormGroup.get("address_line_3").value,
            outofstate_address  :this.secondFormGroup.get("PermanentAddressOutOfStateDetails").value, 
            outofstate_address_pb:this.secondFormGroup.get("PermanentAddressOutOfStateDetailsPunjabi").value,
            address_pincode   :this.secondFormGroup.get("pincode").value,              
            address_region  :this.secondFormGroup.get("region").value,  
            address_district   :{
                district_id :this.permanentaddressdistrictDetails.district_id,
                district_name:this.permanentaddressdistrictDetails.district_name,
                district_code :this.permanentaddressdistrictDetails.district_code,
                name_in_punjabi:this.permanentaddressdistrictDetails.name_in_punjabi,                
            },
              address_tehsil   :{
               tehsil_id   :this.permanentaddresstehsilDetails.tehsil_id,
               tehsil_name  :this.permanentaddresstehsilDetails.tehsil_name,
               district_name   :this.permanentaddresstehsilDetails.district_name,
               name_in_punjabi   :this.permanentaddresstehsilDetails.name_in_punjabi,
               teh_user_code  :this.permanentaddresstehsilDetails.tehsil_user_code,
               is_sub_tehsil  :this.permanentaddresstehsilDetails.is_sub_tehsil,

            }  ,            
            address_village  :{
                village_code :this.permanentaddressvillageDetails.village_code,
                village_name :this.permanentaddressvillageDetails.village_name,
                village_id :this.permanentaddressvillageDetails.village_id,
                tehsil_name :this.permanentaddressvillageDetails.tehsil_name,
                district_name :this.permanentaddressvillageDetails.district_name,
                name_in_punjabi :this.permanentaddressvillageDetails.name_in_punjabi,
                village_user_code:this.permanentaddressvillageDetails.village_user_code,
                village_code_agri:this.permanentaddressvillageDetails.village_code_agri,         
              },
          },
          current_address: {
            address_isOutofState  :this.secondFormGroup.get("CurrentAddressIsOutOfState").value,
            address_line_1  :this.secondFormGroup.get("CurrentAddressLine1").value,            
            address_line_2  :this.secondFormGroup.get("CurrentAddressLine2").value,
            address_line_3  :this.secondFormGroup.get("CurrentAddressLine3").value,
            outofstate_address  :this.secondFormGroup.get("CurrentAddressOutOfStateDetails").value,
            outofstate_address_pb  :this.secondFormGroup.get("CurrentAddressOutOfStateDetailsPunjabi").value,
            address_pincode   :this.secondFormGroup.get("Currentpincode").value,              
            address_region  :this.secondFormGroup.get("CurrentRegion").value, 
            address_district   :{       
                district_id :this.currentaddressdistrictDetails.district_id,
                district_name:this.currentaddressdistrictDetails.district_name,
                district_code :this.currentaddressdistrictDetails.district_code,
                name_in_punjabi:this.currentaddressdistrictDetails.name_in_punjabi, 
            },
              address_tehsil   :{
                tehsil_id   :this.currentaddresstehsilDetails.tehsil_id,
                tehsil_name  :this.currentaddresstehsilDetails.tehsil_name,
                district_name   :this.currentaddresstehsilDetails.district_name,
                name_in_punjabi   :this.currentaddresstehsilDetails.name_in_punjabi,
                teh_user_code  :this.currentaddresstehsilDetails.tehsil_user_code,
                is_sub_tehsil  :this.currentaddresstehsilDetails.is_sub_tehsil,
 
             }    ,            
             address_village  :{
                village_code :this.currentaddressvillageDetails.village_code,
                village_name :this.currentaddressvillageDetails.village_name,
                village_id :this.currentaddressvillageDetails.village_id,
                tehsil_name :this.currentaddressvillageDetails.tehsil_name,
                district_name :this.currentaddressvillageDetails.district_name,
                name_in_punjabi :this.currentaddressvillageDetails.name_in_punjabi,
                village_user_code:this.currentaddressvillageDetails.village_user_code,
                village_code_agri:this.currentaddressvillageDetails.village_code_agri,         
              },
          },
            applicant_email :this.secondFormGroup.get("EmailID").value,
            applicant_mobileNo :this.secondFormGroup.get("mobile_no").value,
            applicant_phoneNo:this.secondFormGroup.get("PhoneNo").value,
            applicant_voterId :this.firstFormGroup.get("VoterIdCardNumber").value,
            applicant_aadhaarEnrollment:this.firstFormGroup.get("AadhaarEnrollmentNumber").value,
            applicant_aadhaar :this.firstFormGroup.get("AadhaarNumber").value,
            applicant_religion:{
              religionid :'',
              religionname:'',               
            }  ,
            applicant_bplNumber: this.firstFormGroup.get("BPLCardNumber").value, 
            applicant_verificationNumber:'', 
            issued_to :'', 
            designation_of_issuingPerson :'', 
            remarks :'', 
            enc_aadhaar :'', 
            service_details:{
           // dateSolemnizationMarriage: this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.thirdFormGroup.get("DateSolemnizationMarriage").value),
            placeSolemnizationMarriage: this.thirdFormGroup.get("PlaceSolemnizationMarriage").value,
           // presentationMemorandumMarriage: this.thirdFormGroup.get("PresentationMemorandumMarriage").value,
           // personPresentingMemorandum : this.thirdFormGroup.get("PersonPresentingMemorandum").value,
            serviceMobileNumber: this.thirdFormGroup.get("ServiceMobileNumber").value,
            serviceEmail: this.thirdFormGroup.get("ServiceEmail").value,
            // nameOfPriest: this.thirdFormGroup.get("NameOfPriest").value,
            // fatherNameOfPriest: this.thirdFormGroup.get("FatherNameOfPriest").value,
            // addressOfPriest : this.thirdFormGroup.get("AddressOfPriest").value,
            },
            bride_details:{
              name :this.fourthFormGroup.get("BrideName").value   , 
              name_pb :this.fourthFormGroup.get("BrideNamePunjabi").value   , 
              // mothersName:this.fourthFormGroup.get("BrideMotherName").value   , 
              // mothersName_pb:this.fourthFormGroup.get("BrideMotherNamePunjabi").value   , 
              fathersName :this.fourthFormGroup.get("BrideFatherName").value   , 
              fathersName_pb :this.fourthFormGroup.get("BrideFatherNamePunjabi").value   , 
              ageAtMarriage :'', 
              date_of_birth:this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fourthFormGroup.get("BrideDateOfBirth").value)  , 
              ageAtMarriage_years :this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInYear").value   , 
              ageAtMarriage_month :this.fourthFormGroup.get("BrideAgeAtTimeOfMarriageInMonth").value   , 
              nationality :this.fourthFormGroup.get("BrideNationality").value   , 
              isFromOtherState:this.fourthFormGroup.get("IsBrideFromOtherState").value   , 
              addressOutOfStateDetails:this.fourthFormGroup.get("BrideAddressOutOfStateDetails").value   , 
              addressOutOfStateDetailsPunjabi:this.fourthFormGroup.get("BrideAddressOutOfStateDetailsPunjabi").value   , 
              region:this.fourthFormGroup.get("BrideRegion").value   ,          

             // BridedistrictDetails
              state :this.BridestateDetails.state_name, 
              district:this.BridedistrictDetails.district_name,
              tehsil :this.BridetehsilDetails.tehsil_name,
              village :this.BridevillageDetails.village_name,
              stateID :this.BridestateDetails.state_code,  
              districtID :this.BridedistrictDetails.district_id,
              tehsilID :this.BridetehsilDetails.tehsil_id,            
              villageID :this.BridevillageDetails.village_id,
              pincode :this.fourthFormGroup.get("BridePincode").value   ,  
              addressLandmark:this.fourthFormGroup.get("BrideStreetAddressLandmark").value   , 
              addressLandmark_pb :this.fourthFormGroup.get("BrideStreetAddressLandmarkPunjabi").value   ,  
             // relationshipStatus_atMarr:this.fourthFormGroup.get("BrideStatusAtTimeOfMarriage").value   , 
             relationshipStatus_atMarriage:{
                statusid  :this.selectedBridemaritialDetails.statusid,
                status_title  :this.selectedBridemaritialDetails.status_title,
                status_title_pb  :this.selectedBridemaritialDetails.status_title_p,
                 },  
              aadhaarNumber :this.fourthFormGroup.get("BrideAadhaarNumber").value   ,  
              aadhaarEnrollmentNumber :this.fourthFormGroup.get("BrideAadhaarEnrollmentNumber").value   ,  
              isNRI :this.fourthFormGroup.get("IsBrideNRI").value   , 
              nri_details:{
                  nri_passport :this.fourthFormGroup.get("BridePassportNumber").value   , 
                  nri_passportDateIssuance :this.fourthFormGroup.get("BridePassportIssuanceDate").value   , 
                  nri_visaGrantedByCountry :this.fourthFormGroup.get("BrideVisaGrantedByCountry").value   , 
                  nri_visaType :this.fourthFormGroup.get("BrideVisaType").value   , 
                  nri_visaDuration_years :this.fourthFormGroup.get("BrideVisaDurationInYear").value   , 
                  nri_visaDuration_months :this.fourthFormGroup.get("BrideVisaDurationInMonth").value   , 
                  nri_visitIndiaDate :this.fourthFormGroup.get("BrideDateOfVisitInIndia").value   , 
                  nri_foreignAddress :this.fourthFormGroup.get("BrideNRIAddress").value   , 
                  nri_foreignAddress_pb :this.fourthFormGroup.get("BrideNRIAddressPunjabi").value   , 
                  nri_foreignSSN :this.fourthFormGroup.get("BrideSocialSecurityNumber").value   ,                   
              }, 
              isAlive:'1', 
              currentaddressinforeign :this.fourthFormGroup.get("Bridecurrentaddressinforeign").value   , 
              currentaddressinforeignpunjabi :this.fourthFormGroup.get("Bridecurrentaddressinforeignpunjabi").value   , 
              lengthstaycurrentresidance :this.fourthFormGroup.get("Bridelengthstaycurrentresidance").value   , 
              occupation :this.fourthFormGroup.get("Brideoccupation").value   , 
            },
            groom_details:{
              name :this.fifthFormGroup.get("GroomName").value,
              name_pb :this.fifthFormGroup.get("GroomNamePunjabi").value,
              // mothersName:this.fifthFormGroup.get("GroomMotherName").value, 
              // mothersName_pb :this.fifthFormGroup.get("GroomMotherNamePunjabi").value, 
              fathersName :this.fifthFormGroup.get("GroomFatherName").value, 
              fathersName_pb :this.fifthFormGroup.get("GroomFatherNamePunjabi").value, 
              date_of_birth:this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fifthFormGroup.get("GroomDateOfBirth").value)   , 
              ageAtMarriage :'', 
              ageAtMarriage_years :this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInYear").value,
              ageAtMarriage_month :this.fifthFormGroup.get("GroomAgeAtTimeOfMarriageInMonth").value,
              nationality :this.fifthFormGroup.get("GroomNationality").value,
              isFromOtherState:this.fifthFormGroup.get("IsGroomFromOtherState").value   , 
              addressOutOfStateDetails:this.fifthFormGroup.get("GroomAddressOutOfStateDetails").value   , 
              addressOutOfStateDetailsPunjabi:this.fifthFormGroup.get("GroomAddressOutOfStateDetailsPunjabi").value   , 
              region:this.fifthFormGroup.get("GroomRegion").value   ,              
              state :this.GroomstateDetails.state_name,              
              district:this.GroomdistrictDetails.district_name,
              tehsil :this.GroomtehsilDetails.tehsil_name,
              village :this.GroomvillageDetails.village_name,
              stateID :this.GroomstateDetails.state_code,  
              districtID :this.GroomdistrictDetails.district_id,
              tehsilID :this.GroomtehsilDetails.tehsil_id,
              villageID :this.GroomvillageDetails.village_id,               
              pincode :this.fifthFormGroup.get("GroomPincode").value,
              addressLandmark:this.fifthFormGroup.get("GroomStreetAddressLandmark").value, 
              addressLandmark_pb :this.fifthFormGroup.get("GroomStreetAddressLandmarkPunjabi").value, 
             // relationshipStatus_atMarr:this.fifthFormGroup.get("GroomStatusAtTimeOfMarriage").value, 
             relationshipStatus_atMarriage:{
                statusid  :this.selectedGroommaritialDetails.statusid,
                status_title  :this.selectedGroommaritialDetails.status_title,
                status_title_pb  :this.selectedGroommaritialDetails.status_title_p,
                 }, 
              aadhaarNumber :this.fifthFormGroup.get("GroomAadhaarNumber").value, 
              aadhaarEnrollmentNumber :this.fifthFormGroup.get("GroomAadhaarEnrollmentNumber").value,
              isNRI :this.fifthFormGroup.get("IsGroomNRI").value,
              nri_details:{
                  nri_passport :this.fifthFormGroup.get("GroomPassportNumber").value,
                  nri_passportDateIssuance :this.fifthFormGroup.get("GroomPassportIssuanceDate").value,
                  nri_visaGrantedByCountry :this.fifthFormGroup.get("GroomVisaGrantedByCountry").value,
                  nri_visaType :this.fifthFormGroup.get("GroomVisaType").value,
                  nri_visaDuration_years :this.fifthFormGroup.get("GroomVisaDurationInYear").value,
                  nri_visaDuration_months :this.fifthFormGroup.get("GroomVisaDurationInMonth").value,
                  nri_visitIndiaDate :this.fifthFormGroup.get("GroomDateOfVisitInIndia").value,
                  nri_foreignAddress :this.fifthFormGroup.get("GroomNRIAddress").value,
                  nri_foreignAddress_pb :this.fifthFormGroup.get("GroomNRIAddressPunjabi").value,
                  nri_foreignSSN :this.fifthFormGroup.get("GroomSocialSecurityNumber").value,                  
              }, 
              isAlive:'1', 
                currentaddressinforeign :this.fifthFormGroup.get("Groomcurrentaddressinforeign").value   , 
                currentaddressinforeignpunjabi :this.fifthFormGroup.get("Groomcurrentaddressinforeignpunjabi").value   , 
                lengthstaycurrentresidance :this.fifthFormGroup.get("Groomlengthstaycurrentresidance").value   , 
                occupation :this.fifthFormGroup.get("Groomoccupation").value   , 
            },
            appImagesList:this.imagesList,
            common_witness:[{
              witness_name :this.sixthFormGroup.get("CommonfirstWitnessName").value,
              witness_relation :this.sixthFormGroup.get("CommonFirstWitnessRelation").value,
              witness_father_husband_Name:this.sixthFormGroup.get("CommonFirstWitnessFatherHusbandName").value,
              witness_Address :this.sixthFormGroup.get("CommonFirstWitnessAddress").value,             
            },
            {
              witness_name :this.sixthFormGroup.get("CommonSecondWitnessName").value,
              witness_relation :this.sixthFormGroup.get("CommonSecondWitnessRelation").value,
              witness_father_husband_Name:this.sixthFormGroup.get("CommonSecondWitnessFatherHusbandName").value,
              witness_Address :this.sixthFormGroup.get("CommonSecondWitnessAddress").value,               
            }
            ,
              {
                witness_name :this.sixthFormGroup.get("CommonThirdWitnessName").value,
                witness_relation :this.sixthFormGroup.get("CommonThirdWitnessRelation").value,
                witness_father_husband_Name:this.sixthFormGroup.get("CommonThirdWitnessFatherHusbandName").value,
                witness_Address :this.sixthFormGroup.get("CommonThirdWitnessAddress").value,               
              }
          ],

            processing_region :this.eighthFormGroup.get("ProcessingRegion").value,
            processing_district:this.eighthFormGroup.get("ProcessingDistrict").value,
            processing_tehsil :this.eighthFormGroup.get("ProcessingTehsil").value,
            processing_office :this.eighthFormGroup.get("ProcessingOffice").value,      
            processing_district_dtl:_.find(this.currentdistrictList, (psdtnm) => psdtnm.district_id == this.eighthFormGroup.get("ProcessingDistrict").value),   
            processing_tehsil_dtl : _.find(this.processingtehsilList, (psthnm) => psthnm.tehsil_id == this.eighthFormGroup.get("ProcessingTehsil").value),
            processing_office_dtl : _.find(this.processingOfficesList, (psolst) => psolst.office_id == this.eighthFormGroup.get("ProcessingOffice").value),
                         
      },
    applicant_address :this.secondFormGroup.get("CurrentAddressLine1").value, 
    applicant_name :this.firstFormGroup.get("first_name").value + " " +
                    this.firstFormGroup.get("middle_name").value + " " +
                    this.firstFormGroup.get("last_name").value,
    dob :this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.firstFormGroup.get("date_of_birth").value),
    fatherfullname: this.firstFormGroup.get("father_first_name").value + " " +
                    this.firstFormGroup.get("father_middle_name").value + " " +
                    this.firstFormGroup.get("father_last_name").value,
    motherfullname :this.firstFormGroup.get("mother_first_name").value + " " +
                    this.firstFormGroup.get("mother_middle_name").value + " " +
                    this.firstFormGroup.get("mother_last_name").value,
    marital_status :this.firstFormGroup.get("marital_status").value,
    gender :this.firstFormGroup.get("gender").value,
    pincode :this.secondFormGroup.get("Currentpincode").value,
    region :this.secondFormGroup.get("CurrentRegion").value,   
    state_code :this.stateMaster.state_code,
    state_name :this.stateMaster.state_name,  
    district_code :this.currentaddressdistrictDetails.district_id,
    district_name :this.currentaddressdistrictDetails.district_name,
    division_code :'0',
    division_name :'',
    tehsil_code :this.currentaddresstehsilDetails.tehsil_id,
    tehsil_name :this.currentaddresstehsilDetails.tehsil_name,
    block_code :'0',
    block_name :'',
    village_code :this.currentaddressvillageDetails.village_code,
    village_name :this.currentaddressvillageDetails.village_name,
    citizenID : this.citizenRefCode,
    assignmentLevel :'',
    assignmentID :'',
    application_type:'', 
    doc_user_case :'',
    doc_user_case_value:'', 
    CurrentStage :'',
    currentStageRefID:'', 
    UserID     :''     
  }
}
 // console.log(formData);
  this.onSubmitApplication(formData);
 }

 dateConvertIntoMMDDYYYtoDDMMYYYY(date_data){  
  return(this.pipe.transform(date_data, 'dd/MM/yyyy'))

  // console.log(this.pipe.transform(now, 'dd/MM/yyyy'));
  // //var convertedDate = moment('20/11/2016', 'dd/MM/yyyy');
  // console.log(moment('20/11/2016', 'dd/MM/yyyy'));
  // console.log(moment(moment('15-06-2010', 'DD-MM-YYYY')).format('MM-DD-YYYY'));
 }
 dateConvertIntoDDMMYYYtoMMDDYYYY(data_date){
  return(moment(moment(data_date, 'DD/MM/YYYY')).format('MM/DD/YYYY'))
  // console.log(this.pipe.transform(now, 'dd/MM/yyyy'));
  // //var convertedDate = moment('20/11/2016', 'dd/MM/yyyy');
  // console.log(moment('20/11/2016', 'dd/MM/yyyy'));
  // console.log(moment(moment('15-06-2010', 'DD-MM-YYYY')).format('MM-DD-YYYY'));
 }
 dateConvertIntoMMDDYYYtoYYYYMMDD(date_data){  
  return(this.pipe.transform(date_data, 'yyyy/MM/dd'))

  // console.log(this.pipe.transform(now, 'dd/MM/yyyy'));
  // //var convertedDate = moment('20/11/2016', 'dd/MM/yyyy');
  // console.log(moment('20/11/2016', 'dd/MM/yyyy'));
  // console.log(moment(moment('15-06-2010', 'DD-MM-YYYY')).format('MM-DD-YYYY'));
 }
 
 fetchmaritalstatus(){
  var url = this.MarriageServicesAPI;
  var fetchMaritalStatus = this._appSettings.fetchMaritalStatus;
  url = url + fetchMaritalStatus;
  
  this._ConfigService.get(url)
  .subscribe(response => {
    if(response["response"] == 1){
      this.maritalstatuslist = response["data"];
    }});
}
DecryptCitizenID(){
  var url = this.eSewaURL;
  var DecryptCitizenID = this._appSettings.DecryptCitizenID;
  url = url + DecryptCitizenID + this.citizenRefCode;
  
  this._ConfigService.get(url)
  .subscribe(response => {
    if(response["response"] == 1){
      this.citizenID = response["sys_message"];
      this.fetchCitizenProfile();
      this.fetchCitizenAddress();
    }});
}
 fetchCitizenProfile(){
  var data = {
    selectfrom : "user",
    selectby : "citizen_profile",
    selectionparam1 : this.citizenRefCode,
  }

  var url = this.eSewaURL;
  var fetchMasterData = this._appSettings.fetchMasterData;
  url = url + fetchMasterData;

  this._ConfigService.post(url, data)
    .subscribe(response => {
      this._notification.responseHandler(response);
      if(response["response"] == 1){
        this.selected='2' ;
        this.citizenData = response["data"][0];
      //  console.log(this.citizenData);
        this.patchFormValue(this.citizenData, this.firstFormGroup);
        //this.firstFormGroup.get("date_of_birth").setValue(new Date(this.citizenData['date_of_birth']));
      
        // this.firstFormGroup.get("date_of_birth").setValue(new Date(this.citizenData['date_of_birth']));
        // this.firstFormGroup.patchValue({
        //   date_of_birth: moment(this.citizenData['date_of_birth']),
        // });

      //  var today = new Date(); // suppose todays date is 27-05-2020 
    //pastDate = new Date(2020, 05, 24);
    const  applicantDob=new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.citizenData['date_of_birth']))
    applicantDob.setFullYear(applicantDob.getFullYear() - 1); 
    this.firstFormGroup.patchValue({
      date_of_birth: new Date(applicantDob)
      //date_of_birth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.citizenData['date_of_birth']))
    });
    this.calculateAge(this.firstFormGroup.get("date_of_birth"));
 
        
        //spouse
        if(this.citizenData.marital_status=='1'){
          this.Maritalstatus = true;
          this.firstFormGroup.get('SpouseName').setValidators([Validators.required,AlphaValidator]);
          this.firstFormGroup.get('SpouseNameinPunjabi').setValidators([Validators.required, OnlyPunjabi]);
        }
        else{
          this.Maritalstatus = false;      
          this.firstFormGroup.get('SpouseName').setValidators(null);
          this.firstFormGroup.get('SpouseNameinPunjabi').setValidators(null);
      
          this.firstFormGroup.get('SpouseName').clearValidators();
          this.firstFormGroup.get('SpouseNameinPunjabi').clearValidators();
        }
        this.firstFormGroup.get('SpouseName').updateValueAndValidity();
        this.firstFormGroup.get('SpouseNameinPunjabi').updateValueAndValidity();
        //end spouse
        this.bindDynamicCalendar(); 
        this.fetchCitizenAddress();
        //console.log(this.citizenData);
      }
    }); 
}
fetchCitizenAddress(){
  var data = {
    selectfrom : "user",
    selectby : "profile_address",
    selectionparam1 : this.citizenRefCode,
  }
 //console.log( this.citizenRefCode);

  var url = this.eSewaURL;
  var fetchMasterData = this._appSettings.fetchMasterData;
  url = url + fetchMasterData;

  this._ConfigService.post(url, data)
    .subscribe(response => {
      this._notification.responseHandler(response);
      if(response["response"] == 1){
        this.citizenAddress = response["data"][0];
        this.citizenCurrentAddress = response["data"][1];
      //  console.log(this.citizenAddress);
      // this.patchFormValue(this.citizenData, this.secondFormGroup);
        this.patchFormValue(this.citizenAddress, this.secondFormGroup);
        //this.patchFormValue(this.citizenAddress, this.secondFormGroup);
       // console.log(this.citizenAddress);

        this.secondFormGroup.patchValue({ 
          EmailID: this.citizenData.EmailID,
          mobile_no:this.citizenData.mobile_no,
          AddressIsOutOfState:false,
          CurrentAddressIsOutOfState:false,
          // this.secondFormGroup.get("CurrentAddressIsOutOfState").setValue(false);
          // this.secondFormGroup.get("AddressIsOutOfState").setValue(false);
         });
         
          
        this.fourthFormGroup.patchValue({ 
          IsBrideNRI: false,
          IsBrideFromOtherState:false
         });

         this.fifthFormGroup.patchValue({ 
          IsGroomNRI: false,
          IsGroomFromOtherState:false
         });
       // this.secondFormGroup.get("EmailID").setValue(this.citizenData.EmailID);

        this.subDistricts(this.secondFormGroup.get("districtID").value);
        this.fetchVillages(this.secondFormGroup.get("tehsilID").value);
        
    //    if(this.secondFormGroup.get("isCurrentPermanentaddressSame").value == true){
          this.ShowCurrentAddressIsSameAsParentAddress=true;
          this.secondFormGroup.get("CurrentAddressLine1").setValue(this.citizenCurrentAddress["address_line_1"]);
          this.secondFormGroup.get("CurrentAddressLine2").setValue(this.citizenCurrentAddress["address_line_2"]);
          this.secondFormGroup.get("CurrentAddressLine3").setValue(this.citizenCurrentAddress["address_line_3"]);
          this.secondFormGroup.get("CurrentRegion").setValue(this.citizenCurrentAddress["region"]);
          this.secondFormGroup.get("CurrentstateID").setValue(this.citizenCurrentAddress["stateID"]);
          this.secondFormGroup.get("CurrentdistrictID").setValue(this.citizenCurrentAddress["districtID"]);
          this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
          this.secondFormGroup.get("CurrenttehsilID").setValue(this.citizenCurrentAddress["tehsilID"]);
          this.secondFormGroup.get("Currentpincode").setValue(this.citizenCurrentAddress["pincode"]);
          if(this.secondFormGroup.get("CurrentRegion").value =='Rural'  ){
          this.fetchcurrentVillages(this.secondFormGroup.get("CurrenttehsilID").value);
          this.secondFormGroup.get("CurrentVillageID").setValue(this.citizenCurrentAddress["villageID"]);
           
           
          this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
          //  this.secondFormGroup.get('villageID').setValidators(null);
            this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();

            this.CurrentRegion = true;      
          
          }
          if(this.secondFormGroup.get("CurrentRegion").value =='Urban'  ){
            //this.fetchcurrentVillages(this.secondFormGroup.get("CurrenttehsilID").value);
            //this.secondFormGroup.get("CurrentVillageID").setValue(this.citizenCurrentAddress["villageID"]);
             
             
            this.secondFormGroup.get('CurrentVillageID').setValidators(null);
            //  this.secondFormGroup.get('villageID').setValidators(null);
              this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
  
              this.CurrentRegion = false;      
            
            }            
              if(this.secondFormGroup.get("region").value =='Rural'  ){               
              this.PermanentRegion = true;
              this.secondFormGroup.get('villageID').setValidators([Validators.required]);
              //  this.secondFormGroup.get('villageID').setValidators(null);
                this.secondFormGroup.get('villageID').updateValueAndValidity();
     
              }
              if(this.secondFormGroup.get("region").value =='Urban'  ){
                this.PermanentRegion = false;
                this.secondFormGroup.get("villageID").setValue(null);
                //this.secondFormGroup.get('villageID').setValidators([Validators.required]);
                this.secondFormGroup.get('villageID').setValidators(null);
                this.secondFormGroup.get('villageID').updateValueAndValidity();
    
              }
              
          
          
//set validity----------------------------------------------------------------
    this.secondFormGroup.get('address_line_1').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('address_line_2').setValidators([EnglishAddress]);
    this.secondFormGroup.get('address_line_3').setValidators([EnglishAddress]);
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').setValidators(null); 
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').setValidators(null);       
    this.secondFormGroup.get('region').setValidators([Validators.required]);
    this.secondFormGroup.get('stateID').setValidators([Validators.required]);
    this.secondFormGroup.get('districtID').setValidators([Validators.required]);
    this.secondFormGroup.get('tehsilID').setValidators([Validators.required]);
    
    this.secondFormGroup.get('pincode').setValidators([Validators.required,Validators.minLength(6)]);      

    //set  
    this.secondFormGroup.get('address_line_1').updateValueAndValidity();
    this.secondFormGroup.get('address_line_2').updateValueAndValidity();
    this.secondFormGroup.get('address_line_3').updateValueAndValidity();
    this.secondFormGroup.get('PermanentAddressOutOfStateDetails').updateValueAndValidity();
    this.secondFormGroup.get('PermanentAddressOutOfStateDetailsPunjabi').updateValueAndValidity();       
    this.secondFormGroup.get('region').updateValueAndValidity();
    this.secondFormGroup.get('stateID').updateValueAndValidity();
    this.secondFormGroup.get('districtID').updateValueAndValidity();
    this.secondFormGroup.get('tehsilID').updateValueAndValidity();   
    this.secondFormGroup.get('pincode').updateValueAndValidity(); 

    //current valid
    this.secondFormGroup.get('CurrentAddressLine1').setValidators([Validators.required,EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressLine2').setValidators([EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressLine3').setValidators([EnglishAddress]);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetails').setValidators(null);
    this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').setValidators(null);      
    this.secondFormGroup.get('CurrentRegion').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentstateID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentdistrictID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrenttehsilID').setValidators([Validators.required]);
    this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
    this.secondFormGroup.get('Currentpincode').setValidators([Validators.required,Validators.minLength(6)]);  

    this.secondFormGroup.get('CurrentAddressLine1').updateValueAndValidity();
    this.secondFormGroup.get('CurrentAddressLine2').updateValueAndValidity();
    this.secondFormGroup.get('CurrentAddressLine3').updateValueAndValidity();
    this.secondFormGroup.get('CurrentAddressOutOfStateDetails').updateValueAndValidity();
    this.secondFormGroup.get('CurrentAddressOutOfStateDetailsPunjabi').updateValueAndValidity();     
    this.secondFormGroup.get('CurrentRegion').updateValueAndValidity();
    this.secondFormGroup.get('CurrentstateID').updateValueAndValidity();
    this.secondFormGroup.get('CurrentdistrictID').updateValueAndValidity();
    this.secondFormGroup.get('CurrenttehsilID').updateValueAndValidity();
    this.secondFormGroup.get('Currentpincode').updateValueAndValidity();
       
  
      }
    });

}
patchFormValue(Data, formGroup: FormGroup) {
  let patchValues = {};
  Object.keys(formGroup.controls).forEach((key: any) => {
    patchValues[key] = Data[key];
  });
  formGroup.patchValue(patchValues);
}
// convertToDate(str) {
//   var date = new Date(str),
//     mnth = ("0" + (date.getMonth() + 1)).slice(-2),
//     day = ("0" + date.getDate()).slice(-2);
//   return [mnth, day, date.getFullYear()].join("/");
// }
  getErrorMessageStep1(control: string) {
    
    if ( this.isStep1Next){
     this.isProcessing=false;
    // console.log(this.firstFormGroup);
      return FormErrorMessage(this.firstFormGroup, control);
    }
 }
 getErrorMessageStep2(control: string) {
  if ( this.isStep2Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.secondFormGroup, control);
  }
}
getErrorMessageStep3(control: string) {
  if ( this.isStep3Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.thirdFormGroup, control);
  }
}
getErrorMessageStep4(control: string) {
  if ( this.isStep4Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.fourthFormGroup, control);
  }
}
getErrorMessageStep5(control: string) {
  if ( this.isStep5Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.fifthFormGroup, control);
  }
}
getErrorMessageStep6(control: string) {
  if ( this.isStep6Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.sixthFormGroup, control);
  }
}
getErrorMessageStep7(control: string) {
  if ( this.isStep7Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.seventhFormGroup, control);
  }
}
getErrorMessageStep8(control: string) {
  if ( this.isStep8Next){
   this.isProcessing=false;
   // console.log(this.step1.value);
    return FormErrorMessage(this.eighthFormGroup, control);
  }
}
// fetch masters
fetchAllMasters(){
  this.fetchDistrict();
  this.fetchmaritalstatus();
//  this.DecryptCitizenID();
  if(this.action === 'submit'  ){
        this.DecryptCitizenID();
    }
    else{
        this.fetchApplicationDetail();
    }
  }

  //fetch application details (resubmit)
  fetchApplicationDetail(){
    this.loaderService.show();
     var url = this.MarriageServicesAPI;
    var GetApplicationDetail = this._appSettings.GetApplicationDetail;
    url = url + GetApplicationDetail + this.applicationID;
    
    this._ConfigService.get(url)
    .subscribe(response => {
    //  console.log(response);
      if(response["response"] == 1) {
        this.response_data = response["data"];
        this.service_data = response["data"]["service_data"];
        this.citizenRefCode = this.service_data['citizenRefCode'];    
        this.imagesList=  this.service_data['appImagesList'], 
        this.setDefaultImageonload();
       // date_of_birth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['applicant_dob']))),
     //  console.log(this.service_data['applicant_dob'])   
     //  console.log((this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['applicant_dob'])))    
     //   console.log(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['applicant_dob'])))
      //  console.log(new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['applicant_dob']))));
        this.firstFormGroup.patchValue({
            Salutation : this.service_data['salutation'],
            first_name : this.service_data['applicant_firstName'],
            first_name_punjabi : this.service_data['applicant_firstName_pb'],
            middle_name : this.service_data['applicant_middleName'],
            middle_name_punjabi : this.service_data['applicant_middleName_pb'],
            last_name : this.service_data['applicant_lastName'],
            last_name_punjabi : this.service_data['applicant_lastName_pb'],

            father_first_name: this.service_data['applicant_fathersFirstName'],
            father_first_name_punjabi: this.service_data['applicant_fathersFirstName_pb'],
            father_middle_name: this.service_data['applicant_fathersMiddleName'],
            father_middle_name_punjabi: this.service_data['applicant_fathersMiddleName_pb'],
            father_last_name: this.service_data['applicant_fathersLastName'],
            father_last_name_punjabi: this.service_data['applicant_fathersLastName_pb'],

            mother_first_name: this.service_data['applicant_mothersFirstName'],
            mother_first_name_punjabi: this.service_data['applicant_mothersFirstName_pb'],
            mother_middle_name: this.service_data['applicant_mothersMiddleName'],
            mother_middle_name_punjabi: this.service_data['applicant_mothersMiddleName_pb'],
            mother_last_name: this.service_data['applicant_mothersLastName'],
            mother_last_name_punjabi: this.service_data['applicant_mothersLastName_pb'],

            gender: this.service_data['applicant_gender'],
            
            //01/01/1981
            date_of_birth: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['applicant_dob']))),
            ApplicantAgeInYear:this. service_data['applicant_age_in_year'],
            ApplicantAgeInMonth:this. service_data['applicant_age_in_month'],
            place_of_birth: this.service_data['applicant_placeOfBirth'],
            marital_status: this.service_data['applicant_maritalStatus']['statusid'],
            SpouseName: this.service_data['applicant_spouseName'],
            SpouseNameinPunjabi: this.service_data['applicant_spouseName_pb'],
            VoterIdCardNumber: this.service_data['applicant_voterId'],
            AadhaarNumber: this.service_data['applicant_aadhaar'],
            AadhaarEnrollmentNumber: this.service_data['applicant_aadhaarEnrollment'],
            BPLCardNumber: this.service_data['applicant_bplNumber'],
             
        });
        this.Changemaritalstatus(this.service_data['applicant_maritalStatus']['statusid']);

        //first form               

        //end of first form       
        this.secondFormGroup.patchValue({
          EmailID: this.service_data['applicant_email'],
          PhoneNo: this.service_data['applicant_phoneNo'],
          mobile_no: this.service_data['applicant_mobileNo'],
          
          //isCurrentPermanentaddressSame: true,

          // Permanent Address
          AddressIsOutOfState: (/true/i).test(this.service_data['permanent_address']['address_isOutofState']),
          address_line_1: this.service_data['permanent_address']['address_line_1'],
          address_line_2: this.service_data['permanent_address']['address_line_2'],
          address_line_3: this.service_data['permanent_address']['address_line_3'],
          PermanentAddressOutOfStateDetails: this.service_data['permanent_address']['outofstate_address'],
          PermanentAddressOutOfStateDetailsPunjabi: this.service_data['permanent_address']['outofstate_address_pb'],
          region: this.service_data['permanent_address']['address_region'],
          stateID: "1",
          districtID: this.service_data['permanent_address']['address_district']['district_id'],
          pincode: this.service_data['permanent_address']['address_pincode'],
          
          // Current Address
          CurrentAddressIsOutOfState: (/true/i).test(this.service_data['current_address']['address_isOutofState']),
          CurrentAddressLine1: this.service_data['current_address']['address_line_1'],
          CurrentAddressLine2: this.service_data['current_address']['address_line_2'],
          CurrentAddressLine3: this.service_data['current_address']['address_line_3'],
          CurrentAddressOutOfStateDetails: this.service_data['current_address']['outofstate_address'],
          CurrentAddressOutOfStateDetailsPunjabi:this.service_data['current_address']['outofstate_address_pb'],
          CurrentRegion: this.service_data['current_address']['address_region'],
          CurrentstateID: "1",
          CurrentdistrictID: this.service_data['current_address']['address_district']['district_id'],
          Currentpincode: this.service_data['current_address']['address_pincode'],
        });


//second masetr

if( ((/true/i).test(this.service_data['permanent_address']['address_isOutofState'])==true) ){
   this.IsPermanentAddressInPunjab=false;
   this.IsPermanentAddressOutOfState=true;
   

}
else{
  this.subDistricts(this.secondFormGroup.get("districtID").value);
  this.secondFormGroup.patchValue({
    tehsilID: this.service_data['permanent_address']['address_tehsil']['tehsil_id'],
  }); 
this.selectPermanenRegion(this.service_data['permanent_address']['address_region']);
 
//Fetch Villages
if(this.service_data['permanent_address']['address_region'] === 'Rural'){
  this.PermanentRegion=true;
  this.fetchVillages(this.service_data['permanent_address']['address_tehsil']['tehsil_id']);
  this.secondFormGroup.patchValue({
    villageID : this.service_data['permanent_address']['address_village']['village_id'],
  });
}
else{
  this.PermanentRegion=false;

}
 
}

//////////////current
if( ((/true/i).test(this.service_data['current_address']['address_isOutofState'])==true) ){ 
 this.IsCurrentAddressNotOutofPunjab=false;
 this.IsCurrentAddressOutOfState=true;
// this.IsCurrentAddressOutOfState=true;

}
else{
  this.currentsubDistricts(this.secondFormGroup.get("CurrentdistrictID").value);
  this.secondFormGroup.patchValue({
    CurrenttehsilID: this.service_data['current_address']['address_tehsil']['tehsil_id'],
  });
  this.selectCurrentRegion(this.service_data['current_address']['address_region']);

//Fetch Villages 
if(this.service_data['current_address']['address_region'] === 'Rural'){
  this.CurrentRegion=true;
  this.fetchcurrentVillages(this.service_data['current_address']['address_tehsil']['tehsil_id']);
  this.secondFormGroup.patchValue({
    CurrentVillageID: this.service_data['current_address']['address_village']['village_id'],
  });
}
else{
  this.CurrentRegion=false;

}
}
////////////end current



//end of second master

        this.thirdFormGroup.patchValue({ 
           // DateSolemnizationMarriage: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['service_details']['dateSolemnizationMarriage']))),
            PlaceSolemnizationMarriage: this.service_data['service_details']['placeSolemnizationMarriage'],
           // PresentationMemorandumMarriage: this.service_data['service_details']['presentationMemorandumMarriage'],
         //   PersonPresentingMemorandum: this.service_data['service_details']['personPresentingMemorandum'],
            ServiceMobileNumber: this.service_data['service_details']['serviceMobileNumber'],
            ServiceEmail: this.service_data['service_details']['serviceEmail'],
            // NameOfPriest: this.service_data['service_details']['nameOfPriest'],
            // FatherNameOfPriest: this.service_data['service_details']['fatherNameOfPriest'],
            // AddressOfPriest: this.service_data['service_details']['addressOfPriest'],
        });
      //  this.calculateMarriageMonth(this.thirdFormGroup.get("DateSolemnizationMarriage"))
        this.fourthFormGroup.patchValue({ 
          BrideName: this.service_data['bride_details']['name'],
          BrideNamePunjabi: this.service_data['bride_details']['name_pb'],
          // BrideMotherName: this.service_data['bride_details']['mothersName'],
          // BrideMotherNamePunjabi: this.service_data['bride_details']['mothersName_pb'],
          BrideFatherName: this.service_data['bride_details']['fathersName'],
          BrideFatherNamePunjabi: this.service_data['bride_details']['fathersName_pb'],
          BrideDateOfBirth:new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['bride_details']['date_of_birth']))),
          BrideAgeAtTimeOfMarriageInYear: this.service_data['bride_details']['ageAtMarriage_years'],
          BrideAgeAtTimeOfMarriageInMonth: this.service_data['bride_details']['ageAtMarriage_month'],
          BrideNationality: this.service_data['bride_details']['nationality'],
          IsBrideFromOtherState: (/true/i).test(this.service_data['bride_details']['isFromOtherState']),         
          //BrideStatusAtTimeOfMarriage: '1',
          BrideStatusAtTimeOfMarriage: this.service_data['bride_details']['relationshipStatus_atMarriage']['statusid'],
          BrideAadhaarNumber: this.service_data['bride_details']['aadhaarNumber'],
          BrideAadhaarEnrollmentNumber: this.service_data['bride_details']['aadhaarEnrollmentNumber'],
          IsBrideNRI: (/true/i).test(this.service_data['bride_details']['isNRI']),
          //new code for missing in resubmit field
          Bridecurrentaddressinforeign: this.service_data['bride_details']['currentaddressinforeign'],
          Bridecurrentaddressinforeignpunjabi: this.service_data['bride_details']['currentaddressinforeignpunjabi'], 
          Bridelengthstaycurrentresidance: this.service_data['bride_details']['lengthstaycurrentresidance'],
          Brideoccupation: this.service_data['bride_details']['occupation'],
          
      });
      // alert((/true/i).test(this.service_data['bride_details']['isNRI']))
      // alert((/false/i).test(this.service_data['bride_details']['isNRI']))
      //for master data binding 
      if( ((/true/i).test(this.service_data['bride_details']['isNRI'])==true) || ((/true/i).test(this.service_data['bride_details']['isFromOtherState'])==true)  ){
        if(((/true/i).test(this.service_data['bride_details']['isNRI'])==true)){
        this.BrideNotNRI=false;
        this.BrideNRIDetails=true; 
        this.IsBrideAddressOutOfState=false;
        this.fourthFormGroup.patchValue({
          BridePassportNumber: this.service_data['bride_details']['nri_details']['nri_passport'],
          //BridePassportIssuanceDate: this.service_data['bride_details']['nri_details']['nri_passportDateIssuance'],
          BridePassportIssuanceDate: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['bride_details']['nri_details']['nri_passportDateIssuance']))),
          BrideVisaGrantedByCountry: this.service_data['bride_details']['nri_details']['nri_visaGrantedByCountry'],
          BrideVisaType: this.service_data['bride_details']['nri_details']['nri_visaType'],
          BrideVisaDurationInYear: this.service_data['bride_details']['nri_details']['nri_visaDuration_years'],
          BrideVisaDurationInMonth: this.service_data['bride_details']['nri_details']['nri_visaDuration_months'],
         // 
          BrideSocialSecurityNumber: this.service_data['bride_details']['nri_details']['nri_foreignSSN'],
          BrideNRIAddress: this.service_data['bride_details']['nri_details']['nri_foreignAddress'],
          BrideNRIAddressPunjabi: this.service_data['bride_details']['nri_details']['nri_foreignAddress_pb'],
          BrideDateOfVisitInIndia:new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['bride_details']['nri_details']['nri_visitIndiaDate']))),
      
      });  
      }
        else if(((/true/i).test(this.service_data['bride_details']['isFromOtherState'])==true)){
          this.BrideNotNRI=true;
          this.BrideNRIDetails=false;
          this.IsBrideAddressOutOfState=true;
          this.fourthFormGroup.patchValue({
          BrideAddressOutOfStateDetails: this.service_data['bride_details']['addressOutOfStateDetails'],
          BrideAddressOutOfStateDetailsPunjabi: this.service_data['bride_details']['addressOutOfStateDetailsPunjabi'],
        }); 
          }

    }
    else{
      this.BrideNotNRI=true;
      this.BrideNRIDetails=false;
      this.IsBrideAddressOutOfState=false;
      this.bridesubDistricts(this.service_data['bride_details']['districtID']);
      this.fourthFormGroup.patchValue({
        BrideRegion: this.service_data['bride_details']['region'],
        BrideState: this.service_data['bride_details']['stateID'],
        BrideDistrict: this.service_data['bride_details']['districtID'],
        BrideTehsil: this.service_data['bride_details']['tehsilID'],
       // BrideVillage: this.service_data['bride_details']['villageID'],
        BridePincode: this.service_data['bride_details']['pincode'],
        BrideStreetAddressLandmark: this.service_data['bride_details']['addressLandmark'],
        BrideStreetAddressLandmarkPunjabi: this.service_data['bride_details']['addressLandmark_pb'],
      });
      //this.bridesubDistricts(this.service_data['bride_details']['districtID']);
      

      this.selectBrideRegion(this.service_data['bride_details']['region']);
      //Fetch Villages
      if(this.service_data['bride_details']['region'] === 'Rural'){
        this.BrideRegionRural=true;
        this.fetchbrideVillages(this.service_data['bride_details']['tehsilID']);
        this.fourthFormGroup.patchValue({
          BrideVillage : this.service_data['bride_details']['villageID'],
        });
      }
      else{
        this.BrideRegionRural=false;
      }

    }
    if(this.fourthFormGroup.get("IsBrideNRI").value){
    this.CheckIsBrideNRI(this.fourthFormGroup.get("IsBrideNRI").value);
    }
    if(this.fourthFormGroup.get("IsBrideFromOtherState").value){
      this.CheckIsBrideFromOtherState(this.fourthFormGroup.get("IsBrideFromOtherState").value);
      }
    
      //end of master data binding
     
      this.fifthFormGroup.patchValue({ 
             GroomName: this.service_data['groom_details']['name'],
             GroomNamePunjabi: this.service_data['groom_details']['name_pb'],
            //  GroomMotherName: this.service_data['groom_details']['mothersName'],
            //  GroomMotherNamePunjabi: this.service_data['groom_details']['mothersName_pb'],
             GroomFatherName: this.service_data['groom_details']['fathersName'],
             GroomFatherNamePunjabi: this.service_data['groom_details']['fathersName_pb'],
             
             GroomDateOfBirth:new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['groom_details']['date_of_birth']))),
             GroomAgeAtTimeOfMarriageInYear: this.service_data['groom_details']['ageAtMarriage_years'],
             GroomAgeAtTimeOfMarriageInMonth: this.service_data['groom_details']['ageAtMarriage_month'],
             GroomNationality: this.service_data['groom_details']['nationality'],
             IsGroomFromOtherState: (/true/i).test(this.service_data['groom_details']['isFromOtherState']),
            
             
             GroomStatusAtTimeOfMarriage:this.service_data['groom_details']['relationshipStatus_atMarriage']['statusid'],
            // GroomStatusAtTimeOfMarriage: this.service_data['bride_detgroom_detailsails']['relationshipStatus_atMarriage']['statusid'],
             GroomAadhaarNumber: this.service_data['groom_details']['aadhaarNumber'],
             GroomAadhaarEnrollmentNumber: this.service_data['groom_details']['aadhaarEnrollmentNumber'],


             IsGroomNRI: (/true/i).test(this.service_data['groom_details']['isNRI']),
             // new code added missing in resubmit case
             Groomcurrentaddressinforeign:  this.service_data['groom_details']['currentaddressinforeign'],
             Groomcurrentaddressinforeignpunjabi:  this.service_data['groom_details']['currentaddressinforeignpunjabi'],
             Groomlengthstaycurrentresidance:  this.service_data['groom_details']['lengthstaycurrentresidance'],
             Groomoccupation:  this.service_data['groom_details']['occupation'],
             
    });
          //for master data binding 
          if( ((/true/i).test(this.service_data['groom_details']['isNRI'])==true) || ((/true/i).test(this.service_data['groom_details']['isFromOtherState'])==true)  ){
            if(((/true/i).test(this.service_data['groom_details']['isNRI'])==true)){
            this.GroomNotNRI=false;
            this.GroomNRIDetails=true;
            this.IsGroomAddressOutOfState=false;
            this.fifthFormGroup.patchValue({
            GroomPassportNumber: this.service_data['groom_details']['nri_details']['nri_passport'],
             GroomPassportIssuanceDate: new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['groom_details']['nri_details']['nri_passportDateIssuance']))),
             GroomVisaGrantedByCountry: this.service_data['groom_details']['nri_details']['nri_visaGrantedByCountry'],
             GroomVisaType: this.service_data['groom_details']['nri_details']['nri_visaType'],
             GroomVisaDurationInYear: this.service_data['groom_details']['nri_details']['nri_visaDuration_years'],
             GroomVisaDurationInMonth: this.service_data['groom_details']['nri_details']['nri_visaDuration_months'],
             
             GroomSocialSecurityNumber: this.service_data['groom_details']['nri_details']['nri_foreignSSN'],
             GroomNRIAddress: this.service_data['groom_details']['nri_details']['nri_foreignAddress'],
             GroomNRIAddressPunjabi: this.service_data['groom_details']['nri_details']['nri_foreignAddress_pb'],

              GroomDateOfVisitInIndia:new Date(this.dateConvertIntoMMDDYYYtoYYYYMMDD(this.dateConvertIntoDDMMYYYtoMMDDYYYY(this.service_data['groom_details']['nri_details']['nri_visitIndiaDate']))),
            });
            }
            else if(((/true/i).test(this.service_data['groom_details']['isFromOtherState'])==true)){
              this.GroomNotNRI=false;
              this.GroomNRIDetails=false;
              this.IsGroomAddressOutOfState=true;
              this.fifthFormGroup.patchValue({
                GroomAddressOutOfStateDetails: this.service_data['groom_details']['addressOutOfStateDetails'],
                GroomAddressOutOfStateDetailsPunjabi: this.service_data['groom_details']['addressOutOfStateDetailsPunjabi'],
              });
              }
    
        }
        else{
          this.GroomNotNRI=true;
          this.GroomNRIDetails=false;
          this.IsGroomAddressOutOfState=false;
    
          this.groomsubDistricts(this.service_data['groom_details']['districtID']);
          this.fifthFormGroup.patchValue({
             GroomRegion: this.service_data['groom_details']['region'],
             GroomState: this.service_data['groom_details']['stateID'],
             //GroomState: '1',
             GroomDistrict: this.service_data['groom_details']['districtID'],
             GroomTehsil: this.service_data['groom_details']['tehsilID'],
            // GroomVillage: this.service_data['groom_details']['villageID'],
             GroomPincode: this.service_data['groom_details']['pincode'],
             GroomStreetAddressLandmark: this.service_data['groom_details']['addressLandmark'],
             GroomStreetAddressLandmarkPunjabi: this.service_data['groom_details']['addressLandmark_pb'],
          });
    
          this.selectGroomRegion(this.service_data['groom_details']['region']);
          //Fetch Villages
          if(this.service_data['groom_details']['region'] === 'Rural'){
            this.GroomRegionRural=true;
            this.fetchgroomVillages(this.service_data['groom_details']['tehsilID']);
            this.fifthFormGroup.patchValue({
              GroomVillage : this.service_data['groom_details']['villageID'],
            });
          }
          else{
            this.GroomRegionRural=false;
          }
    
        }
        if(this.fifthFormGroup.get("IsGroomNRI").value){
          this.CheckIsGroomNRI(this.fifthFormGroup.get("IsGroomNRI").value);
          }
          if(this.fifthFormGroup.get("IsGroomFromOtherState").value){
            this.CheckIsGroomFromOtherState(this.fifthFormGroup.get("IsGroomFromOtherState").value);
            }
          //end of master data binding  
        
    
    this.sixthFormGroup.patchValue({ 
      CommonfirstWitnessName: this.service_data['common_witness'][0]['witness_name'],
      CommonFirstWitnessRelation: this.service_data['common_witness'][0]['witness_relation'],
      CommonFirstWitnessFatherHusbandName: this.service_data['common_witness'][0]['witness_father_husband_Name'],
      CommonFirstWitnessAddress: this.service_data['common_witness'][0]['witness_Address'],

      CommonSecondWitnessName: this.service_data['common_witness'][1]['witness_name'],
      CommonSecondWitnessRelation: this.service_data['common_witness'][1]['witness_relation'],
      CommonSecondWitnessFatherHusbandName: this.service_data['common_witness'][1]['witness_father_husband_Name'],
      CommonSecondWitnessAddress: this.service_data['common_witness'][1]['witness_Address'],
      
      CommonThirdWitnessName: this.service_data['common_witness'][2]['witness_name'],
      CommonThirdWitnessRelation: this.service_data['common_witness'][2]['witness_relation'],
      CommonThirdWitnessFatherHusbandName: this.service_data['common_witness'][2]['witness_father_husband_Name'],
      CommonThirdWitnessAddress: this.service_data['common_witness'][2]['witness_Address'],
         
  });
 
        this.bindDynamicCalendar();

       // Fetch Processing Offices
        this.eighthFormGroup.patchValue({

          ProcessingRegion: this.service_data['processing_region'],
          ProcessingDistrict: this.service_data['processing_district'],
          ProcessingTehsil:  this.service_data['processing_tehsil'],
          ProcessingOffice:this.service_data['processing_office'],

        });
        this.processingsubDistricts(this.service_data['processing_district']);
        this.fetchProcessingOfficeMasterByTehsilID(this.service_data['processing_tehsil']);
        //End Fetch Processing Offices
        
        this.isStep1Next=true;
        this.isStep2Next=true; 
        this.isStep3Next=true;
        this.isStep4Next=true; 
        this.isStep5Next=true;
        this.isStep6Next=true; 
        this.isStep7Next=true;
        this.isStep8Next=true; 
        // this.isStep3Next=true; 
        // this.isStep4Next=true; 
      
        this.loaderService.hide();
      
      
      
      
      
      
      
      
      
      
      }
    });
    this.loaderService.hide();
  }
  //end of resubmit data
  selectPermanenRegion(event){
    this.loaderService.show();
    if(event == 'Rural'){      
      this.PermanentRegion = true;      
      //this.secondFormGroup.get("villageID").setValue(null);
      this.secondFormGroup.get('villageID').setValidators([Validators.required]);
      //this.secondFormGroup.get('villageID').setValidators(null);
      this.secondFormGroup.get('villageID').updateValueAndValidity();
    }
    else{
      this.PermanentRegion = false;
      this.secondFormGroup.get("villageID").setValue(null);
      //this.secondFormGroup.get('villageID').setValidators([Validators.required]);
      this.secondFormGroup.get('villageID').setValidators(null);
      this.secondFormGroup.get('villageID').updateValueAndValidity();
    }
    this.loaderService.hide();
  }
  selectCurrentRegion(event){
    this.loaderService.show();
    if(event == 'Rural'){      
      this.CurrentRegion = true;      
          //  this.secondFormGroup.get("CurrentVillageID").setValue(null);
          this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
          //  this.secondFormGroup.get('CurrentVillageID').setValidators(null);
            this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
    }
    else{
      this.CurrentRegion = false;            
      this.secondFormGroup.get("CurrentVillageID").setValue(null);
      //this.secondFormGroup.get('CurrentVillageID').setValidators([Validators.required]);
      this.secondFormGroup.get('CurrentVillageID').setValidators(null);
      this.secondFormGroup.get('CurrentVillageID').updateValueAndValidity();
    }
    this.loaderService.hide();
  }

  selectBrideRegion(event){
   
    this.loaderService.show();
    if(event == 'Rural'){      
      this.BrideRegionRural = true;      
          //  this.fourthFormGroup.get("BrideVillage").setValue(null);
          this.fourthFormGroup.get('BrideVillage').setValidators([Validators.required]);
          //  this.fourthFormGroup.get('BrideVillage').setValidators(null);
            this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
    }
    else{
      this.BrideRegionRural = false;            
      this.fourthFormGroup.get("BrideVillage").setValue(null);
      //this.fourthFormGroup.get('BrideVillage').setValidators([Validators.required]);
      this.fourthFormGroup.get('BrideVillage').setValidators(null);
      this.fourthFormGroup.get('BrideVillage').updateValueAndValidity();
    }
    this.loaderService.hide();
  }

  selectGroomRegion(event){
    
    this.loaderService.show();
    if(event == 'Rural'){      
      this.GroomRegionRural = true;      
          //  this.fifthFormGroup.get("GroomVillage").setValue(null);
          this.fifthFormGroup.get('GroomVillage').setValidators([Validators.required]);
          //  this.fifthFormGroup.get('GroomVillage').setValidators(null);
            this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
    }
    else{
      this.GroomRegionRural = false;            
      this.fifthFormGroup.get("GroomVillage").setValue(null);
      //this.fifthFormGroup.get('GroomVillage').setValidators([Validators.required]);
      this.fifthFormGroup.get('GroomVillage').setValidators(null);
      this.fifthFormGroup.get('GroomVillage').updateValueAndValidity();
    }
    this.loaderService.hide();
  }
  fetchDistrict(){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchDistrict;
    url = url + fetchDistrict + 1;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.districtList = response["data"];
        this.currentdistrictList = response["data"];
      }});
      this.loaderService.hide();
  }
  subDistricts(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.tehsilList = response["data"];
      }});
      this.loaderService.hide();
  }
  currentsubDistricts(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.currenttehsilList = response["data"];
      }});
      this.loaderService.hide();
  }

  bridesubDistricts(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.bridetehsilList = response["data"];
      }});
      this.loaderService.hide();
  }

  groomsubDistricts(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchDistrict = this._appSettings.fetchTehsil;
    url = url + fetchDistrict + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.groomtehsilList = response["data"];
      }});
      this.loaderService.hide();
  }
  fetchVillages(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.villageList = response["data"];
      }});
      this.loaderService.hide();
  }
  fetchcurrentVillages(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.currentvillageList = response["data"];
      }});
      this.loaderService.hide();
  }
  fetchbrideVillages(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.bridevillageList = response["data"];
      }});
      this.loaderService.hide();
  }

  fetchgroomVillages(event){
    this.loaderService.show();
    var url = this.MarriageServicesAPI;
    var fetchVillages = this._appSettings.fetchVillages;
    url = url + fetchVillages + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.groomvillageList = response["data"];
      }});
      this.loaderService.hide();
  }
//end fetch Dist
//fetch processing Details

processingsubDistricts(event){
  this.loaderService.show();
  var url = this.MarriageServicesAPI;
  var fetchDistrict = this._appSettings.fetchTehsil;
  url = url + fetchDistrict + event;
  
  this._ConfigService.get(url)
  .subscribe(response => {
    if(response["response"] == 1){
      this.processingtehsilList = response["data"];
    }});
    this.loaderService.hide();
}

//end fetch processing Details
//start
// onSubmitApplication(data: any){
//   var url = environment.eSewaURL;
//   var SubmitData = this._appSettings.FetchMenu;
//   //  url = url + FetchMenu;
//   //this._ConfigService.post(url,data)
//   this._ConfigService.post('https://localhost:44325/api/ApplicationSubmit/submit',data)  
//       .subscribe(response => {
//         this._notification.responseHandler(response);
//         if(response["response"] == 1){           
//           this.apiRes = response["data"];
//         }
//         else {
//           this._notification.info("Please enter all required fields")
//         }
//       });
    
    
// }
//end
//new submit

async onSubmitApplication(data: any){
    this.loaderService.show(); 
  
  if(this.action === 'resubmit')
  {
    // var url = this._appSettings.eSewaURL;
    // var GetApplicationIdAtCreation = this._appSettings.GetApplicationIdAtCreation;
    // //url = url + GetApplicationIdAtCreation + "6";
    // url = url + GetApplicationIdAtCreation+"6"  ;
    var resubmiturl = this._appSettings.MarriageServicesAPI;  
    resubmiturl = resubmiturl + this._appSettings.ApplicationReSubmit;
    var ApplicationID =  this.applicationID;
        
        
        if(ApplicationID != null || ApplicationID != '' || ApplicationID > 0){
          data.applicationid=ApplicationID
       //get mapping stage and user
              url = '';
              url =  this.eSewaURL;
              var GetMappingStageAndUser = this._appSettings.GetMappingStageAndUser;
              url = url + GetMappingStageAndUser;
  
              let getactordata = {
                ServiceID : '',
                operation_level : '',
                operation_ref_id : '',
                SubmissionType : '',
              }               
                getactordata = {
                 ServiceID : this.serviceID,
                 operation_level : "District",
                 operation_ref_id :this.eighthFormGroup.get("ProcessingDistrict").value,
                 SubmissionType : 'Y',
                 }
                 data.assignmentID =this.eighthFormGroup.get("ProcessingDistrict").value;
                 data.assignmentLevel='District'
               
              this._ConfigService.post(url, getactordata)
              .subscribe(response => {
              if(response["response"] == 1){
                let MappingStage = response["data"];
                data.UserID = this.userID
                data.currentStage= MappingStage[0]["userID"],
                data.currentStageRefID= MappingStage[0]["stageID"];
               // console.log(data);
                
                if (this.fourthFormGroup.get("IsBrideNRI").value){
                  data.service_data.bride_details.nri_details.nri_visitIndiaDate= this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fourthFormGroup.get("BrideDateOfVisitInIndia").value);
                               
                }
                
                if(this.fifthFormGroup.get("IsGroomNRI").value){
                  data.service_data.groom_details.nri_details.nri_visitIndiaDate= this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fifthFormGroup.get("GroomDateOfVisitInIndia").value);
                   
                }
               // console.log(data);
                
        //submit application
         this._ConfigService.post(resubmiturl,data)
        .subscribe(response => {
         
          if(response["response"] == 1){
            //alert("App Resubmitpost");
            this._notification.success("Application has been resubmit successfully!","success");
           // console.log(response);
            window.location.href = environment.uploadDocumentURL + "uploaddocuments/" +
                    this.token + '/' + ApplicationID + '/resubmit/'+ this.serviceID;
            //return response["data"][0].applicationID;
            this.loaderService.hide();
          }
        else{
          this._notification.info("Application  resubmission failed!","failed"); 
        this.loaderService.hide();
        //  console.log(response);
        }}); 
      }
      else{
        this._notification.info("Application  resubmission failed!","failed");        
        this.loaderService.hide();
      }
      this.loaderService.hide();

    });//end of user get
      }
    
      this.loaderService.hide();
  }

  else{
    this.loaderService.show();
  var url = this._appSettings.eSewaURL;
  var GetApplicationIdAtCreation = this._appSettings.GetApplicationIdAtCreation;
  //url = url + GetApplicationIdAtCreation + "6";
  url = url + GetApplicationIdAtCreation+"6"  ;
  var submiturl = this._appSettings.MarriageServicesAPI;  
  submiturl = submiturl + this._appSettings.ApplicationSubmit;
  var ApplicationID = null;
  this._ConfigService.get(url)
  .subscribe(response => {
     
    if(response["response"] == 1){      
      ApplicationID = response["data"][0].applicationID;
      if(ApplicationID != null || ApplicationID != '' || ApplicationID > 0){  
      url =  this.eSewaURL;   
      } 
      } 
      
      if(ApplicationID != null || ApplicationID != '' || ApplicationID > 0){
        data.applicationid=ApplicationID
     //get mapping stage and user
            url = '';
            url =  this.eSewaURL;
            var GetMappingStageAndUser = this._appSettings.GetMappingStageAndUser;
            url = url + GetMappingStageAndUser;

            let getactordata = {
              ServiceID : '',
              operation_level : '',
              operation_ref_id : '',
              SubmissionType : '',
            }              
              getactordata = {
               ServiceID : this.serviceID,
               operation_level : "District",
               operation_ref_id :this.eighthFormGroup.get("ProcessingDistrict").value,
               SubmissionType : 'Y',
               }
               data.assignmentID =this.eighthFormGroup.get("ProcessingDistrict").value;
               data.assignmentLevel='District'
             
            this._ConfigService.post(url, getactordata)
            .subscribe(response => {
            if(response["response"] == 1){
              let MappingStage = response["data"];
              data.UserID = this.userID
              data.currentStage= MappingStage[0]["userID"],
              data.currentStageRefID= MappingStage[0]["stageID"];
              if (this.fourthFormGroup.get("IsBrideNRI").value){
                data.service_data.bride_details.nri_details.nri_visitIndiaDate= this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fourthFormGroup.get("BrideDateOfVisitInIndia").value);
                data.service_data.bride_details.nri_details.nri_passportDateIssuance=this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fourthFormGroup.get("BridePassportIssuanceDate").value);                
              }
              
              if(this.fifthFormGroup.get("IsGroomNRI").value){
                data.service_data.groom_details.nri_details.nri_visitIndiaDate= this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fifthFormGroup.get("GroomDateOfVisitInIndia").value);
                data.service_data.groom_details.nri_details.nri_passportDateIssuance= this.dateConvertIntoMMDDYYYtoDDMMYYYY(this.fifthFormGroup.get("GroomPassportIssuanceDate").value);  
              }
             // data.imagesList=this.imagesList;
            //  console.log(data);
      // return response["data"][0].applicationID;
      //submit application
      this._ConfigService.post(submiturl,data)
      .subscribe(response => {
         
        if(response["response"] == 1){
          this.loaderService.hide();
          this._notification.success("Application submitted","Success");            
          window.location.href = environment.uploadDocumentURL + "uploaddocuments/" +
                    this.token + '/' + ApplicationID + '/submit/'+ this.serviceID;
          //return response["data"][0].applicationID;
        }
      else{
        this.loaderService.hide();
        this._notification.info("Application submission failed!","Failed");   
        
      }});
      //end of submit application
      this.loaderService.hide();
    }
    this.loaderService.hide();
  }
  );//end of user get
   // }
   this.loaderService.hide();
  
}

  else{
    this.loaderService.hide();
    this._notification.info("Application submission failed!","Failed");   
     
  }});
}
 
}
}
 




