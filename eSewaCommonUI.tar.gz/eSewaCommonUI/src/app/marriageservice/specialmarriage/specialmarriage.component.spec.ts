import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialmarriageComponent } from './specialmarriage.component';

describe('SpecialmarriageComponent', () => {
  let component: SpecialmarriageComponent;
  let fixture: ComponentFixture<SpecialmarriageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecialmarriageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialmarriageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
