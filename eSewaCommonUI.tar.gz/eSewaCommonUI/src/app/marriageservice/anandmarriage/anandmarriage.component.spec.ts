import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnandmarriageComponent } from './anandmarriage.component';

describe('AnandmarriageComponent', () => {
  let component: AnandmarriageComponent;
  let fixture: ComponentFixture<AnandmarriageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnandmarriageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnandmarriageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
