import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import {UploaddocumentComponent} from './document/uploaddocument/uploaddocument.component';
import {IndexComponent} from './home/index/index.component';
import {LogoutComponent} from './logout/logout/logout.component';
import { CompulsorymarriageComponent } from './marriageservice/compulsorymarriage/compulsorymarriage.component';
import { CompulsorymarriageserviceComponent } from './marriageservice/compulsorymarriageservice/compulsorymarriageservice.component';
import { MarriageabilitycertificateComponent } from './marriageservice/marriageabilitycertificate/marriageabilitycertificate.component';
import { AnandmarriageComponent } from './marriageservice/anandmarriage/anandmarriage.component';
import { SpecialmarriageComponent } from './marriageservice/specialmarriage/specialmarriage.component';
import { HistoryComponent } from './history/history.component'; 
import { PaymentComponent } from './payment/payment.component'; 
const routes: Routes = [
  //   {
  //   path: 'history',
  //   component: HistoryComponent
  // }, 
    {
    path: 'history/:token',
    component: HistoryComponent
    },
    {
      path: 'payment/:token',
      component: PaymentComponent
    }
  // {
  //   path: ':token',
  //   component: IndexComponent
  // },
//   {
//     path: 'home/:token',
//     component: IndexComponent
//   },{
//     path: 'uploaddocument/:token',
//     component: UploaddocumentComponent
//   },{
//     path: 'logout',
//     component: LogoutComponent
//   },   
//   {
//     path: 'compulsorymarriage',
//     component: CompulsorymarriageComponent
//   },
//   {
//     path: 'compulsorymarriageservice',
//     component: CompulsorymarriageserviceComponent
//   },
//   {
//     path: 'marriageabilitycertificate/:token/:action/:serviceID/:userID',
//     component: MarriageabilitycertificateComponent
//   }, 
//   // Resubmit Case
//   {
//     path: 'marriageabilitycertificate/:token/:action/:applicationID',
//     component: MarriageabilitycertificateComponent
//   },
//   {
//     path: 'compulsorymarriageservice/:token/:action/:serviceID/:userID',
//     component: CompulsorymarriageserviceComponent
//   },
//   // Resubmit Case
//   {
//    path: 'compulsorymarriageservice/:token/:action/:applicationID',
//    component: CompulsorymarriageserviceComponent
//  },
//  //anand marriage route
//  {
//    path: 'anandmarriageservice/:token/:action/:serviceID/:userID',
//    component: AnandmarriageComponent
//  },
//  // Resubmit Case
//  {
//   path: 'anandmarriageservice/:token/:action/:applicationID',
//   component: AnandmarriageComponent
// },
//  //special marriage route
//  {
//   path: 'specialmarriageservice/:token/:action/:serviceID/:userID',
//   component: SpecialmarriageComponent
// },
// // Resubmit Case
// {
//  path: 'specialmarriageservice/:token/:action/:applicationID',
//  component: SpecialmarriageComponent
// }
];

@NgModule({
  imports: [
    CommonModule,
    [RouterModule.forRoot(routes)],
  ],
  //imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
