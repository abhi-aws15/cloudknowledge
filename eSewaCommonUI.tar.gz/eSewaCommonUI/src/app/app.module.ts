import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateAdapter } from "@angular/material/core";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { MenuComponent } from './common/menu/menu.component';
import { UploaddocumentComponent } from './document/uploaddocument/uploaddocument.component';
import { IndexComponent } from './home/index/index.component';

import { ValidationService } from './services/validation.service';

import { ToastrModule } from 'ngx-toastr';
import { LogoutComponent } from './logout/logout/logout.component';
import { CompulsorymarriageComponent } from './marriageservice/compulsorymarriage/compulsorymarriage.component';
import { CompulsorymarriageserviceComponent } from './marriageservice/compulsorymarriageservice/compulsorymarriageservice.component';
import { AppMaterialModule } from "./app-material-modules";
import { DirectivesDirective } from './directive/directives.directive';
import { DateFormat } from "src/app/config/date-format";
import { LoaderComponent } from './loader/loader.component';
import { AnandmarriageComponent } from './marriageservice/anandmarriage/anandmarriage.component';
import { SpecialmarriageComponent } from './marriageservice/specialmarriage/specialmarriage.component';
import { MarriageabilitycertificateComponent } from './marriageservice/marriageabilitycertificate/marriageabilitycertificate.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HistoryComponent } from './history/history.component';
import { MatTableExporterModule } from 'mat-table-exporter';
import { PaymentComponent } from './payment/payment.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    UploaddocumentComponent,
    IndexComponent,
    LogoutComponent,
    CompulsorymarriageComponent,
    CompulsorymarriageserviceComponent,
    DirectivesDirective,
    LoaderComponent,
    AnandmarriageComponent,
    SpecialmarriageComponent,
    MarriageabilitycertificateComponent,
    HistoryComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    // import HttpClientModule after BrowserModule.
    HttpClientModule,
    BrowserAnimationsModule,
    AppMaterialModule,
    ToastrModule.forRoot({
      preventDuplicates: true,
      maxOpened: 5
    }),
    NgxSpinnerModule,
    MatTableExporterModule,
  ],
  providers: [{ provide: DateAdapter, useClass: DateFormat }, DatePipe, ValidationService],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private dateAdapter: DateAdapter<Date>) {
    dateAdapter.setLocale("en-in"); // DD/MM/YYYY
  } 
}
