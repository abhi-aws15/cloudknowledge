export interface TablePagingInterface {
    total: number;
    pageIndex: number;
    previousPageIndex: number;
    pageSize: number;  
}