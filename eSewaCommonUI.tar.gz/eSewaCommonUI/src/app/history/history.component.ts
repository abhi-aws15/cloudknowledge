import { Component, OnInit,ElementRef,  Renderer2, ViewChild,AfterViewInit } from '@angular/core'; 
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';
import { DateAdapter } from '@angular/material/core';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from 'src/environments/environment';
import { AppsettingsService } from '../config/appsettings.service';
import { ConfigService } from '../config/config.service';
import { CommonservicesService } from '../services/commonservices.service';
//import { EncryptiondecryptionserviceService } from '../services/encryptiondecryptionservice.service';
import { NotificationService } from '../services/notification.service';
import {MatPaginator, PageEvent} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table'; 
import { TablePagingInterface } from '../history/history.interface';
 import { Aadhaar, AlphaNumericValidator,AlphaValidator,email, EnglishAddress, AadhaarEnrolmentNumber, FormErrorMessage,mobile,NumOnly,OnlyPunjabi, PassportNo, PunjabiAddress, SocialSecurityNumber, VoterID, NumericValidator } from 'src/app/services/custom.validators';
 
import * as _ from 'lodash';
import { mapTo } from 'rxjs/operators';
import { Moment } from 'moment';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
 
import { EncryptiondecryptionserviceService } from 'src/app/services/encryptiondecryptionservice.service';
 
 

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  displayedColumns: string[] = ['applicationID', 'serviceID', 'service_name'];
  dataSource = new MatTableDataSource<HistoryElement>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  selecteSearchBy: any;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  MarriageServicesAPI: any;
  public CommonEsewaAPI: any;
  tehsilList: any;
  firstFormGroup: any;
  departmentList: any;
  currentdepartmentList: any;
  eSewaURL: string;
  PostGreMasterAPI: string;
  responseData: any;
  userID: any;
  // private _encdecrService: any;
  token: string;
  sub: any;
  SubDepartmentList: any;
  CurrentSubDepartmentList: any;
  servicesList: any;
  currentServicesList: any;
  minDate: Date;
  maxDate: Date;
  public selectedApplicationStatus = 'Z'; 
  public button_text: string = 'Filter Results'; 

  constructor(private _formBuilder: FormBuilder,
    private renderer: Renderer2,
    private route: ActivatedRoute, 
    private _appSettings: AppsettingsService, 
    private _ConfigService: ConfigService,
    private _notification: NotificationService,
    private _commonService: CommonservicesService,
   // private loaderService: LoaderService,
    private adapter: DateAdapter<any>,
    private _encdecrService: EncryptiondecryptionserviceService,
    private loader_spinner: NgxSpinnerService) {
   //   this.captures = [];
    }
  

    public tableOptions: TablePagingInterface = {
      total: 0,
      pageIndex: 0,
      previousPageIndex: 0,
      pageSize: 10 
    };  

    ngOnInit() {  
    this.sub = this.route.params.subscribe(params => {
      this.token = params['token']; // (+) converts string 'token' to a number      
     // this.action = params['action'];  
   
    });
  
    if(window.localStorage.getItem("TokenID")=='' || window.localStorage.getItem("TokenID")== null || window.localStorage.getItem("TokenID")== undefined ){
      this.ValidateToken(1);
    }
    else{
      if (window.localStorage.getItem("TokenID") == this.token) {
        this.ValidateToken(0);
      }
      else{        
        window.localStorage.clear();
        this.ValidateToken(1);
      }
    }

    this.MarriageServicesAPI=this._appSettings.MarriageServicesAPI;  
    this.firstFormGroup = this._formBuilder.group({ 
     // departmentID: new FormControl(null,Validators.required),
     departmentID: new FormControl(null,Validators.required),
      subDeptID: new FormControl(null),
      servicesId: new FormControl(null),
      searchBy:new FormControl(null),
      startDate: new FormControl(null),
      endDate: new FormControl(null),
      ApplicationID:  new FormControl(null),
      applicationStatus: new FormControl(null),

     });
     this.fetchDepartments();
  }
  ValidateToken(redirect){
    // window.localStorage.getItem("token")
     if(this.token != null || this.token !=""){
       var url = this._appSettings.eSewaURL;
       var ValidateToken = this._appSettings.ValidateToken;
       url = url + ValidateToken + this.token;
       
       this._ConfigService.getWithoutHeader(url)
       .subscribe(response => {
         this._notification.responseHandler(response);
         if(response["response"] == 1){  
           if(redirect === 1){
              window.localStorage.clear();
              window.localStorage.setItem("TokenID", this.token);
              // window.localStorage.setItem("token", response["data"][0]["Token"]);
              window.localStorage.setItem("token", this._encdecrService.Encrypt(response["data"][0]["Token"]));
             // window.localStorage.setItem("session", response["data"][0]["Session"]);
              window.localStorage.setItem("session", this._encdecrService.Encrypt(response["data"][0]["Session"]));                 
              window.localStorage.setItem("user_type", response["data"][0]["user_type"]);
              window.location.reload();
           }
           else{
              this.PostGreMasterAPI = this._appSettings.PostGreMasterAPI;   
              this.MarriageServicesAPI=this._appSettings.MarriageServicesAPI;               
              this.eSewaURL = this._appSettings.eSewaURL;
              this.responseData = response["data"][0];
              this._commonService.BindMenu();
              this.userID = this.responseData.userID;                  
 
         
            //   this.fetchAllMasters();
            //   this.startCamera();
            // //  this.setDefaultImageonload();
            //   this.isProcessing=true;
            //   this.fetchCitizenProfile();
            //   //this.fetchCitizenAddress();
           }
           this.firstFormGroup.get("applicationStatus").setValue("Z");
         }
         else {
            window.localStorage.clear();
            //this._commonService.BindMenu();
            this.loader_spinner.hide();
            this._notification.warning("Session Expired!","Warning");
            
              setTimeout (() => {
           //    window.location.href = environment.eSewaURL;
            }, 2000);
           // window.sessionStorage.clear();
           // window.location.href = environment.eSewaURL;
         }
       },
       err=>{
        this.loader_spinner.hide();
        this._notification.error("Something Went Wrong Please Try Again!","Error");
      //   console.log("status code--->"+err.status)
       });
       // In a real app: dispatch action to load the details here.
       }
       else{
        this.loader_spinner.hide();
        this._notification.warning("Session Expired!","Warning");
        
        //this._notification.warning("Session Expired!","Warning");
        setTimeout (() => {
          window.location.href = environment.eSewaURL;
       }, 2000);
         // window.localStorage.clear();
         // window.sessionStorage.clear();
       }
 }
 fetchDepartments(){
    var data = {
      selectionType : "DEPARTMENTS"
    }
    //this.loaderService.show();
    var url = this._appSettings.CommonEsewaAPI;
    var fetchDepartment = this._appSettings.fetchDepartment;
    url = url + fetchDepartment;
    this._ConfigService.post(url, data)
    .subscribe(response => {
      if(response["response"] == 1){
        console.log(response);
        this.departmentList = response["data"];
        this.currentdepartmentList = response["data"];
      }});
      //this.loaderService.hide();
  }
  fetchSubDepartments(event){
   // this.fetchServicesByDepartmentID(event);
  
   this.loader_spinner.show();
     var url = this._appSettings.CommonEsewaAPI;
    var fetchSubDepartment = this._appSettings.fetchSubDepartment;
    url = url + fetchSubDepartment + event;
    
    this._ConfigService.get(url)
    .subscribe(response => {
        this.SubDepartmentList = response["data"];
        this.CurrentSubDepartmentList = response["data"];
        if(response["data"] == null)
        {
          this.fetchServicesByDepartmentID(event);
        }
        else
        {
          this.currentServicesList = null;
        }
 
    });
    
    this.loader_spinner.hide();
  }

  fetchServicesByDepartmentID(event){ 
    this.loader_spinner.show();
    var _departmentId =  (this.firstFormGroup.get("departmentID").value) ? this.firstFormGroup.get("departmentID").value : 0;
    var url = this._appSettings.CommonEsewaAPI;
    var fetchServicesByDepartmentID = this._appSettings.fetchServicesByDepartmentID;
    url = url + fetchServicesByDepartmentID + _departmentId + '/'+ event.subDeptID + '/' + event.esewaNew;
    this._ConfigService.get(url)
    .subscribe(response => {
      if(response["response"] == 1){
        this.servicesList = response["data"];
        this.currentServicesList = response["data"];
      }});
    this.loader_spinner.hide();
  }

  searchBy(event){
    this.selecteSearchBy =  event;
    if(this.selecteSearchBy === "ApplicationID"){
      this.firstFormGroup.get('ApplicationID').setValidators(Validators.required);
      this.firstFormGroup.get('startDate').setValidators(null);
      this.firstFormGroup.get('endDate').setValidators(null);
    }
    else{
      this.firstFormGroup.get('ApplicationID').setValidators(null);
      this.firstFormGroup.get('startDate').setValidators(Validators.required);
      this.firstFormGroup.get('endDate').setValidators(Validators.required);
    }
    this.firstFormGroup.get("ApplicationID").updateValueAndValidity();
    this.firstFormGroup.get("startDate").updateValueAndValidity();
    this.firstFormGroup.get("endDate").updateValueAndValidity();
  }
  
  paginateApplications(event: PageEvent): PageEvent {
    this.tableOptions.pageIndex = event.pageIndex;
    this.tableOptions.previousPageIndex = event.previousPageIndex;
    this.tableOptions.pageSize = event.pageSize; 
    this.onSubmit();
    return event;
  }
  onSubmit(){  
  
    if (this.firstFormGroup.invalid === true) {  
        this.loader_spinner.hide();
        this._notification.warning("Please fill all required filled","warning");
      return;
    }
  else{
    this.loader_spinner.show();
    let formData={};
    formData = {     
      applicationStatus : (this.firstFormGroup.get("applicationStatus").value) ? this.firstFormGroup.get("applicationStatus").value : 'Z' ,      
      page :{pageIndex:this.tableOptions.pageIndex + 1 ,pageSize:this.tableOptions.pageSize },
      applicationID:Number( (this.firstFormGroup.get("ApplicationID").value ) ? this.firstFormGroup.get("ApplicationID").value : 0),
      servicesId : Number((this.firstFormGroup.get("servicesId").value) ? this.firstFormGroup.get("servicesId").value : 0),      
      departmentId : Number((this.firstFormGroup.get("departmentID").value) ? this.firstFormGroup.get("departmentID").value : 0),
      esewaNew:  (this.firstFormGroup.get("subDeptID").value?.esewaNew) ? this.firstFormGroup.get("subDeptID").value.esewaNew : 'N',
      fromdate: (this.firstFormGroup.get("startDate").value) ? moment(this.firstFormGroup.get("endDate").value).format('MM/DD/YYYY') : null,
      todate: (this.firstFormGroup.get("endDate").value) ? moment(this.firstFormGroup.get("endDate").value).format('MM/DD/YYYY') :  null 
    }  

    // formData = {     
    //   applicationStatus :  "Z",
    //   page :{pageIndex:1,pageSize:25 },
    //   applicationID:0,
    //   servicesId : 0,
    //   departmentId : 4,
    //   esewaNew: "n",
    //   fromdate: "12/10/2020",
    //   todate:"01/01/2021"
    //     }  


    var url = this._appSettings.CommonEsewaAPI;
    var fetchAdvanceSearchResult = this._appSettings.fetchAdvanceSearchResult;
    url = url + fetchAdvanceSearchResult;
    this._ConfigService.post(url, formData)
    .subscribe(response => {
      if(response["response"] == 1){
       
        this.dataSource.data =response['data'];

      //  const ELEMENT_DATA: HistoryElement[] = response['data'];
        console.log(response);
        this.loader_spinner.hide();
      }else{
        this.loader_spinner.hide();
        this._notification.info("No Record!");   
      }
    });
  }
  }
  // onSubmitnew(){ 
  //   debugger;
  //   this.dataSource.data = [
  //       {applicationID: 1, serviceID: 33, service_name: 'Test v 1'},
  //       {applicationID: 2, serviceID: 244, service_name: 'Test fvd 2'},
  //       {applicationID: 3, serviceID: 2345, service_name: 'Test fd 3'},
  //       {applicationID: 4, serviceID: 245, service_name: 'Test 4'},
  //     ];

  // }
  // refresh(data) {
  //   new MatTableDataSource<HistoryElement>(data);
    
  // }
}

export interface HistoryElement {
  applicationID: number;
  serviceID: number;
  service_name: string;
}
 const ELEMENT_DATA: HistoryElement[] = [];
// const ELEMENT_DATA: HistoryElement[] = [
//   {applicationID: 1, serviceID: 96, service_name: 'Test 1'},
//   {applicationID: 2, serviceID: 36, service_name: 'Test 2'},
//   {applicationID: 3, serviceID: 46, service_name: 'Test 3'},
//   {applicationID: 4, serviceID: 55, service_name: 'Test 4'},
//   {applicationID: 5, serviceID: 56, service_name: 'Test 5'},
//   {applicationID: 6, serviceID: 55, service_name: 'Test 6'},
//   {applicationID: 7, serviceID: 56, service_name: 'Test 7'},
//   {applicationID: 8, serviceID: 33, service_name: 'Test 8'},
//   {applicationID: 9, serviceID: 22, service_name: 'Test 9'},
//   {applicationID: 10, serviceID: 24, service_name: 'Test 10'},
//   {applicationID: 11, serviceID: 22, service_name: 'Test 11'},
// ];