
jQuery(document).ready(function() {
	
    /*
        Form
    */
    $('.marriage-certificate-form fieldset:first-child').fadeIn('slow');
    
    $('.marriage-certificate-form input[type="text"], .marriage-certificate-form input[type="password"], .marriage-certificate-form textarea, .marriage-certificate-form select').on('focus', function() {
    	$(this).removeClass('input-error');
    });
    
    // next step
    $('.marriage-certificate-form .btn-next').on('click', function() {
    	var parent_fieldset = $(this).parents('fieldset');
    	var next_step = true;
    	
    	parent_fieldset.find('select[name="Salutation"],input[name="BeneficiaryFirstName"], input[name="BeneficiaryFirstNamePunjabi"], input[name="FatherFirstName"], input[name="FatherFirstNamePunjabi"], input[name="MotherFirstName"], input[name="MotherFirstNamePunjabi"], input[type="date"], input[name="AgeofBeneficiary"], input[name="PlaceofBirth"], input[name="Salutation"], input[name="MobileNo"]').each(function() {
    		if( $(this).val() == "" ) {
    			$(this).addClass('input-error');
    			next_step = false;
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	
    	if( next_step ) {
    		parent_fieldset.fadeOut(400, function() {
	    		$(this).next().fadeIn();
	    	});
    	}
    	
    });
    
    // previous step
    $('.marriage-certificate-form .btn-previous').on('click', function() {
    	$(this).parents('fieldset').fadeOut(400, function() {
    		$(this).prev().fadeIn();
    	});
    });
    
    // submit
    $('.marriage-certificate-form').on('submit', function(e) {
    	
    	$(this).find('input[type="text"], input[type="password"], textarea').each(function() {
    		if( $(this).val() == "" ) {
    			e.preventDefault();
    			$(this).addClass('input-error');
    		}
    		else {
    			$(this).removeClass('input-error');
    		}
    	});
    	
    });
    
    
});
