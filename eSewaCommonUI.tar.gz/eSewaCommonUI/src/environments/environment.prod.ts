export const environment = {
  production: true,
  envName: 'production',
  eSewaURL: 'https://esewa.punjab.gov.in/',
  postGreMasterAPI: 'https://sdc-esewa-prod.punjab.gov.in/SocialJusticeAPIs/',
  marriageServicesAPI: 'https://sdc-esewa-prod.punjab.gov.in/homemarriageapi/',

  // Upload Document URL
  uploadDocumentURL: 'https://sdc-esewa-prod.punjab.gov.in/SocialJusticeUI/',

  // Service ID of Marriage ability
  serviceID_marriageability: 104
};
