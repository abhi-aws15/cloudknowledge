export const environment = {
  production: false,
  envName: 'testing',
  eSewaURL: 'https://esewatst.punjab.gov.in/',
  postGreMasterAPI: 'https://sdc-esewa-stg.punjab.gov.in/SocialJusticeAPIs/',
  marriageServicesAPI: 'https://sdc-esewa-stg.punjab.gov.in/homemarriageapi/',

  // Upload Document URL
  uploadDocumentURL: 'https://sdc-esewa-stg.punjab.gov.in/SocialJusticeUI/',

  // Service ID of Marriage ability
  serviceID_marriageability: 104
};
